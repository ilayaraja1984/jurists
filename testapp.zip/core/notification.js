 import messaging from '@react-native-firebase/messaging';
 import PushNotification, {Importance} from 'react-native-push-notification';
import { useNavigation } from '@react-navigation/native';
import  config  from '../core/global'
import whistle from '../assets/whistle.mp3';
import ring from '../assets/ring.mp3';
var Sound = require('react-native-sound');

//const song = new Audio('./assets/whistle.mp3');
const configuration = {
      optional: null,
      key: Math.random().toString(36).substr(2, 4),
    };
const playsound=(f) =>{
Sound.setCategory('Playback');
var whoosh = new Sound(f, (error) => {
  if (error) {
    console.log('failed to load the sound', error);
    return;
  }
  // loaded successfully
  console.log('duration in seconds: ' + whoosh.getDuration() + 'number of channels: ' + whoosh.getNumberOfChannels());

  // Play the sound with an onEnd callback
  whoosh.play((success) => {
    if (success) {
      console.log('successfully finished playing');
       whoosh.release();

    } else {
      console.log('playback failed due to audio decoding errors');
    }
  });
});
whoosh.setVolume(0.5);

// Position the sound to the full right in a stereo field
whoosh.setPan(1);

// Loop indefinitely until stop() is called
whoosh.setNumberOfLoops(-1);
}
const dellocalpushnotification=(id) => {
console.log('notification cleared ',id);
  setTimeout(
        () => { console.log('result notification cleared ',id);
        PushNotification.cancelLocalNotifications({id: id}) },
        2000
      );
}

 const localpushnotification=(item) => 
{
 //PushNotification.cancelAllLocalNotifications();console.log(item,'--------------')
 let d=item.data;
 if(d.type=='incoming'){
  PushNotification.localNotification({
  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: d.title, // (optional)
  message: d.body, // (required)
  smallIcon: "ic_stat_jz",
  actions: ["Accept", "Reject"],
  timeoutAfter: 110000,
  data:item.data,
});  
  //dellocalpushnotification(item.id)
 }
 else{
 PushNotification.localNotification({
  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: d.title, // (optional)
  message: d.body, // (required)
  smallIcon: "ic_stat_jz",
  data:item,
  
 
});}

}
const createChannel=() =>
{
 
 PushNotification.channelExists("juristz-id", function (exists) {
  console.log(exists); // true/false

  if(!exists){

    PushNotification.createChannel(
    {
      channelId: "juristz-id", // (required)
      channelName: "juristz", // (required)
      channelDescription: "A channel to categorise your notifications", // (optional) default: undefined.
      playSound: false, // (optional) default: true
      soundName: "default", // (optional) See `soundName` parameter of `localNotification` function
      importance: Importance.HIGH, // (optional) default: Importance.HIGH. Int value of the Android notification importance
      vibrate: true, // (optional) default: true. Creates the default vibration pattern if true.
    color: "red", 
    actions: ["Yes", "No"],
    id: 0,
    },
    (created) => console.log(`createChannel returned '${created}'`) // (optional) callback returns whether the channel was created, false means it already existed.
  );
  }
})
  
}
const notification={
  test : async () => {},
 sendPushNotification : async (da) => {
  const FIREBASE_API_KEY = "AAAAYW2ElQc:APA91bEx6J3a3DLYnuKKrOXo7QGCk7eU7duDgjfH05YcSoENsJHYZ1EqAFOJ1qavBeCTGwpnqIB4v9Pcu20DQWGcUKXNZAg1E_5CX4kiZnlhsj6MSPRWwV8mh8CBvEPOQkR6U4TQSoYs"
  const message = {
    registration_ids: [
      "e0u1Hk50RdWHoT3jaGHpj-:APA91bFRGQmpHfJ-PTckaHewxzI_A9hfJz8OLj52mxydElKv8slrXZPL0ko25YuD9S3_pdqq7uCgWNph0u1zjpkw5gJK37eJTd5vOHZXt8PYTnvIvsfdw2LgwiC_cgsCHWyia7L2RD34",
      
    ],
    notification: {
      title: "india vs south africa test",
      body: "IND chose to bat",
      vibrate: 1,
      sound: 1,
      show_in_foreground: true,
      priority: "high",
      content_available: true,

    },
    data: {
      title: "india vs south africa test",
      body: "IND chose to bat",
      score: 50,
      wicket: 1,
    },
  }

  let headers = new Headers({
    "Content-Type": "application/json",
    Authorization: "key=" + FIREBASE_API_KEY,
  })

  let response = await fetch("https://fcm.googleapis.com/fcm/send", {
    method: "POST",
    headers,
    body: JSON.stringify(message),
  })
  response = await response.json()
  console.log(response)
},
sendPushData : async (da,fun=null) => {
  const FIREBASE_API_KEY = "AAAAYW2ElQc:APA91bEx6J3a3DLYnuKKrOXo7QGCk7eU7duDgjfH05YcSoENsJHYZ1EqAFOJ1qavBeCTGwpnqIB4v9Pcu20DQWGcUKXNZAg1E_5CX4kiZnlhsj6MSPRWwV8mh8CBvEPOQkR6U4TQSoYs"
  const message = {
    registration_ids: [
      "e0u1Hk50RdWHoT3jaGHpj-:APA91bFRGQmpHfJ-PTckaHewxzI_A9hfJz8OLj52mxydElKv8slrXZPL0ko25YuD9S3_pdqq7uCgWNph0u1zjpkw5gJK37eJTd5vOHZXt8PYTnvIvsfdw2LgwiC_cgsCHWyia7L2RD34",
      
    ],
   
    data: da,
  }

  let headers = new Headers({
    "Content-Type": "application/json",
    Authorization: "key=" + FIREBASE_API_KEY,
  })

  let response = await fetch("https://fcm.googleapis.com/fcm/send", {
    method: "POST",
    headers,
    body: JSON.stringify(message),
  })
  response = await response.json()
  if(fun){fun(response)}
  console.log(response)
},
 register:async () =>{
  // Register the device with FCM
  await messaging().registerDeviceForRemoteMessages();

  // Get the token
  const token = await messaging().getToken();
console.log(token,'========================>>>>>>>>??????????????????????????????????????????????????????');
return token;
  // Save the token
  //await postToApi('/users/1234/tokens', { token });
},
 createChannel()  
{
  PushNotification.createChannel(
    {
      channelId: "juristz-id", // (required)
      channelName: "juristz", // (required)
      channelDescription: "A channel to categorise your notifications", // (optional) default: undefined.
      playSound: true, // (optional) default: true
      soundName: "default", // (optional) See `soundName` parameter of `localNotification` function
      sound: "default", // (optional) See `soundName` parameter of `localNotification` function
      soundName: "default",
      importance: Importance.HIGH, // (optional) default: Importance.HIGH. Int value of the AndrosoundName: "rush"id notification importance
      vibrate: true, // (optional) default: true. Creates the default vibration pattern if true.
    color: "red", 
    actions: ["Yes", "No"],
    id: 0,
    },
    (created) => console.log(`createChannel returned '${created}'`) // (optional) callback returns whether the channel was created, false means it already existed.
  );
},
localpushnotification(item)
{
 PushNotification.cancelAllLocalNotifications();
 PushNotification.localNotification({
  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: "testing vvvvvvvvvvv", // (optional)
  message: "message.data.body", // (required)
  playSound: true,
  soundName: "default", 
  sound: "default", 
  smallIcon: "ic_stat_jz",
  data:{id:25},
  
 
});

}
,
onMessageReceived:async (message) => {
   //console.log(message,'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',globalCall.start);

   
   //WebrtcSimple.setSessionId('q123');
  // let peer=WebrtcSimple.startbk();
  // WebrtcSimple.connect('q123');
   console.log('==============XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
   //createChannel()
   //localpushnotification(message)
},
notificationConfigure(obj)
{
  config.calling=false;
  PushNotification.configure({
    onNotification: function (notification) {
      console.log('LOCAL NOTIFICATION ==>', notification);const info = notification;
      console.log(info.data.type , config.appState,'8888888888888888888888888888888888888',info.actions);
      if(typeof(info.action)=='undefined' && typeof(info.actions)=='undefined'){
      if(config.appState=='active'){playsound(whistle);}else{playsound(ring);}}
      
      if (info.data.type=="incoming" && config.appState=='active'){
         config.notficationData=notification.data;
         if(config.obj!=null){ 
          if(config.screen1=='call'){console.log('WQQQQQQQQQQQQQQQQQ');
          config.peer.consesmsg({data:notification.data,'incoming':1,id:notification.data.id})}
          else{config.obj.props.navigation.navigate('call',{data:notification.data,'incoming':1});}return;
         }
      }
      
      else if(typeof(info.action)=='undefined' && typeof(info.actions)=='undefined'){
       createChannel()
      localpushnotification(notification)
      }
      else{
    config.pushnotidata=notification;config.pushnoti=false;
    
    if (info.data.type=="incoming" && (info.action == 'Accept' || typeof(info.action)=='undefined')) {
        config.notficationData=notification.data;
        config.calling=true;
       //info.sendPushData({type:'startcall',sid:info.data.sid,id:info.data.id});
       console.log('call  initiated',notification.data);

        if(config.obj!=null){ 
          if(typeof(config.obj.state.callId)!='undefined'){}
          else{config.obj.props.navigation.navigate('call',{data:notification.data,'incoming':1});}
         }
       // else{navigation.navigate('call',{'data':notification});}
     }
    else if (info.data.type== "appointment" && (info.action == 'Accept' || typeof(info.action)=='undefined')) {
     if(config.obj!=null){ config.obj.props.navigation.navigate('Myappoinment',{'data':notification});}
     else{config.pushnoti=true;}
    } 
    else if (info.data.type == "appointment") {
     if(config.obj!=null){ config.obj.props.navigation.navigate('appoinment',{'data':notification});}
     else{config.pushnoti=true;}
    } 
    else if (info.action == 'Cancel') {
      pushnotiaction = 0;
    }
     }
    },

    // This line solves the problem that I was facing.
    requestPermissions: Platform.OS === 'ios',
  });
},
MessageHandler(){
const unsubscribe =messaging().onMessage(this.onMessageReceived);
messaging().setBackgroundMessageHandler(this.onMessageReceived);

messaging().onNotificationOpenedApp(remoteMessage => {
      console.log(
        'Notification caused app to open from background state:',
        remoteMessage.notification,
      );
      //navigation.navigate(remoteMessage.data.type);
    });

    // Check whether an initial notification is available
    messaging()
      .getInitialNotification()
      .then(remoteMessage => {
        if (remoteMessage) {
          console.log(
            'Notification caused app to open from quit state:',
            remoteMessage.notification,
          );
          //setInitialRoute(remoteMessage.data.type); // e.g. "Settings"
        }
        //setLoading(false);
      });
}
}
 module.exports =notification;