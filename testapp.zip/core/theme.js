import { DefaultTheme } from 'react-native-paper'

export const theme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    text: '#000000',
    primary: '#560CCE',
    secondary: '#673ab7',
	light:'#BDA7E3',
    error: '#f13a59',
  },
}

//560CCE 