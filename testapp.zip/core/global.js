module.exports = {
   screen1: null,
   pushnoti:false,pushnotidata:{},calling:false,
   data:{},
   uinfo:null,
   pimage:null,
   notfication:null,
   menu:{},
   appState:'',
   peer:null,
   peercon:null,
   sid:'0000',
   obj:null,
   settings:{'login':false,role:3,cnt:0}
};