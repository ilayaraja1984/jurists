export const SERVER_URL = "http://juristz.com/apinew";//http://192.168.1.16/juristz1/api http://juristz.com/apinew
export const SERVER = "http://juristz.com/";
export const SMS_URL =""
export function networkCheck(){
  return (dispatch) => {
    const dispatchNetworkState = (isConnected) => dispatch({
      type: types.NETWORK_STATE,
      state: isConnected
    })
    const handle = () => NetInfo.isConnected.fetch().done(dispatchNetworkState)
    NetInfo.isConnected.addEventListener('change', handle);
  }
}
export const MENU = [
      {
        navOptionIcon: 'search',
        navOptionTitle: 'Home',
        screenToNavigate: 'homeScreen',
        //controler: '!search',
        islogin: true,
        
      },

	   {
        navOptionIcon: 'book',
        navOptionTitle: 'My Profile',
        screenToNavigate: 'clientprofile',
        islogin: true,
		custom:{'role':3}
      },
      {
        navOptionIcon: 'book',
        navOptionTitle: 'My Profile',
        screenToNavigate: 'lawyerprofile',
        islogin: true,
    custom:{'role':2}
      },
      {
        navOptionIcon: 'calendar-today',
        navOptionTitle: 'My Appointments',
        screenToNavigate: 'appoinment',
        islogin: true,
      },
      
      {
        navOptionIcon: 'admin-panel-settings',
        navOptionTitle: 'My Wallet',
        screenToNavigate: 'transections',
        islogin: true,
      },
	  {
        navOptionIcon: 'admin-panel-settings',
        navOptionTitle: 'Widthdraw',
        screenToNavigate: 'widthdraw',
        islogin: true,
      },
      
      {
        navOptionIcon: 'bookmark-outline',
        navOptionTitle: 'About',
        screenToNavigate: 'myList',
        islogin: true,
      },
      {
        navOptionIcon: 'logout',
        navOptionTitle: 'Logout',
        screenToNavigate: 'otp',
        islogin: true,
      }
    ];
