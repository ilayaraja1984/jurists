import { SERVER_URL,SERVER } from '../core/settings'
const lib = {
 config: {},
 isArray ( obj ) {return typeof(obj)=='object'?true:false;},
 isFun(o){if(o){if(typeof o === "function"){return true}} return false},
 opcheck(t,v,a){if(a[t]){if(a[t]==v){return true}} return false},
 async postdata(url,data={},op={}){
	 url=SERVER_URL+url;
	 console.log(url,' =>>>>> request called ',op);
	 let res=null;let resx=null;
	 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> request called ');}
	  console.log(url,' =>>>>> request called ');
	 var formData = {};
	     if(this.isArray(data)){
		 let k=Object.keys(data);
	     for(var i=0;i<k.length;i++){formData[k[i]]=data[k[i]];}
		// console.log(formData,'test=================>>>>>');return formData;
		 }
		if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> started ');}
		await fetch(url, {
         method: 'POST',
		 headers: {'Content-Type': 'application/json'},
         body: JSON.stringify(formData)
      })
      .then((response) => {return this.opcheck('type','text',op)?response.text():response.json();})
      .then((responseJson) => {
			 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> responce recived ');console.log(responseJson,' =>>>>> responce ');}
			 if(this.isFun(op['success'])){op['success'](responseJson)}})
	   
      .catch((error) => {
		if(this.isFun(op['error'])){op['error'](error)}
		console.log('request errrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr');
         console.error(error);
      });	  
	 return
 },
 f(){console.log("caledd class");}
}
module.exports =lib;