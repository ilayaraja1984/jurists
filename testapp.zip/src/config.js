export default [
  {
    appId: 5476,
    authKey: 'FZTrGG5yXr6VYZU',
    authSecret: 'CDds4UVcAB6ebh-',
  },
  {
    debug: {mode: 1},
  },
];

export const users = [
  {
    id:4955871,
    name: 'ilayaraja',
    login: 'ilayaraja',
    password: '12345678',
    color: '#34ad86',
  },
  
];
