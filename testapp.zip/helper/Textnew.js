import React, { Component } from 'react';
import { View, StyleSheet, Text } from 'react-native'
import { TextInput as Input } from 'react-native-paper'
import { theme } from '../core/theme'
import GLOBAL from '../core/global'

//GLOBAL.data['test'].setState({name:'raja'})
//console.log(GLOBAL.data['test'].state)
//console.log('name',this.props)



class Cat extends Component {
  constructor(props)
  {
   super(props);
  this.state={a:true,error:false,value:''}
  }
  connect(){
  if(!GLOBAL.data['inputs']){GLOBAL.data['inputs']={}}
  if(this.props.name){GLOBAL.data['inputs'][this.props.name]=this}
  }
  componentDidMount(){this.connect()}
  
  render() {
	 
	 // GLOBAL.data['test'].setState({name:this.props.name})
	  //console.log(GLOBAL.data['test'].state)
    return (
      <View style={styles.container}>
    <Input
      style={styles.input}
      selectionColor={theme.colors.primary}
      underlineColor="transparent"
      mode="outlined"
	  onChangeText={value => this.setState({value})}
      {...this.props}
    />
    
    {this.state.error ? <Text style={styles.error}>{this.props.errorText?this.props.errorText:'Invalid value'}</Text> : null}
  </View>
    );
  }
}




const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginVertical: 4,
  },
  input: {
    backgroundColor: theme.colors.surface,
  },
  description: {
    fontSize: 13,
    color: theme.colors.secondary,
    paddingTop: 8,
  },
  error: {
    fontSize: 13,
    color: theme.colors.error,
    paddingTop: 4,
  },
})

export default Cat
