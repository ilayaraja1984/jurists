import React, { Component } from 'react';
import { ImageBackground, StyleSheet, KeyboardAvoidingView } from 'react-native'
import { theme } from '../core/theme'
import GLOBAL from '../core/global'

class Form extends Component {
  constructor(props)
  {
   super(props);
  this.state={a:true}
  }
  connect(){
  //GLOBAL.data['test'].setState({name:'raja'});console.log(GLOBAL.data['test'].state);
  let data=GLOBAL.data;
  data[this.props.name]={}
  data['Context']=this.props.name
  console.log('name:',data['Context']);
  React.Children.map(this.props.children,(child,index)=>{
	
	if(child.props.post)
	{
		
		if(child.props.post=='1' || child.props.post=='true'){
			const childType={...child}	
	        GLOBAL.data[this.props.name][child.props.name]={value:"",props:child.props};
	        console.log('child',child.props.name,'=',child)
			}
	}
	
						 })
    console.log('form:===================================================')
    console.log('form:',GLOBAL.data[this.props.name])
  }
 
  componentDidMount(){this.connect()}
  
  render() {
	 
	 // GLOBAL.data['test'].setState({name:this.props.name})
	  //console.log(GLOBAL.data['test'].state)
    return (
      <KeyboardAvoidingView style={styles.container} behavior="padding">
      {this.props.children}
    </KeyboardAvoidingView>
    );
  }
}
const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    backgroundColor: theme.colors.surface,
  },
  container: {
    flex: 1,
    padding: 20,
    width: '100%',
    maxWidth: 340,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
})

export default Form
