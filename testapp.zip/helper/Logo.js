import React from 'react'
import { Image, StyleSheet } from 'react-native'

const Logo = () => (
  <Image source={require('../assets/logox.jpg')} style={styles.image} />
)

const styles = StyleSheet.create({
  image: {
   
    marginBottom: 8,
  },
})

export default Logo
