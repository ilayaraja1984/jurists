 import messaging from '@react-native-firebase/messaging';
const notification={
 sendPushNotification : async () => {
  const FIREBASE_API_KEY = "AAAAYW2ElQc:APA91bEx6J3a3DLYnuKKrOXo7QGCk7eU7duDgjfH05YcSoENsJHYZ1EqAFOJ1qavBeCTGwpnqIB4v9Pcu20DQWGcUKXNZAg1E_5CX4kiZnlhsj6MSPRWwV8mh8CBvEPOQkR6U4TQSoYs"
  const message = {
    registration_ids: [
      "e0u1Hk50RdWHoT3jaGHpj-:APA91bFRGQmpHfJ-PTckaHewxzI_A9hfJz8OLj52mxydElKv8slrXZPL0ko25YuD9S3_pdqq7uCgWNph0u1zjpkw5gJK37eJTd5vOHZXt8PYTnvIvsfdw2LgwiC_cgsCHWyia7L2RD34",
      
    ],
    notification: {
      title: "india vs south africa test",
      body: "IND chose to bat",
      vibrate: 1,
      sound: 1,
      show_in_foreground: true,
      priority: "high",
      content_available: true,
    },
    data: {
      title: "india vs south africa test",
      body: "IND chose to bat",
      score: 50,
      wicket: 1,
    },
  }

  let headers = new Headers({
    "Content-Type": "application/json",
    Authorization: "key=" + FIREBASE_API_KEY,
  })

  let response = await fetch("https://fcm.googleapis.com/fcm/send", {
    method: "POST",
    headers,
    body: JSON.stringify(message),
  })
  response = await response.json()
  //console.log(response)
}
 onAppBootstrap:async () =>{
  // Register the device with FCM
  await messaging().registerDeviceForRemoteMessages();

  // Get the token
  const token = await messaging().getToken();
console.log(token,'========================>>>>>>>>');
  // Save the token
  //await postToApi('/users/1234/tokens', { token });
}
}
 module.exports =notification;