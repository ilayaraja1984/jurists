import React, { Component,useState } from 'react';
import { View, StyleSheet, Text,TouchableOpacity } from 'react-native'



class Checklist extends Component {
  constructor(props)
  {
   super(props);
  //this.state={checked:false,error:false,value:''}
  }
 // setcheck(){this.state.checked?this.setState({checked:false}):this.setState({checked:true});}

  
  render() {
	 
	 // GLOBAL.data['test'].setState({name:this.props.name})
	  //console.log(GLOBAL.data['test'].state)
    return (
null
    );
  }
}



const styles = StyleSheet.create({
  container: {
    width: '100%',
    marginVertical: 12,
  },
  input: {
    backgroundColor: theme.colors.surface,
  },
  description: {
    fontSize: 13,
    color: theme.colors.secondary,
    paddingTop: 8,
  },
  error: {
    fontSize: 13,
    color: theme.colors.error,
    paddingTop: 8,
  },
})

export default Checklist
