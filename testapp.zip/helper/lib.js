const Obj= {
  data: () =>{return {response: (m)  =>{m();return "ebbbbbbbbbbbrrror"},error: (m) =>{m();return "errror"}}},
  name: "string"
  }

export const foo = Obj