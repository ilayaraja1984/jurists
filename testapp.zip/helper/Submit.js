import React, { Component } from 'react';
import { StyleSheet } from 'react-native'
import { Button as PaperButton } from 'react-native-paper'
import { theme } from '../core/theme'
import GLOBAL from '../core/global'

class Submit extends Component {
  constructor(props)
  {
   super(props);
  this.state={error:false,validated: true}
  }
  getType(type) {return type != null ? type : "";}
  parseValue(value = null) {
		value = value == null ? "" : value;
		value = String(value).trim();
		return value;
	}
  parseNum(num) {
		if (this.typeNumeric()) {num = parseInt(num);}
		if (isNaN(num)) {num = 0;}
		return num;
	}
  isValidated() {
		return this.state.validated;
	}
  typeNumeric(type) {
		return (
			type === "int" ||
			type === "integer" ||
			type === "numeric" ||
			type === "float" ||
			type === "decimal" ||
			type === "real"
		);
	}

  callback=()=>{
  let form=GLOBAL.data[this.props.form]  
  if(form){
  let fun=this.props.callback();
  console.log('form:===============================',Object.entries(form));
  Object.entries(form).map(([k, v]) => {
    console.log(k,'===============================',v['value'],GLOBAL.data['inputs'][v.props.name].state.value);
	if(GLOBAL.data['inputs'][v.props.name].state.value==""){GLOBAL.data['inputs'][v.props.name].setState({error:true});}
	else{GLOBAL.data['inputs'][v.props.name].setState({error:false});}
})
  /*form.map((data) => {
    console.log('form:::::',data['props'].name);
});*/
 
  
  }
  }
  
  valitation()
  {
	  
  }
  
  render() {
	 
	 // GLOBAL.data['test'].setState({name:this.props.name})
	  //console.log(GLOBAL.data['test'].state)
    return (
   <PaperButton
    style={[
      styles.button,
      this.props.mode === 'outlined' && { backgroundColor: theme.colors.surface },
      this.props.style,
    ]}
	onPress={() => this.callback()}
    labelStyle={styles.text}
    mode={this.props.mode}
    {...this.props}
  />
    );
  }
}

const styles = StyleSheet.create({
  button: {
    width: '100%',
    marginVertical: 10,paddingVertical: 2,
  },
  text: {
    fontWeight: 'bold',
    fontSize: 15,
    lineHeight: 26,
  },
})

export default Submit
