/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */


import type {Node , useEffect, useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,AppState,
  useColorScheme,
  View,Image,
} from 'react-native';

import {
  Colors,
  DebugInstructions,
  Header,
  LearnMoreLinks,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import * as React from 'react';
import { NavigationContainer,DrawerActions} from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Homenew from './components/homenew';
import Details from './components/details';
 import { theme } from './core/theme'
 import  config  from './core/global'
//Import all the menu screens
import homeScreen from './components/Home';
import Myappoinment from './components/Myappoinment';
import DrawerComponent from './components/drawer';
import widthdraw from './components/widthdraw';

import myList from './components/MyList';
import call from './components/call';
import Login from './components/Login';
import signup from './components/signup';
import payment from './components/payment';
import clientprofile from './components/clientprofile';
import lawyerprofile from './components/lawyerprofile';
import appoinment from './components/appoinment';
import profile from './components/profile';
import signuplawyer from './components/signuplawyer';
import address from './components/Address';
import profileupdate from './components/Profileupdate';
import lawyerprofileupdate from './components/lawyerprofileupdate';
import otp from './components/otp';
import test from './components/test';
import homenew from './components/homenew';
import details from './components/details';
import splash from './components/splash';
import newappoinment from './components/newappoinment';
import transections from './components/Transections';
import { AsyncStorage } from 'react-native';
import messaging from '@react-native-firebase/messaging';
import  notification from './core/notification'
import AuthScreen from './src/components/AuthScreen';
import VideoScreen from './src/components/VideoScreen';
import {
  DrawerContentScrollView,
  DrawerItemList,
} from '@react-navigation/drawer';
import { YellowBox } from 'react-native'
import PushNotification from "react-native-push-notification";
//import RNRestart from 'react-native-restart';
// Must be outside of any component LifeCycle (such as `componentDidMount`).
global.pushnoti = false;
global.pushnotiaction = 0;
global.pushnotidata = null;

// notification settings
notification.MessageHandler()
notification.notificationConfigure( null)


global.appstate='';
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();




const NavigationDrawerStructure = (props)=> {
  //Structure for the navigatin Drawer
  const toggleDrawer = () => {
    //Props to open/close the drawer
    props.navigationProps.toggleDrawer();
  };

  return (
    <View style={{ flexDirection: 'row' }}>
      <TouchableOpacity onPress={()=> toggleDrawer()}>
       <Icon  
                        style={{ width: 25, height: 25, marginLeft: 20}}    
                        name="md-menu"  
                        size={30}
                        color="#000"  
                    />  
      </TouchableOpacity>
    </View>
  );
}
const DrawerContent = (props) => {
  return (
    <SafeAreaView forceInset={{ top: 'always', horizontal: 'never' }}>
      <View style={{ flexDirection: 'row', paddingBottom: 20 }}>
        <View style={{ flex: 80, backgroundColor: '#f50057'}}>
            <Image style={{ width: 181, height: 132}} source={images.logo} />
        </View>
          <Text style={{ color: '#000', fontSize: 30 }}>Header</Text>
      </View>
      <DrawerItems {...props}/>
    </SafeAreaView>
)};
   
const StackNavigator = () => {
    return (
        <Stack.Navigator>
        <Stack.Screen name="appoinment" component={appoinment} options={{ headerShown: false }} />
         <Stack.Screen name="Splash" component={splash} options={{ headerShown: false }} />
		 <Stack.Screen name="otp" component={otp} options={{ headerShown: false }}/>
		 <Stack.Screen name="homeScreen" component={homeScreen} options={{ headerShown: true ,headerStyle: {backgroundColor: theme.colors.primary}, backgroundColor: theme.colors.primary,headerTintColor: theme.colors.secondary}} />
		 <Stack.Screen name="profile" component={profile} options={{ headerShown: false }} />
        <Stack.Screen name="Homenew" component={Homenew} />
        <Stack.Screen name="Details" component={Details} />
		 <Stack.Screen name="myList" component={myList} />
		  <Stack.Screen name="profileupdate" component={profileupdate} options={{ headerShown: false }} />
		  <Stack.Screen name="signuplawyer" component={signuplawyer} />
        </Stack.Navigator>
    );
};
const logo = require('./image/logo.jpg')
const DrawerNavigator = () => {
    return (
			
        <Drawer.Navigator drawerContent={(props) => <DrawerComponent {...props} />}>
       
      <Drawer.Screen
        name="homeScreen"
        component={homeScreen}
        options={{ drawerLabel: 'Home',headerShown: false ,headerStyle: {backgroundColor: theme.colors.primary},backgroundColor: theme.colors.primary,headerTintColor: theme.colors.secondary }}
      />
	  <Drawer.Screen
        name="signuplawyer"
        component={signuplawyer} 
        
		options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
      <Drawer.Screen
        name="profile"
        component={profile}
        options={{ drawerLabel: 'Profile' }}
      />
	 <Drawer.Screen
        name="myList"
        component={myList}
        options={{ drawerLabel: 'myList' }}
      />
      <Drawer.Screen
        name="VideoScreen"
        component={VideoScreen}
        options={{ drawerLabel: 'myList' }}
      />
      <Drawer.Screen
        name="AuthScreen"
        component={AuthScreen}
        options={{ drawerLabel: 'myList' }}
      />
	  <Drawer.Screen
        name="widthdraw"
        component={widthdraw}
        options={{ drawerLabel: 'myList' }}
      />
	   <Drawer.Screen
        name="otp"
        component={otp}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	  <Drawer.Screen
        name="address"
        component={address}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
    <Drawer.Screen
        name="call"
        component={call}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	  <Drawer.Screen
        name="transections"
        component={transections}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	   <Drawer.Screen
        name="profileupdate"
        component={profileupdate}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	  <Drawer.Screen
        name="newappoinment"
        component={newappoinment}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	   <Drawer.Screen
        name="Myappoinment"
        component={Myappoinment}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: true,
        };
      }}
      />
	  <Drawer.Screen
        name="lawyerprofileupdate"
        component={lawyerprofileupdate}
        options={({ route, navigation }) => {
        return {
          swipeEnabled: false,
        };
      }}
      />
	  <Drawer.Screen
        name="clientprofile"
        component={clientprofile}
        options={{ drawerLabel: 'clientprofile' }}
      />
      <Drawer.Screen
        name="lawyerprofile"
        component={lawyerprofile}
        options={{ drawerLabel: 'lawyerprofile' }}
      />

	   <Drawer.Screen
        name="appoinment"
        component={appoinment}
        options={{ drawerLabel: 'appoinment' }}
      />
	  <Drawer.Screen
        name="payment"
        component={payment}
        options={{ drawerLabel: 'payment' }}
      />
        </Drawer.Navigator>
    )
};


function App() {
  return (
    <NavigationContainer>
            <Stack.Navigator initialRouteName="Splash">
                <Stack.Screen name="Splash" component={splash} options={{ headerShown: false }}/>
                <Stack.Screen name="homeScreen" component={DrawerNavigator} options={{ headerShown: false }}/>
            </Stack.Navigator>
        </NavigationContainer>
  );
}



const styles = StyleSheet.create({
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
});

export default App;
