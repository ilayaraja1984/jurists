import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,SafeAreaView,FlatList,TouchableOpacity,TextInput,Image,KeyboardAvoidingView,ActivityIndicator,Alert} from 'react-native';
import {PermissionsAndroid} from 'react-native';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import Icon from 'react-native-vector-icons/Ionicons';
import MapView from "react-native-maps";
import GetLocation from 'react-native-get-location'
import { theme } from '../core/theme'
import Toast from 'react-native-toast-message';
import { AsyncStorage } from 'react-native';
import { SERVER_URL } from '../core/settings';
import GLOBAL from '../core/global'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});
const latitudeDelta = 1;
const longitudeDelta = 1;
global.rd=false;
const api = "AIzaSyB5wrx-qf90czh-420lZEoaw7Q5rTfpxzA";
type Props = {};
export default class MyList extends Component<Props> {
 constructor() {
    super();
  this.state = {
    region: {
        latitudeDelta,
        longitudeDelta,
        latitude: 13.067439,
        longitude: 80.237617,
		searchKeyword: '',
        searchResults: [],
        isShowingResults: false,
        },
	isLoging:false,
   listViewDisplayed: true,
   address: "Please wait, Getting GEO Points.....",
   showAddress: false,
   search: "",
   currentLat: 13.067439,
   currentLng: 80.237617,
   forceRefresh: 0,
   location: null,
   loading: false,
   latitude:'',
   longitude:'',
   city: '',
   state: '',
   country: '',
   data:null,
   role:4,

}

 }
  componentDidMount() {
    this.getLocation();
  }
goToInitialLocation = (region) => {
	 this.getCurrentAddress()
     
};
async requestAccessLocationPermission() {
  if (Platform.OS === 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({interval: 10000, fastInterval: 5000})
      .then(data => {
			this.getLocation();
        //alert(data);
      }).catch(err => {
        // The user has not accepted to enable the location services or something went wrong during the process
        // "err" : { "code" : "ERR00|ERR01|ERR02", "message" : "message"}
        // codes : 
        //  - ERR00 : The user has clicked on Cancel button in the popup
        //  - ERR01 : If the Settings change are unavailable
        //  - ERR02 : If the popup has failed to open
        alert("Error " + err.message + ", Code : " + err.code);
      });
    }
}
getLocation = () => {
     GetLocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 150000,
        })
            .then(location => {
                this.setState({
                    location,
                    loading: false,
                });
				console.log("========================================================================================")
				console.log(location);
				let initialRegion = Object.assign({}, this.state.region);
                initialRegion["latitudeDelta"] = 0.017077960073947906;
                initialRegion["longitudeDelta"] =  0.017077960073947906;
				initialRegion["latitude"] = location["latitude"];
				initialRegion["longitude"] = location["longitude"];
				this.getAddress(location["latitude"],location["longitude"]);
                this.mapView.animateToRegion(initialRegion, 2000);
   
  
   console.log("========================================================================================")
            })
            .catch(ex => {
                const { code, message } = ex;
                console.warn(code, message);
                /*if (code === 'CANCELLED') {
                    Alert.alert('Location cancelled by user or by another request');
                }*/
                if (code === 'UNAVAILABLE') {
                    Alert.alert('Location service is disabled or unavailable');
                }
                if (code === 'TIMEOUT') {
                    Alert.alert('Location request timed out');
                }
                if (code === 'UNAUTHORIZED') {
                    Alert.alert('Authorization denied');
                }
                this.setState({
                    location: null,
                    loading: false,
                });
				});
  };
onRegionChange = (region) => {
    this.setState({
      region: region,
      forceRefresh: Math.floor(Math.random() * 100),
      },
	  console.log(region)
     //this.getCurrentAddress//callback
     );
   };
async getAddress(l,lo){
	 console.log("\n==============================================================<<<<<<<<<<<<<<<<<<<<");
	
	 this.state.data=await this.getitems();console.log( 'xxxxx>',this.state.data[3]);
	 this.setState({ address: 'Please wait, current address is loading'});
	 this.setState({ role: this.state.data[3]});
	 this.state.latitude=l; this.state.longitude=lo;
	fetch('https://app.geocodeapi.io/api/v1/reverse?point.lat='+l+',&point.lon='+lo+'&apikey=05e67940-6e96-11eb-90f2-a9f8f4d770a0', {
         method: 'GET',
      })
      .then((response) => response.json())
      .then((responseJson) => {
        console.log('=========================');
			 console.log(responseJson);
       console.log('=========================');
			let location=responseJson;
      try{
			let lox=location['features'];console.log(lox[0]['properties']);
			if(lox[0]){
				let lo=lox[0]['properties'];console.log(lo);
				this.state.city=lo['county'];this.state.state=lo['region'];this.state.country=lo['country'];
   //this.state.address=lo['name']+','+lo['county']+','+lo['region']+','+lo['county'];
   this.setState({ address: lo['name']+','+lo['county']+','+lo['region']+','+lo['country']});

   
			}}catch(e){}
      this.setState({ loading: false});
         /*this.state.city=lo['county'];this.state.state=lo['region'];this.state.country=lo['countyr'];
   this.state.address=lo['name']+','+lo['county']+','+lo['region']+','+lo['county'];*/
      })
      .catch((error) => {
         console.error(error);
      });
   
}
async storeitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	return [session,id,session]
}
async getitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	let role=await AsyncStorage.getItem('role');
	return [uid,id,session,role]
}
redirect()
{
   
   if(rd){this.props.navigation.navigate('clientprofile');return}
	if(this.state.data[3]==2){this.props.navigation.navigate('lawyerprofileupdate')}
  else{this.props.navigation.navigate('profileupdate')}
}
saveCurrentAddress()
 {   console.log('save loading->',this.state.loading);
	 if(this.state.loading || this.state.address==""){
		 
		 Toast.show({
	  type: 'error',
	  position: 'top',
      text1: "Geo Locaion process is loading ,wait...",
      text2: 'Loading...... ',
	  
    });return true}
	 this.setState({ isLoging: true });
    console.log('save loading->',1);
	 if(this.state.address != ""){
		 console.log('save loading->',2);
	var formData = new FormData();
	    formData.append('address', this.state.address);
		formData.append('longitude', this.state.longitude);
        formData.append('latitude', this.state.latitude);
        formData.append('City', this.state.city);
		formData.append('State', this.state.state);
		formData.append('Country', this.state.country);
		//console.log("entering render section: " + JSON.stringify(GLOBAL.screen1.state) );
	
		let itm=this.state.data;
		formData.append('idz', itm[1]); 
	    formData.append('uid', itm[0]); 
		formData.append('session', itm[2]);
		//console.log('=====-------------------------------------------------------------------------');
		console.log(formData);
/*		formData.append('id', async (AsyncStorage.getItem('id'))); 
		formData.append('uid', await AsyncStorage.getItem('uid')); 
		formData.append('session', await AsyncStorage.getItem('session')); */
	fetch(SERVER_URL+'?op=updateaddress', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.json())
      .then((responseJson) => {
			 console.log("=========================");console.log(responseJson);//return
		 if(responseJson['result']==true)
		 {
			this.setState({ isLoging: false });
			Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully Updated...',
      text2: 'user Profile',
	  onHide: () => {this.redirect()},
    });
			
		 }
		 else{
		this.setState({ isLoging: false });	 
		Toast.show({
	  type: 'error',
	  position: 'top',
      text1: 'Address is invalid',
      text2: 'Please check login and session also ',
	  
    }); 
	
 }
			 })
      .catch((error) => {
         console.error(error);
      });
	 }
 }
 
 async pos(n){await AsyncStorage.setItem('screen',n);AsyncStorage.flushGetRequests();}
getCurrentAddress()
 {console.log('loading->',this.state.loading);
	if(this.state.loading){Toast.show({
	  type: 'error',
	  position: 'top',
      text1: "Geo Locaion process is loading , wait...",
      text2: 'Loading...... ',
	  
    });return true}
	this.setState({ loading: true, location: null });
    this.setState({ address:"Please wait, Getting GEO Points....."});
	this.requestAccessLocationPermission() ;
       
 }


  render() {
	      const { region } = this.state;
      udata=this.props.route.params;
		  if(typeof(udata)=='undefined'){this.pos('address');}else{this.pos('home');rd=true;}
    return (


     <View style={styles.map}>
     <View style={{backgroundColor:theme.colors.primary,height:70}}> 
   {typeof(udata)!='undefined' &&(<TouchableOpacity onPress={()=>{this.props.navigation.navigate('homeScreen');}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: 'white',}} />
   </TouchableOpacity>)}
    <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18}}>Update Profile Image </Text></View>
       </View>
       <MapView
         ref={(ref) => (this.mapView = ref)}
         onMapReady={() =>
         this.goToInitialLocation(this.state.region)}
         style={styles.map}
         initialRegion={this.state.region}
         onRegionChangeComplete={this.onRegionChange}
       />
    <View style={styles.panel}>
 
</View>
<View style={styles.markerFixed}>
<Image
  style={styles.marker}
  source={require("../assets/pinmarker.png")}/>
</View>
<KeyboardAvoidingView style={styles.footer}>
  <View style={{ flexDirection: "row", margin: 10 }}>
    
     <Icon name="home"
      size={24}
      color="#DC2B6B"
      type="ionicon"
       style={{
        paddingLeft:5 
      }}
     />
    <Text style={styles.addressText}>Current Location</Text>
	
  </View>
<TextInput
  multiline={true}
  clearButtonMode="while-editing"
  style={{
    marginBottom: 5,
    width: "90%",
    minHeight: 70,
    alignSelf: "center",
    borderColor: "lightgrey",
    borderWidth: 1.5,
    fontSize: 15,
    borderRadius: 5,
    flex: 0.5,
    alignContent: "flex-start",
    textAlignVertical: "top",
    fontFamily: "Calibri",
    }}
  onChangeText={(text) =>this.setState({ address: text })}
  value={this.state.address}
/>
<View style={{ flexDirection: "row", margin: 10,display: 'flex',justifyContent: "space-around"  }}>
  <TouchableOpacity 
   onPress={() => {this.saveCurrentAddress()}}
   style={{
    width: "30%",
    alignSelf: "center",
    alignItems: "center",
    backgroundColor: theme.colors.primary,marginVertical: 10,paddingVertical: 2,
    borderRadius: 3,
    shadowColor: "rgba(0,0,0, .4)", // IOS
    shadowOffset: { height: 1, width: 1 }, // IOS
    shadowOpacity: 1, // IOS
    shadowRadius: 1, //IOS
    elevation: 2, // Android 
    }}>
        <Text
           style={{
           color: "white",
           fontFamily: "Calibri",
           fontSize: 12,
           paddingVertical: 4,
        }}>
           SAVE
       </Text>
  </TouchableOpacity>
  
    <TouchableOpacity 
   onPress={() => {this.getCurrentAddress()}}
   disable={true}
   style={{
    width: "30%",
    alignSelf: "center",
    alignItems: "center",
    backgroundColor: theme.colors.primary,marginVertical: 10,paddingVertical: 2,
    borderRadius: 3,
    shadowColor: "rgba(0,0,0, .4)", // IOS
    shadowOffset: { height: 1, width: 1 }, // IOS
    shadowOpacity: 1, // IOS
    shadowRadius: 1, //IOS
    elevation: 2, // Android 
    }}>
        <Text
           style={{
           color: "white",
           fontFamily: "Calibri",
           fontSize: 12,
           paddingVertical: 4,
        }}>
           Get Geoloction
       </Text>
  </TouchableOpacity>
  </View>
 </KeyboardAvoidingView>
 <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:10000}} />
  {this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
</View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  loading: {
  position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
 map:{
  flex:1
  },
markerFixed: {
  left: "50%",
  marginLeft: -24,
  marginTop: -48,
  position: "absolute",
  top: "50%",
  },
addressText: {
  color: "black",
  margin: 3,fontSize: 16,fontWeight:'bold',
  fontFamily: "Calibri",
},
footer: {
  backgroundColor: "white",
  bottom: 0,
  position: "absolute",
  width: "100%",
  height: "30%",
},
panelFill: {
 position: "absolute",
 top: 0,
 alignSelf: "stretch",
 right: 0,
 left: 0,
},
panel: {
 position: "absolute",
 top: 0,
 alignSelf: "stretch",
 right: 0,
 left: 0,
 flex: 1,
},
});