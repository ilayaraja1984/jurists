import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,Image,TouchableOpacity,Dimensions,ActivityIndicator} from 'react-native';
import ImagePicker from 'react-native-image-picker'
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import Button from '../helper/Button';
import { AsyncStorage } from 'react-native';
import Toast from 'react-native-toast-message';
import { SERVER_URL,SERVER } from '../core/settings'
import { theme } from '../core/theme'
import eImage from '../assets/user.png'
import config from '../core/global'
import Icon from 'react-native-vector-icons/Ionicons';
import {PermissionsAndroid} from 'react-native';


const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});


export default class profileupdate extends Component<Props> {
	constructor() {
    super();
    this.state ={
      photo:{uri:Image.resolveAssetSource(eImage).uri},
	  loadimage:false,
	  isLoging:false,photouri:null,
    }
	
  }
	
 
  async getitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	
	return [uid,id,session]
}

 async requestCameraPermission () {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"App needs access to your camera ",
        buttonNeutral: "Ask Me Later",
        buttonNegative: "Cancel",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera permission given");
    } else {
      console.log("Camera permission denied");
    }
  } catch (err) {
    console.warn(err);
  }
}

  handleCameraPhoto = () => {
    const options = {
      noData: true,
    }
	console.log("work start===>>>",this.state.photo.uri);
	
	try
	{
	this.requestCameraPermission();	
    launchCamera(
              {
                mediaType: 'photo',
                includeBase64:true,
                maxWidth: 500,
                    maxHeight: 500,
                    quality: 0.5
              },
              (response) => {
				  console.log(response);this.setState({ loadimage: true })
				   if (response.error) {
    console.log('LaunchCamera Error: ', response.error);
  }
  else {
     this.setState({ photo: response });this.setState({photouri:response.uri});
  }
               
              },
            );
	}catch(e){console.log("work",e);}
	
  }
componentDidMount() {console.log(SERVER+config.profile.image,"====================");
  if(config.profile){this.setState({photouri:SERVER+config.profile.image});}
  else{this.setState({photouri:this.state.photo.uri});}
}
async createFormData (photo){
	 console.log("pppppppppppppp11111111");
  const data = new FormData();
   console.log("pppppppppppppp11111111");
  data.append('file', {
        uri: Platform.OS === 'android' ? photo.uri : photo.uri.replace('file://', ''),
        type: photo.type,
        name:photo.fileName,
        data: photo.data,
      });
 console.log("pppppppppppppp2222222");
		 let itm=await this.getitems();
		console.log("pppppppppppppp2222222",itm);
		
		data.append('uid', itm[0]); 
		data.append('session', itm[2]);

       
/*  Object.keys(body).forEach((key) => {
    data.append(key, body[key]);
  });*/
 console.log(data);
  return data;
  }
   savefile= async () => 
  { 
 	    if(this.state.loadimage==false){
			Toast.show({
	  type: 'error',
	  visibilityTime: 100,
	  position: 'top',
      text1: 'Image is invalid',
      text2: 'Please chose ane image... ',
	  
    }); 
			return false}
			
this.setState({ isLoging: true });//let p=this.createFormData(this.state.photo);return ;
console.log("cccccccccccccccccccccccc");
		fetch(SERVER_URL+'?op=profileimage', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: await this.createFormData(this.state.photo)
      })
      .then((response) => response.json())
      .then((responseJson) => {
			 console.log('===========xxxxxxxxxxxxxxxxxxx========');
			 console.log(responseJson);this.setState({ isLoging: false });
			 console.log('===========xxxxxxxxxxxxxxxxxxx========');
		 if(responseJson['result']==false)
		 {
			
			 Toast.show({
	  type: 'error',
	  visibilityTime: 1000,
	  position: 'top',
      text1: "File is invalid",
      text2: 'Please check ',
	  
    });
			 
		 }
		 else{
			 
		 Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully Profile Updated...',
      text2: 'Profile Image',onHide: () => {this.props.navigation.navigate('homeScreen')},
	 
    });
		// onHide: () => {this.props.navigation.navigate('homescreen')
		
			 }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
         console.error(error);
      });	 
	 
	
  }
  async pos(n){await AsyncStorage.setItem('screen',n);AsyncStorage.flushGetRequests();}
  handleChoosePhoto = () => {
    const options = {
      noData: true,
    }
	console.log("work start===>>>",this.state.photo);
	try
	{
    launchImageLibrary(options, response => {
      if (response.uri) {
		  this.setState({photouri:response.uri});
        this.setState({ photo: response })
		this.setState({ loadimage: true })

      }
    })
	}catch(e){console.log("work",e);}
  }
  
  render() {
	   const { photo } = this.state;
	   console.log('-----------------------------cccccccccccccccccccccc');
     udata=this.props.route.params;let mar=0;
	   if(!udata){this.pos('profile');mar=20;}
     
     
    return (

        <View style={{height:"100%"}}>
		      <View style={{backgroundColor:theme.colors.primary,height:70}}> 
   {typeof(udata)!='undefined' &&(<TouchableOpacity onPress={()=>{this.props.navigation.navigate('homeScreen');}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: 'white',}} />
   </TouchableOpacity>)}

    <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18,marginTop:mar}}>Update Profile Image </Text></View>
       </View>
       
        <View style={{alignItems:'center',paddingTop:50}}>
         
          <Image
            source={{ uri: this.state.photouri}}

  resizeMethod="resize"
            style={{ width: 200, height: 200,borderRadius:100,marginBottom:15 }}
          />
        
   
		</View>
     
	  
        <View style={{flexDirection: 'row',position: 'absolute',bottom: 25,justifyContent: 'center',alignItems: 'center',width:"96%"}}>
        <View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.handleCameraPhoto()}}>
       <Icon name="camera" size={35} color="#fff" /> 
        </TouchableOpacity>
        </View>
        <View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.handleChoosePhoto()}}>
       <Icon name="image" size={35} color="#fff" />
        </TouchableOpacity>
        </View>
        <View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.savefile()}}>
       <Icon name="save" size={35} color="#fff" /> 
        </TouchableOpacity>
        </View>
		  </View>
     
	  
        <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:10000}} /> 
		{this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
        </View>
    
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  bottomView: {
    width: 75,
    height: 75,
  borderRadius: 150,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft:30,

  

  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
uploadButtonText:{color:'#fff',fontWeight: "bold",},
  uploadContainer: {
    backgroundColor: theme.colors.light,
    borderTopLeftRadius: 45,
    borderTopRightRadius: 45,
    position: 'absolute',
    bottom: 0,
    width: Dimensions.get('window').width,
    
  },
  uploadContainerTitle: {
    alignSelf: 'center',
    fontSize: 25,
    margin: 20,
    fontFamily: 'Roboto'
  },
  uploadButton: {
    borderRadius: 16,
    alignSelf: 'center',
    shadowColor: "#000",
	color:'red',
	
    shadowOffset: {
      width: 7,
      height: 5,
    },
	shadowOpacity: 1.58,
    shadowRadius: 9,
    elevation: 4,
    margin: 10,
    padding: 10,
    backgroundColor: theme.colors.primary,
    width: Dimensions.get('window').width - 60,
    alignItems: 'center'
  },
  backgroundImage: {
    flex: 1,resizeMode: 'cover',
  }
 
});