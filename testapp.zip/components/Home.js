import React, {Component} from 'react';
import {Platform, StyleSheet,
  Text,
  TextInput,
  Alert,
  View,
  Image,
  TouchableOpacity,ActivityIndicator,
  FlatList,Animated,
  Dimensions,useWindowDimensions ,
  Modal,ImageBackground,BottomSheet,
  ScrollView} from 'react-native';
import { Rating,Button,PricingCard} from 'react-native-elements';
import Icon from 'react-native-vector-icons/Ionicons';
import { Searchbar } from 'react-native-paper';
import { theme } from '../core/theme'

import { AsyncStorage } from 'react-native';
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import { TabView, SceneMap } from 'react-native-tab-view';
import Toast from 'react-native-toast-message';
import {PermissionsAndroid} from 'react-native';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import GetLocation from 'react-native-get-location';
const latitudeDelta = 1;
const longitudeDelta = 1;
const api = "AIzaSyB5wrx-qf90czh-420lZEoaw7Q5rTfpxzA";
import { BackHandler } from "react-native";
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

//Define a color for toolbar
global.backgroundColor = '#176abf';
global.tm = null;
global.nv = null;
global.obj = null;
const status=['offline','online','idle','busy','away','in meeting','vacation'];
const statuscol={'online':'green','offline':'grey','idle':'orange','busy':'red','away':'orange','in meeting':'red','vacation':'blue'};
const vr=require("../assets/verified.png");
const uvr=require("../assets/tick.png");
const objp=null;
type Props = {};
const FirstRoute = () => (
  <View style={{ flex: 1, backgroundColor: '#ff4081' ,height:200}} />
);

const SecondRoute = () => (
  <View style={{ flex: 1, backgroundColor: '#673ab7' ,height:200}} />
);
const initialLayout = { width: Dimensions.get('screen').width };
const pobj=null;
export default class Home extends Component<Props> {

 constructor() {
    super();

  this.state = {
      modalVisible:false,
      userSelected:[],
	  setIsVisible : false,
	  isVisible: false,
	  nodata:false,
	  gpsrequest:false,
	   latitudeDelta,
	   gpsload:null,
        longitudeDelta,
        lat:null,
        lng: null,
		distance:30,
	  suggestion:false,
	  fdata:true,
	  msearch:false,
	  gender: "",
	  modelcontent:null,
	  modeltitle:null,
	  modelcontentheight:100,
	  catdata:null,
	  qtype:1,
	  category: "",
	  location: "",
	  isLoading:false,
	  iskeyboard:false,
	  moredata:false,
	  caticon:{},
	  page:0,
	  data:[],
	  query:"",
	  dataview:null,
      tm:null, 
	  isSelected:false,
	  setSelection:false,
      routes:[
    { key: 'first', title: 'First' },
    { key: 'second', title: 'Second' },
  ],index:0, setIndex:0,}
  
 }

 async getData(n=0,d=0)
 {
	 this.setState({ isLoading: true });
	 let obj=this;
	 let nop=n;
	 let ds=await this.getitems()
	 
	 let op={'success':function(d){obj.setState({ isLoading: false });
	 let data=d.data;console.log('sucess calledddddddddddddd',d['data']);obj.setModalVisible(false);
	 if(data.length==0 && nop==1){obj.setState({moredata:false});return}
	 if(data.length>=30){obj.setState({moredata:true});}else{obj.setState({moredata:false});}
	 if(data.length==0){obj.setState({nodata:true});obj.setState({fdata:false});}else{obj.setState({nodata:false});obj.setState({fdata:true});}
	 if(nop==1){data = [...obj.state.data, ...data];console.log( data)}
	 obj.setState({data:data});
	 },'error':function(d){console.log('error calledddddddddddddd')},'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let pd={'session':ds[2],'uid':ds[0]}
	 if(this.state.query.length>=1 && this.state.query!='near me'){pd['s']=this.state.query}
	 if(this.state.gender.length>=3){pd['g']=this.state.gender}
	 if(this.state.category.length>=3){let cx=this.state.category.substr(0,this.state.category.length-1);
	 cx=cx.replace(',',',|');pd['c']=cx+','}
	 if(this.state.lat!=null && this.state.query=='near me'){pd['lat']=this.state.lat;pd['lng']=this.state.lng;pd['distance']=this.state.distance}
	 
	 pd['t']=this.state.qtype;
	 pd['page']=this.state.page
	 this.postdata(SERVER_URL+'?op=lawyers',pd,op);
	
	 console.log('--------------------------------------------------------------------------------------------------------????');
	// console.log(this.fview(data))
	 //this.setState({dataview:this.fview(data)});
	// if(n==1){data = [...this.state.data, ...data];console.log( data)}
	// this.setState({data:data});
	 
	return true
	 
 }
 isArray ( obj ) {
    
     
		return typeof(obj)=='object'?true:false;
}
 isFun(o){if(o){if(typeof o === "function"){return true}} return false}
 opcheck(t,v,a){if(a[t]){if(a[t]==v){return true}} return false}
 postdata(url,data={},op={}){
	 console.log(url,' =>>>>> request called ',op);
	 let res=null;
	 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> request called ');}
	  console.log(url,' =>>>>> request called ');
	 var formData = new FormData();
	     if(this.isArray(data)){
		 let k=Object.keys(data);
	     for(var i=0;i<k.length;i++){formData.append(k[i], data[k[i]]);}
		// console.log(formData,'test=================>>>>>');return formData;
		 }
		if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> started ');}
		fetch(url, {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => {return this.opcheck('type','text',op)?response.text():response.json()})
      .then((responseJson) => {
			 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> responce recived ');console.log(responseJson,' =>>>>> responce ');}
			 if(this.isFun(op['success'])){op['success'](responseJson)}})
	   
      .catch((error) => {
		if(this.isFun(op['error'])){op['error'](error)}
         console.error(error);
      });	  
	 return
 }
 onContentSizeChange = (contentWidth, contentHeight) => {
    const newLength = this.state.data.length;
    newLength > this._lastDataLength && requestAnimationFrame(() => this._flatListRef && this._flatListRef.scrollToEnd({ animated: true }));
    this._lastDataLength = newLength;
	console.log('ennnnnnnnnnnnnnnnnnnnnnnnnnnnnnd')
  };
 
  refHandler = ref => {
    this._scrollViewRef = ref;
    // If you are using AnimatedFlatList, this should be written here
    //this._scrollViewRef = ref && ref.getNode();
  };

 fview(data)
 {
	 
	 return(<FlatList 
          style={styles.userList}
          columnWrapperStyle={styles.listContainer}
          data={data}
          keyExtractor= {(item) => {
            return item.id;
          }}
		  onEndReachedThreshold={0.5}
  onEndReached={({ distanceFromEnd }) => {
    console.log('on end reached ', distanceFromEnd);
	console.log('test');
	this.getData(1)
	console.log('test13333333333');
  }}

          renderItem={({item}) => {
		  let st=this.value(1,item.status)
		  let verifyimage=this.value(0,item.verified)
		  let image= SERVER_URL+item.image
		  console.log(image,'pppppppppppppppppppppp');
          return (
            <TouchableOpacity style={styles.card} onPress={() => {this.clickEventListener(item)}} key="{item.user_id}">
              <Image style={styles.image} source={{uri: image}}/>
              <View style={styles.cardContent}>
                <View style={{flex: 1, flexDirection: 'row', justifyContent: 'flex-start'}}>
        <View style={{width: '60%', height: 90}} >
		<Text style={styles.name}>{item.name}{item.rating}</Text>
        <View style={{flex: 1, flexDirection: 'row'}} ><Icon name="location" style={{ fontSize: 18 ,color: '#000',}} /><Text style={styles.position}>{item.position}</Text></View>
		
        <View style={{flex: 1, flexDirection: 'row'}} >
        <Icon name="ellipse-sharp" style={{ fontSize: 15 ,color: st[1],marginLeft:5}} /><Text style={styles.position}>{st[0]}</Text></View>
		</View>
        <View style={{width: '27%', height: 100,justifyContent: 'space-between',alignItems: 'center',}}>
		 <Image style={styles.verified} source={verifyimage}/>
     <Button onPress={() => {this._handleProfile(item)}} title="Book" type="clear" />
		 <View style={{flex: 1, flexDirection: 'column',justifyContent: 'space-between',marginTop:10}} ><Rating imageSize={15} readonly startingValue={item.rating} style={styles.rating} /></View>
		</View>
        
      </View>
              </View>
            </TouchableOpacity>
          )}}/>)
		  
	 
 }
 ImageLoading_Error(error){
 
    console.log('errrrrrrrrrrrrrrrrrrrrrrr',error)
 
    // Write Your Code Here Which You Want To Execute If Image Not Found On Server.
 
  }
 async setitems(responseJson)
  {
  
  }
 async _handleProfile(index){ //this.props.navigation.setParams({query: 'someText',});
     this.props.navigation.navigate('profile',{'data':index});
    return true
}
 callpro(){ clearInterval(global.tm);
  global.nv.navigate('profile',{'raja':'=========================='});}
 value(n,v){console.log('log',n,'=============',v,status[v]);
 if(n==1){return [status[v],statuscol[status[v]]]}
 else if(n==0 && v==1){return vr} 
 else if(n==0 && v==0){return uvr}}
 async getitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	let role=await AsyncStorage.getItem('role');
	config.uinfo=[uid,id,session,role];
	return [uid,id,session,role]
}
async pos(n){await AsyncStorage.setItem('screen',n);AsyncStorage.flushGetRequests();}
async componentDidMount() {
	
	 BackHandler.addEventListener("hardwareBackPress", this.onBackPress);
	let ldata=await this.getitems();
	  console.log("Log","logged............. started",ldata)
	  this.pos('home');
	  global.obj=this;config.obj=this;
	  this.getData();

}
componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
  }
  
 onBackPress = () => {
	 
   // const { dispatch, nav } = this.props;
	console.log('navvvvvvvvv bbbbbbbbbbbbbbbbbbbbbbb',this.props.route.name);
	
    //this.props.navigation.goBack(null);
	
   // dispatch(NavigationActions.back());
    return true;
  };
setgender(t){this.setState({gender:t });this.setModalVisible(false); this.state.page=0;this.getData(0,1)}
 clickEventListener = (item) => {
	 console.log(item);
    this.setState({userSelected: item}, () =>{
      this.setModalVisible(true);
    });
	
  }
  gendershow()
  {
	   let allm=<Icon name="square-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />
	   let m=<Icon name="square-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />
	   let f=<Icon name="square-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />
	  if(this.state.gender==""){allm=<Icon name="checkbox-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />}
	  if(this.state.gender=="male"){m=<Icon name="checkbox-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />}
	  if(this.state.gender=="female"){f=<Icon name="checkbox-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />}
	  
	  
	  return (<View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35}}>
			<TouchableOpacity  onPress={() => {this.setgender('')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>{allm} All   </Text></TouchableOpacity>
			<TouchableOpacity  onPress={() => {this.setgender('male')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>{m} Male </Text></TouchableOpacity>
	<TouchableOpacity  onPress={() => {this.setgender('female')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>{f} Female </Text></TouchableOpacity>
			</View>)
	  
  }
 setcat(itm,e)
 {
	// e.target._children[0].value="pppppppppppppppppppppppppppp";
	 
	// this.state.caticon[itm]=<Icon name="checkbox-outline" style={{ fontSize: 15 ,color: theme.colors.primary,marginLeft:5}} />
	this.state.caticon[itm]=this.state.caticon[itm]==1?2:1;
	if(this.state.category.search(itm+',')>=0){this.state.category=this.state.category.replace(itm+',','')}else{this.state.category+=itm+','}
	let dw=this.catlist(this.state.catdata);
	 this.setState({modelcontent:(<View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35,height:200}}>{dw}</View>)})
	//console.log(this.state.category.search(itm+','),this.state.category,'0000000000000000000000000000000000000000000');
 }
 catlist(data)
 {
	 this.state.catdata=data;console.log(data,"-------------------------------");
	 let allm=<Icon name="square-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />
	 return(<FlatList 
          style={styles.userList}
          columnWrapperStyle={styles.listContainer}
          data={data}
          keyExtractor= {(item, index) => {
            return item;
          }}
          renderItem={({item}) => {
			  console.log(this.state.caticon[item],'-------------------------------------------------------------');
			  
			  let ic=allm;
			  if(!this.state.caticon[item]){this.state.caticon[item]=1}
			  else{
				  if(this.state.caticon[item]==2){ic=<Icon name="checkbox-outline" style={{ fontSize: 15 ,color: theme.colors.primary,}} />}
				  }
			   console.log(this.state.caticon[item],'-------------------------------------------------------------');
          return (
				  
            <TouchableOpacity  onPress={(e) => {this.setcat(item,e)}} style={{flex:1,fontSize: 25 ,color:theme.colors.primary,height:25,marginBottom:5}}>
			<Text style={styles.name}> {ic} {item}</Text></TouchableOpacity>
          )}}/>)
 }
 async categoriesshow()
  {  obj.setState({ isLoading: true});
	  let op={'success':function(d){obj.setState({ isLoading: false });
	 let data=d.data;console.log('sucess calledddddddddddddd',d['data']);
	 let dw=obj.catlist(data);console.log(data,'00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000')
	 obj.setState({modelcontent:(<View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35,height:200}}>{dw}</View>)})
	 },'error':function(d){console.log('error calledddddddddddddd')},'type':'json','trace':true}
let ds=await this.getitems()
let pd={'session':ds[2],'uid':ds[0]}	 
this.postdata(SERVER_URL+'?op=categories',pd,op);
  }
  async requestAccessLocationPermission() {
  if (Platform.OS === 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({interval: 10000, fastInterval: 5000})
      .then(data => {
			this.getLocation();
        //alert(data);
      }).catch(err => {
        // The user has not accepted to enable the location services or something went wrong during the process
        // "err" : { "code" : "ERR00|ERR01|ERR02", "message" : "message"}
        // codes : 
        //  - ERR00 : The user has clicked on Cancel button in the popup
        //  - ERR01 : If the Settings change are unavailable
        //  - ERR02 : If the popup has failed to open
        alert("Error " + err.message + ", Code : " + err.code);
      });
    }
}
  getLocation = () => {
	  //this.props.navigation.navigate('address');return
	   this.setState({ isLoading: true });
	   obj.setState({modelcontent:(<View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35,height:50}}><Text style={styles.name}>GPS Location is getting,Please wait..</Text></View>)});this.setModalVisible(true)
     GetLocation.getCurrentPosition({
            enableHighAccuracy: true,
            timeout: 150000, maximumAge: 3600000
        })
            .then(location => {
				console.log(location["latitude"],"========================================================================================",location["longitude"])
				//console.log(location);
				// this.state.query!='near me'
				 this.setState({query:'near me' });
				this.setState({ isLoading: false });
				this.setState({ lat: location["latitude"] });
				this.setState({ lng: location["longitude"] });
				obj.setState({modelcontent:(<View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35,height:50}}><Text style={styles.name}>Data is getting from server,Please wait..</Text></View>)})
                this.getData(0)
   console.log("========================================================================================")
    //this.setState({ isLoading: false });
            })
            .catch(ex => {
                const { code, message } = ex;
                //console.warn(code, message);
                /*if (code === 'CANCELLED') {
                    Alert.alert('Location cancelled by user or by another request');
                }*/
                if (code === 'UNAVAILABLE') {
                    Alert.alert('Location service is disabled or unavailable');
                }
                if (code === 'TIMEOUT') {
                    Alert.alert('Location request timed out');
                }
                if (code === 'UNAUTHORIZED') {
                    Alert.alert('Authorization denied');
                }
				});
  };
  
  
   clickEventListenerz = (item) => {
	  // this.setState({modelcontent:(<View style={{ backgroundColor:'#ccc',Flex:1,paddingLeft:35}}><Text style={styles.bname}>Location</Text></View>)});return;
	    if(item==0){this.setState({msearch:false});this.setState({modeltitle:'Select Gender of Lawers'});this.setState({modelcontent:this.gendershow()});this.setModalVisible(true)}
		else if(item==1){this.setState({msearch:true});this.setState({modeltitle:'Select Categories'});this.categoriesshow();this.setModalVisible(true)}
		else if(item==2){this.setState({modeltitle:'Search Lawyers within 30km by GPS'});this.requestAccessLocationPermission();this.setState({msearch:false})}
	   };
   
  _handleIndexChange = (index) => this.setState({ index });
  
setModalVisible(visible) {
    this.setState({modalVisible: visible});
  }
 onsearch(o){
	  if(o.nativeEvent.text.length<=0){return}
	  global.obj.page=0
	  global.obj.getData(0,1)
	  global.obj.setState({suggestion:false });
	 console.log(o.nativeEvent.text,'pppppp',this)
 }
 onsearchb(o){
	 this.setState({iskeyboard:false});this.setState({suggestion:false });
	  if(this.state.query.length<=0){
		 Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Search keyword length should be minimum 3 ...',
      text2: 'Search lawyers.',
	  
    });
		 //this.setState({query:'Search keyword length should be minimum 3'})
		 //console.log(this.state.query.length,this.state.query);
		 return
		 }
	 this.state.page=0;this.getData(0,1)
	 console.log('pppppp',o)
 }
 onChangeSearch =(query) => {this.setState({query:query });this.setState({suggestion:true });}
 onChangeText =(query) => {this.setState({iskeyboard:true });}
 onChangeTextblur =(query) => {this.setState({iskeyboard:false});this.setState({suggestion:false });}
 //onIconPress={() => onEndSearchQueryHandler()}
  render() {
   //console.log('-----------------------------------bbbb-------',foo.data().response(this.m));
  const renderScene = ({ route }) => {
    console.log(route.key);
  switch (route.key) {
    case 'first':
      return <FirstRoute foo={this.props.foo} />;
    case 'second':
      return <SecondRoute />;
    default:
      return null;
  }
};//this.props.navigationProps.toggleDrawer();
let dlist=["Civil", "Crime", "FamilyLaw", "PropertyTransfers", "Wills"]

    return (
	<View style={styles.containertop}>
	 <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:1000000}} />
	 <ImageBackground source={require("../assets/rounded-rectangle.png")} style={styles.bg}>
	 <View style={{ flexDirection:'row' , alignItems:'center',backgroundColor:'#fff'}}>
        <TouchableOpacity  onPress={() => {this.props.navigation.openDrawer();}}><Icon name="menu" style={{fontSize: 30 ,color:theme.colors.primary,left:5,marginRight:5}} />
		</TouchableOpacity>
        <TextInput
          placeholder="Search your needs (Name,city,address)                                      "
          keyboardShouldPersistTaps
		  value={this.state.query}
  		  onChangeText={this.onChangeSearch}
	      onSubmitEditing={this.onsearch}
		  onFocus={this.onChangeText}
		  onBlur={this.onChangeTextblur}
        />
      <TouchableOpacity style={{position: 'absolute', right: 5}}  onPress={() => {this.onsearchb(this.state.query);}}>
	  <Icon name="search" style={{fontSize: 25 ,color:theme.colors.primary}} />
	  </TouchableOpacity>
      </View>
	{this.state.suggestion && <View style={{ backgroundColor:'#fff',Flex:1,paddingLeft:35}}>
	<TouchableOpacity  onPress={() => {this.setState({qtype:1 });this.onsearchb('')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>Name : {this.state.query}</Text></TouchableOpacity>
	<TouchableOpacity onPress={() => {this.setState({qtype:2 });this.onsearchb('')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>City : {this.state.query}</Text></TouchableOpacity>
	<TouchableOpacity onPress={() => {this.setState({qtype:3 });this.onsearchb('')}} style={{fontSize: 25 ,color:theme.colors.primary,height:25}}><Text style={styles.name}>Address : {this.state.query}</Text></TouchableOpacity>
	</View>}
	<View style={styles.containerrow}>
	 <TouchableOpacity style={styles.cardbutton1} onPress={() => {this.clickEventListenerz(0)}}><Icon name="options" style={{ fontSize: 25 ,color: 'white',}} />
	 <Text style={styles.bname}>Filter</Text>
	 </TouchableOpacity>
	 <TouchableOpacity style={styles.cardbutton} onPress={() => {this.clickEventListenerz(1)}}><Icon name="aperture" style={{ fontSize: 25 ,color: 'white',}} />
	 <Text style={styles.bname}>Categories</Text>
	 </TouchableOpacity>
	 <TouchableOpacity style={styles.cardbutton} onPress={() => {this.clickEventListenerz(2)}}><Icon name="location" style={{ fontSize: 25 ,color: 'white',}} />
	 <Text style={styles.bname}>Location</Text>
	 </TouchableOpacity>
	</View>
	
     <View style={styles.container}>
          {this.state.nodata && <View style={{height:50,marginTop:150,alignItems: 'center',}} ><Text style={styles.bname1}>No Data Found..</Text></View>}
        {this.state.fdata && <FlatList 
          style={styles.userList}
          columnWrapperStyle={styles.listContainer}
          data={this.state.data}
          keyExtractor= {(item) => {
            return item.id;
          }}
		  onEndReachedThreshold={0.5}
  onEndReached={({ distanceFromEnd }) => {
    console.log('on end reached ', distanceFromEnd)
	console.log('test');
	if(!this.state.iskeyboard && this.state.moredata){
		this.state.page=this.state.page+1;this.getData(1)}
	console.log('test13333333333');
  }}

          renderItem={({item}) => {
		  let st=this.value(1,item.status)
		  let verifyimage=this.value(0,item.verified)
		  let image= SERVER+item.image
		  let dis=item.distance?parseFloat(item.distance).toFixed(2)+' km':null;
		  console.log(image,'pppppppppppppppppppppp');
          return (
            <TouchableOpacity style={styles.card}  key="{item.user_id}">
              <Image style={styles.image} onError={({ nativeEvent: {error} }) => console.log('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',error) } source={{uri: image}}/>
              <View style={styles.cardContent}>
                <View style={{flex: 1, flexDirection: 'row', justifyContent: 'flex-start'}}>
        <View style={{width: '60%', height: 90}} >
		<Text style={styles.name}>{item.name}</Text>
        <View style={{flex: 1, flexDirection: 'row'}} ><Icon name="location" style={{ fontSize: 18 ,color: '#000',}} /><Text style={styles.position}>{item.position} </Text>
		{dis && <Text style={{color:'green',fontWeight:'bold'}}>{dis}</Text>}
		</View>
		
        <View style={{flex: 1, flexDirection: 'row'}} >
        <Icon name="ellipse-sharp" style={{ fontSize: 14 ,color: st[1],marginLeft:3}} /><Text style={styles.position}>{st[0]}</Text></View>
		</View>
        <View style={{width: '27%', height: 100,justifyContent: 'space-between',alignItems: 'center',}}>
		 <Image style={styles.verified} source={verifyimage}/>
     <Button onPress={() => {this._handleProfile(item)}} title="Book" type="clear" />
		 <View style={{flex: 1, flexDirection: 'column',justifyContent: 'space-between',marginTop:10}} ><Rating imageSize={15} readonly startingValue={parseFloat(item.rating)} style={styles.rating} /></View>
		</View>
        
      </View>
              </View>
            </TouchableOpacity>
          )}}/>}

        <Modal
          animationType={'fade'}
          transparent={true}
          onRequestClose={() => this.setModalVisible(false)}
          visible={this.state.modalVisible}>

          <View style={styles.popupOverlay}>
            <View style={styles.popup}>
			  <View style={{height:35,backgroundColor:theme.colors.primary,borderColor:'#fff',borderTopWidth:0.5,borderLeftWidth:1,borderRightWidth:1}}> 
                    <Text style={{color:'#fff',fontSize:15,fontWeight:'bold',marginLeft:15,marginTop:5}}>{this.state.modeltitle}</Text>
              </View>
              <View style={styles.popupContent}>
			  
               <View style={styles.popupContent1}> 
                    {this.state.modelcontent}
              </View>
              </View>
              <View style={styles.popupButtons}>
           
                <Button
  onPress={() => {this.setModalVisible(false) }}
  title="Close" type="clear"
/>
{this.state.msearch && <Button
   style={{marginLeft:25}}
  onPress={() => {this.setModalVisible(false);this.getData(0) }}
  title="Search" type="clear"
/>}
              </View>
            </View>
          </View>
        </Modal>
      </View>
	  </ImageBackground>
	  {this.state.isLoading &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoading} size="large" color={theme.colors.primary} />
   </View>}
     </View>
    );
  }
}

const styles = StyleSheet.create({
  container:{
    flex:1,

  },
  checkboxContainer: {
    flexDirection: "row",
    marginBottom: 20,
  },
  checkbox: {
    alignSelf: "center",
  },
  label: {
    margin: 8,
  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
           
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    
	marginTop:0,
	height:250,
	
	
  }, buttons: {
      flexDirection: 'row',
      paddingVertical: 8
    },
    button: {
      flex: 1,
      alignSelf: 'center'
    },
  userInfo: {
      flexDirection: 'row',
      paddingVertical: 10,
      marginTop:10
    },
bordered: {

      borderTopWidth: 1,
      borderColor: '#ccc',
      borderBottomWidth: 1,
    },
  section: {
      flex: 1,
      alignItems: 'center'
    },
    space: {
      marginBottom: 3,
      color: '#ccc'
    },
  rating:{marginLeft:0},
  modelname:{flexDirection: 'row',
      flex:1,
      alignItems: 'center',marginTop:10,},
	   containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
	  marginTop:0,
   },
  containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
	  marginTop:10,
   },
  containertop:{
    flex:1,
    
	
	
  },
  separator: {
      backgroundColor: '#ccc',
      alignSelf: 'center',
      flexDirection: 'row',
      flex: 0,
      width: 1,
      height: 20
    },
  searchbar:{marginTop:0},
  header:{
    backgroundColor: "#00CED1",
    height:200
  },
  headerContent:{
    padding:30,
    alignItems: 'center',
    flex:1,
  },
  detailContent:{
    top:80,
    height:300,
    width:Dimensions.get('screen').width - 90,
    marginHorizontal:30,
    flexDirection: 'row',
    position:'absolute',
    backgroundColor: "#ffffff"
  },
  userList:{
    flex:1,
  },
  cardContent: {
    marginLeft:10,
    marginTop:5
  },
  image:{
    width:80,
    height:90,
   	marginTop:5
	
  },
  imagemodel:{
    width:80,
    height:90,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
verified:{
    width:80,
    height:20,
   	marginTop:5,
	 
  },

 cardbutton:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '37%',
    padding: 5,

    flexDirection:'row'
  },
  cardbutton1:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '27%',
    paddingLeft: 10,

    flexDirection:'row'
  },
  card:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
    backgroundColor: "#ffffff",
    flexBasis: '46%',
    padding: 5,
	padding: 5,
    flexDirection:'row'
  },
 namemodel:{
    fontSize:14,

  marginLeft:5,
    color:"#000",
    alignSelf:'center',
    fontWeight:'bold',


  },

  name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
	marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  bname:{
    fontSize:17,
    flex:1,
    alignSelf:'flex-start',
	marginLeft:10,
    color:"#fff",
    fontWeight:'bold',

  },
  bname1:{
    fontSize:17,
    flex:1,
   
	marginLeft:10,
    color:theme.colors.primary,
    fontWeight:'bold',

  },
  position:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
	marginLeft:5,
    color:"#696969"
  },
  positionmodel:{
    fontSize:14,
    color:"#696969"
  },
  about:{
    marginHorizontal:10
  },

  followButton: {
    marginTop:10,
    height:35,
    width:100,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius:30,
    backgroundColor: "#00BFFF",
  },
  followButtonText:{
    color: "#FFFFFF",
    fontSize:20,
  },
 /************ modals ************/
  popup: {
    backgroundColor: 'white',
    marginTop: 90,
    marginHorizontal: 0,
    borderRadius: 0,
  },
  popupOverlay: {
    backgroundColor: "#00000057",
    flex: 1,
    marginTop: 10
  },
  popupContent: {
    //alignItems: 'center',
    margin: 5,
	 marginTop: 15,
    
  },
  popupContent1: {
    //alignItems: 'center',
    margin: 5,
	marginTop: 15,
    
  },
  
  popupHeader: {
    marginBottom: 45
  },
  popupButtons: {
    marginTop: 15,
    flexDirection: 'row',
    borderTopWidth: 1,
    borderColor: "#eee",
    justifyContent:'center'

  },
  popupButton: {
    flex: 1,
    marginVertical: 16
  },
  btnClose:{
    height:20,
    backgroundColor:'#20b2aa',
    padding:20
  },
  modalInfo:{
    alignItems:'center',
    justifyContent:'center',
  },
});// JavaScript Document