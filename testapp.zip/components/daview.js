<FlatList 
          style={styles.userList}
          columnWrapperStyle={styles.listContainer}
          data={this.state.data}
          keyExtractor= {(item) => {
            return item.id;
          }}
          renderItem={({item}) => {
		  let st=this.value(1,item.status)
		  let verifyimage=this.value(0,item.verified)
          return (
            <TouchableOpacity style={styles.card} onPress={() => {this.clickEventListener(item)}}>
              <Image style={styles.image} source={{uri: item.image}}/>
              <View style={styles.cardContent}>
                <View style={{flex: 1, flexDirection: 'row', justifyContent: 'flex-start'}}>
        <View style={{width: '60%', height: 90}} >
		<Text style={styles.name}>{item.name}</Text>
        <View style={{flex: 1, flexDirection: 'row'}} ><Icon name="location" style={{ fontSize: 18 ,color: '#000',}} /><Text style={styles.position}>{item.position}</Text></View>
		
        <View style={{flex: 1, flexDirection: 'row'}} >
        <Icon name="ellipse-sharp" style={{ fontSize: 15 ,color: st[1],marginLeft:5}} /><Text style={styles.position}>{st[0]}</Text></View>
		</View>
        <View style={{width: '27%', height: 100,justifyContent: 'space-between',alignItems: 'center',}}>
		 <Image style={styles.verified} source={verifyimage}/>
     <Button onPress={() => {this._handleProfile(item)}} title="Book" type="clear" />
		 <View style={{flex: 1, flexDirection: 'column',justifyContent: 'space-between',marginTop:10}} ><Rating imageSize={15} readonly startingValue={item.rating} style={styles.rating} /></View>
		</View>
        
      </View>
              </View>
            </TouchableOpacity>
          )}}/>// JavaScript Document