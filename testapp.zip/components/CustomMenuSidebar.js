import React, { Component } from 'react';
import { View, StyleSheet, Image, Text ,TouchableOpacity} from 'react-native';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import  config  from '../core/global';
import { MENU } from '../core/settings';
import { SERVER_URL,SERVER } from '../core/settings'
// Define a variable for selected screen index
global.selectedScreenIndex = 0;
const logo = require('./image/logo.jpg');

export default class CustomMenuSidebar extends Component {
  constructor(props,navigation) {
    super();
    // Main Top Large Image of the Custom Sidebar
    this.headerImage = '';
	this.state ={
      showmenu:true,photouri:null,photo:{uri:Image.resolveAssetSource(logo).uri},
	}
	  
	  
    // OptionsList which will used in map loop in render method 
	console.log('===========================================================================================================================',MENU)
    this.optionsList =MENU;
  }
componentDidMount() {
  if(typeof(config.profile)!='undefined'){this.setState({photouri:SERVER+config.profile.image});}
  else{this.setState({photouri:this.state.photo.uri});}
}
 async logout(){let keys = ['uid', 'scrren','session','id'];
					await AsyncStorage.multiRemove(keys, (err) => {
					
					});config.profile=null; config.uinfo=null;config.settings=null;}
  drawer(){console.log('clicked');this.props.navigation.goBack()}
  ck(){
   let mlist=[]
   
   this.optionsList.map((item, key) => {
   let isvalid=true
   if('islogin' in item){if(item['islogin']!=config.settings.login){isvalid=false}}
   if('custom' in item){
    let kys=Object.keys(item['custom']);
    kys.map((v, key) => {if(item['custom'][v]!=config.settings[v]){isvalid=false}});}
	console.log(item['custom'],'=>>>>>>',item.navOptionTitle,'0000000000000',isvalid,config.settings);
    if(isvalid){mlist[key]=item}})
   return mlist
  }
  render() {
	
    let optionsList=this.ck()
	
    return (
	 <>
	   {config.menu==false &&(<View style={styles.containerSideMenu}>
		
		<Image
          source={{ uri: this.state.photouri}}
          style={styles.headerStyle}
        />
		<Text style={[styles.socialbtntxt,{color:'#fff'}]}>Please login</Text>
		</View>)
	   }
      {config.menu &&(<View style={styles.containerSideMenu}>
        {/*Navigation Bar header  Image */}
		
        <Image
          source={{ uri: this.state.photouri}}
          style={styles.headerStyle}
        />
        {/*Divider between header Image and options*/}
        <View
          style={{
            width: '100%',
            height: 1,
            backgroundColor: '#e2e2e2',
            marginTop: 15,
          }}
        />
        {/*Setting up Navigation Options from jsonArray using loop*/}
        <View style={{ width: '100%' }}>
          {optionsList.map((item, key) => (
            
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingTop: 10,
                paddingBottom: 10,
                backgroundColor: global.selectedScreenIndex === key ? '#e0dbdb' : '#ffffff',
              }} key={item.navOptionTitle}>
              <View style={{ marginRight: 10, marginLeft: 20 }}>
                <Icon name={item.navOptionIcon}  size={25} color="#808080" />
              </View>
              <Text
                style={{
                  fontSize: 15,
                  color: global.selectedScreenIndex === key ? 'blue' : 'black',
                }}
                onPress={() => {
                  global.selectedScreenIndex = key;
				  if(item.screenToNavigate=='otp'){
					this.logout();
					console.log("cleared logout");
					  }
                   //console.log(item.navOptionTitle,this.props.navi.navigate);
				  this.props.navi.navigate(item.screenToNavigate)
                }}>
                {item.navOptionTitle}
              </Text>
            </View>
          ))}
        </View>
      </View>)}
	  </>
    );
  }
}
const styles = StyleSheet.create({
   headerStyle: {
    resizeMode: 'cover',
	borderRadius:75,
    width: 150,
    height: 150,
  },
  containerSideMenu: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    alignItems: 'center',
    paddingTop: 20,
  }
 
});