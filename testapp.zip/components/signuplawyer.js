import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
//18001031212 
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { Modal , RadioButton , HelperText} from 'react-native-paper';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'
import Button from '../helper/Button'
import BackButton from '../helper/BackButton'
import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL } from '../core/settings'
import {emailValidator} from '../helper/emailValidator'
import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
//Define a color for toolbar
global.backgroundColor = '#176abf';
var { findNodeHandle } = React;
type Props = {};
export default class Home extends Component<Props> {
constructor() {
    super();
	
    this.state ={
      isLoging:false,
      checkingAuth:true,
      email:"",
      password:"",
	  visibleAlert:false,
	  name:"",
	  uid:"",
	  mobile:"",
	  address:"",
	  firstname:"",
	  lastname:"",
	  gender:"male",
      activecolor:"#000",
	  malebg:'#2980B9',
	  femalebg:'#ccc',
	  nameError:'',
	  lastError:'',
	  role:2,
	  addressError:'',
	  mobileError:'',
	  visible:true,
	  
    }
	
  }
   
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
	  if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
	  this.setState({ gender: v});
  }
  async setitems(responseJson)
  {
	
	/*await AsyncStorage.setItem('uid', responseJson['uid']);
	await AsyncStorage.setItem('session', responseJson['session']);
	await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222",responseJson['role'].toString());
	await AsyncStorage.setItem('role', responseJson['role'].toString());

	AsyncStorage.flushGetRequests();*/
	console.log("==================================<<<<<<<<<<<<<<<",responseJson['uid']);
	Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully Account Updated...',
      text2: ' loading home page...',
	  onHide: () => {this.props.navigation.navigate('address')},
    }); 
	
  }
  showAlert1(n) { 
        this.setState({role:n})
        Alert.alert(  
            'Confirm to save',  
            'Are you sure to continue?',  
            [  
                {  
                    text: 'Cancel',  
                    onPress: () => this.setState({visible:false}),  
                    style: 'cancel',  
                },  
                {text: 'OK', onPress: () =>this.requestUserSignup(3) },  
            ]  
        );  
    } 
  async requestUserSignup(n) {
	//const { navigation } = this.props;
	 this.setState({visible:false});console.log(this.state.role);
	let uid=await AsyncStorage.getItem('uid');
	//console.log(itemId)
	//console.log(this.props.route)
   
	 //this.setState({ nameError: "Invalid Name" });
	 console.log("looooooooooooooooooooding.",this.state.lastname ,"|" , this.state.address,"-", this.state.name);
	 if(this.state.name == "" || this.state.name.length<4){this.setState({ nameError: "Invalid name or name lenth must be > 4" });}else{this.setState({ nameError: "" });}
	 if(this.state.lastname == "" || this.state.lastname.length<4){this.setState({ lastnameError: "Invalid last name or lenth must be > 4" });}
	 else{this.setState({ lastnameError: "" });}
	
	if(this.state.address=="" || this.state.address.length<4){this.setState({ addressError: "Invalid address or lenth must be > 4" });return false}else{this.setState({ addressError: "" });}
	 
	console.log("looooooooooooooooooooding.",this.state.lastname ,"|" , this.state.address,"-", this.state.name);
	 if(this.state.lastname != "" && this.state.address!="" && this.state.name!=""){
		 console.log("looooooooooooooooooooding.");
		 this.setState({ isLoging: true });
	var formData = new FormData();
	    formData.append('username',this.state.name+' '+ this.state.lastname);
		formData.append('display_name', this.state.name+' '+ this.state.lastname);
        formData.append('first_name', this.state.name);
        formData.append('last_name', this.state.lastname);
		formData.append('address_p', this.state.address);
		formData.append('uid', uid);
		formData.append('gender', this.state.gender);
		formData.append('role',this.state.role); 
		console.log('post data:',formData);
	fetch(SERVER_URL+'?op=register', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.json())
      .then((responseJson) => {
			  console.log('-----',responseJson);this.setState({ isLoging: false });
			  
			 if(responseJson['result']==true)
		 {
			 this.setitems(responseJson);
			 
			
		 }
		 else{
			 
		
			Toast.show({
	  type: 'error',
	  position: 'top',
      text1: responseJson['errors'],
      text2: 'Please check ',
	  
    }); 
			 }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
			  alert(error);
         console.error(error);
      });	 
	 }
	 else {
      Alert.alert("Error", "fields are required")
    }
    //this.props.navigation.navigate('homeScreen');
	
	
  }
  render() {
    //const { route } = this.props
        //const { loveOne } = route.params;
		
     const hideDialog = () => {setState({visible:false}); } 
    return (
	 
     <Background>
	 <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:1000}} />
	
      <Logo />
      <Header>Create Account</Header>
     

  <TextInput
	   
        label="First Name"
        returnKeyType="next"
        onChangeText={name => this.setState({name})}
        errorText={this.state.nameError}
	 
      />

     <TextInput
	   
        label="Last Name"
        returnKeyType="next"
        onChangeText={lastname => this.setState({lastname})}
        errorText={this.state.lastError}
	 
      />
	  <TextInput
        label="Address"
        returnKeyType="next"
        onChangeText={address => this.setState({address})}
        autoCapitalize="none"
        autoCompleteType="email"
        textContentType="emailAddress"
        keyboardType="email-address"
		errorText={this.state.addressError}
      />

	
	<View style={{ flexDirection: "row" }}>
     <View style={{ flex: 1 }}>
         <TouchableOpacity style={{ alignSelf: 'stretch',backgroundColor: this.state.malebg }} onPress={() => this.cgender('male')}>
              <Text style={{ alignSelf: 'center',
                            color: '#ffffff',
                            fontSize: 16,
                            fontWeight: '600',
                            paddingTop: 10,
                            paddingBottom: 10 }}>Male</Text>
         </TouchableOpacity>
     </View>
     <View style={{borderLeftWidth: 1,borderLeftColor: 'white'}}/>
     <View style={{ flex: 1}}>
         <TouchableOpacity style={{ alignSelf: 'stretch',backgroundColor: this.state.femalebg}} onPress={() =>this.cgender('female')}>
              <Text style={{ alignSelf: 'center',
                            color: '#ffffff',
                            fontSize: 16,
                            fontWeight: '600',
                            paddingTop: 10,
                            paddingBottom: 10 }}>Female</Text>
         </TouchableOpacity>
     </View>
 </View>
  
      <Button
        mode="contained"
         onPress={() => this.showAlert1(3)}
        style={{ marginTop: 10 }}
      >
        Sign Up as Client
      </Button>
	  <Button
        mode="contained"
         onPress={() => this.showAlert1(2)}
       
      >
        Sign Up as Lawyer
      </Button>
      
	   {this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
    </Background>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    position: 'absolute',
    top: 10 + getStatusBarHeight(),
    left: 4,
  },
  image: {
    width: 24,
    height: 24,
  },
  radio: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
   loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  radioContainer: {
    height: 20,
    width: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputs : {
    borderRadius:25,
    backgroundColor:'#fff',
    width:80+'%',
    paddingHorizontal:25,
    fontSize:16,
    marginTop:20
  },
   row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
});