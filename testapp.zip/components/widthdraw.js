import React, {Component} from 'react';
import {Platform,  Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions,Modal,ScrollView, StatusBar} from 'react-native';
import { theme } from '../core/theme'
import Icon from 'react-native-vector-icons/Ionicons';
import {TextInput,List} from 'react-native-paper';
import RNDateTimePicker from '@react-native-community/datetimepicker';
import { Button} from 'react-native-elements';
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import lib from '../core/lib'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

type Props = {};
const statuscol=['blue','green','red','red','green','red'];
export default class transections extends Component<Props> {
	constructor(route, navigation ,props) {
    super(props);
    this.state ={
      isLoging:false,balance:0,adata:null,olddata:null,modalVisible:false,amount:1,bdetails:"",
      checkingAuth:true,cancelmodel:false,show:false,datetxt:null,ac:null,ifsc:'',
	  }
	}
dChange = (event, d) => {
	if(event.type != "set") {
    return
    } 
    const currentDate = d || this.state.datetxt;console.log(d);this.setState({ isLoading:true });
    //setShow(Platform.OS === 'ios');
    this.setState({datetxt:d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate(),show: Platform.OS === 'ios' ? true : false,});// this.setState({show:false});
	let op={'success':function(d){obj.setState({ isLoading: false });
	let info =d['data'];console.log(info);obj.setState({ balance: d.balance });
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let ds=config.uinfo;
	 let pd={'session':ds[2],'uid':ds[0],'date':this.state.datetxt}
	 lib.postdata('?op=getWidthdraws',pd,op);
	return true
  };
  apconfirm(item,i)
  {this.setState({ isLoading:true });
	 let op={'success':function(d){obj.setState({ isLoading: false });
	 obj.state.olddata[i]['status']=3;obj.state.olddata[i]['statustxt']="Cancelled by you"
	 let dd=obj.state.olddata;
	 obj.showlist(dd);
	 },'type':'text','trace':true}

	  let ds=config.uinfo;
	 let pd={'session':ds[2],'uid':ds[0],'id':item.id}
	 lib.postdata('?op=cancelwidthdrawRequest',pd,op); 
  }
  _handleProfile(item,n=0){
	  Alert.alert( "Widthdrawel Request","Are you sure to Cancel?",[
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        { text: "OK", onPress: () => {this.apconfirm(item,n)}}
      ],
      { cancelable: false })
	  }
componentDidMount() {
	 global.obj=this;let ds=config.uinfo;this.setState({ isLoading:true });
	 let op={'success':function(d){obj.setState({ isLoading: false });console.log(d);
	 let info =d['data'];console.log(info);obj.setState({ balance: d.balance });
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let pd={'session':ds[2],'uid':ds[0]}
	 lib.postdata('?op=getWidthdraws',pd,op);config.obj=this;
}
setModalVisible(visible) {
    this.setState({modalVisible: visible});
  }
 showlist(data){
	   //console.log(data,data.length)
	 if(!data || data.length==0){this.setState({adata:(<View style={{alignItems:"center",marginTop: 10,}}><Text style={{marginTop: 10,fontSize: 20 }}>No Data Available.</Text></View>)});return}
	 
	 let rd= data.map((item, index) => {
					   let cols={marginLeft: 0,fontSize: 16 ,color:statuscol[item.status]};
					   let canc=item.status==0?(<TouchableOpacity onPress={() => {this._handleProfile(item,index)}}>
				 <Text style={{fontSize: 20,fontWeight:"bold",color: theme.colors.secondary}} >Cancel</Text>
	 
				 </TouchableOpacity>):null;
				return(<View style={{backgroundColor:"#fff",paddingBottom:10}} key={index}>
					   
				 <View style={{borderBottomWidth:1,borderBottomColor:"#ccc"}}>
				  <View style={[styles.catrow,backgroundColor:"#ccc"]}>
				 <Icon style={{ width: 25, height: 25, marginLeft: 5,marginRight: 5}}  name="calendar-outline" size={25} color="#000" />				
				 <View style={{alignItems:"flex-start",justifyContent: 'flex-start',width:"40%"}}>
				<Text style={{marginLeft: 10,fontSize: 20,fontWeight:"bold" }}  >
					{'\u20B9'}{item.amount}
				</Text></View>
				
				<View style={{alignItems:"flex-end",justifyContent: 'flex-end',width:"45%"}}>
					 {canc}
				</View>
				</View>
				<View style={{marginLeft:45,marginRight:10,paddingBottom:5,flexDirection: 'row',}}>
				 <View  style={{width:"50%"}}><Text style={{fontSize: 15}}  >Date : {item.created_at}</Text></View>
				 <View  style={{width:"45%",alignItems:"flex-end",justifyContent: 'flex-end'}}><Text style={cols}  >{item.statustxt}</Text></View>
				 
				  
				  
				  </View>
				 
					  
				</View>
                </View>)
              
            }); 
	 
	 this.setState({olddata:data});
	//console.log("$$$$$$$$$$$$$$$>>>>",this.state.olddata);
	 this.setState({adata:rd}); 
   }
   wrequest(){
	   if(parseFloat(this.state.amount)<300){alert("you can widthdraw minimum : 300");return}
	    if(this.state.ac.length<=5){alert("invalid bank account number");return}
		 if(this.state.ifsc.length<=5){alert("invalid ifsc code");return}
		  if(this.state.bdetails.length<3){alert("invalid bank name");return}
	   let o=this.state;
	   let note="Account No : "+o.ac+" \n";
	       note+="IFSC Code : "+o.ifsc+" \n";
		   note+="Bank : "+o.bdetails+" \n";
	 this.setState({ isLoading:true });
	 let op={'success':function(d){obj.setState({ isLoading: false });console.log(d);
	 let info =d['data'];
	 obj.setState({modalVisible: false});
	 obj.showlist(info);
	 },'type':'json','trace':true}

	  let ds=config.uinfo;
	 let pd={'session':ds[2],'uid':ds[0],'amount':o.amount,'note':note,'account':o.ac,'ifsc':o.ifsc}
	 lib.postdata('?op=widthdrawRequest',pd,op); 
	   console.log(this.state.amount,this.state.bdetails)
   }
  render() {
	 
	 let gbk=config.settings.role==2?'appoinment':'homeScreen';
	  
    return (
      <View style={{height:"100%"}}>
	  
	   <View style={{height:70,backgroundColor:theme.colors.primary,width:"100%"}}>
	   <TouchableOpacity onPress={()=>{this.props.navigation.navigate(gbk);;}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: '#fff',}} /> 
   </TouchableOpacity>
  <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18}}>
  <Text style={styles.textStyle}>
              Balance : {'\u20B9'}{this.state.balance}
            </Text> </Text></View>
       </View> 
 

<View style={{marginTop:2}}>
<TextInput
      label="Select Date"
      value={this.state.datetxt}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({show:true}) }} />}
    />              
         {this.state.show && (<RNDateTimePicker value={new Date()} minuteInterval={5} onChange={this.dChange} />)}
</View>
    <ScrollView style={styles.scrollView}><View style={{paddingBottom:70}}>{this.state.adata}</View></ScrollView>
	 {this.state.isLoading &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoading} size="large" color={theme.colors.primary} />
   </View>}
   	<Modal
          animationType={'fade'}
          transparent={true}
          onRequestClose={() => this.setModalVisible(false)}
          visible={this.state.modalVisible}>

          <View style={styles.popupOverlay}>
            <View style={styles.popup}>
			  <View style={{height:35,backgroundColor:theme.colors.primary,borderColor:'#fff',borderTopWidth:0.5,borderLeftWidth:1,borderRightWidth:1}}> 
                    <Text style={{color:'#fff',fontSize:15,fontWeight:'bold',marginLeft:15,marginTop:5}}>New Widthdrawel Request</Text>
              </View>
              <View style={styles.popupContent}>
			  
               <View style={styles.popupContent1}> 
			  <TextInput
      label="Amount"
      
	  keyboardType='numeric'
	  onChangeText={text =>this.setState({amount:text}) }
      right={<TextInput.Icon name="calendar-outline" />}
    />  
	<TextInput
      label="Account No"
     
	  keyboardType='numeric'
	  onChangeText={text =>this.setState({ac:text}) }
      right={<TextInput.Icon name="calendar-outline"  />}
    />   
	<TextInput
      label="IFSC Code"
      
	  
	  onChangeText={text =>this.setState({ifsc:text}) }
      right={<TextInput.Icon name="calendar-outline"  />}
    />         
      <TextInput
      label="Bank name and address"
	   multiline={true} 
	   numberOfLines={10}
	   autoCorrect={false}
       spellCheck={false}
	   onChangeText={text =>this.setState({bdetails:text}) }
      value={this.state.bdetails}
      right={<TextInput.Icon name="account-alert-outline"  />}
    />             
    
				
              </View>
              </View>
              <View style={styles.popupButtons}>
			  <Button
  onPress={() => {this.setModalVisible(false) }}
  title="Close" type="clear"
/>
   <Button
  onPress={() => {this.wrequest() }}
  title="Save Request" type="clear"
/>         
			</View>
            </View>
          </View>
        </Modal>
		<View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.setModalVisible(true);}}>
		   <Text style={styles.textStyle}><Icon name="add-circle-outline" size={35} color="#fff" /> </Text>
		    </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  bottomView: {
    width: 75,
    height: 75,
	borderRadius: 150,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute', //Here is the trick
    bottom: 25, //Here is the trick
	right:25,
	paddingLeft:5

  },
    loading: {
    position: 'absolute',
            left: 0,
            right: 0,
           
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  scrollView: {
    backgroundColor: '#fff',
    marginHorizontal: 5,
	
  },
  popup: {
    backgroundColor: 'white',
    marginTop: 90,
    marginHorizontal: 0,
    borderRadius: 0,
  },
  popupOverlay: {
    backgroundColor: "#00000057",
    flex: 1,
    marginTop: 10
  },
  popupContent: {
    //alignItems: 'center',
    margin: 5,
	 marginTop: 15,
    
  },
  popupContent1: {
    //alignItems: 'center',
    margin: 5,
	marginTop: 15,
    
  },
  
  popupHeader: {
    marginBottom: 45
  },
  popupButtons: {
    marginTop: 15,
    flexDirection: 'row',
    borderTopWidth: 1,
    borderColor: "#eee",
    justifyContent:'center'

  },
  popupButton: {
    flex: 1,
    marginVertical: 16
  },
  catrow: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      
    },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  imageback: {
    width: 24,
    height: 24,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});