import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions ,
  Modal,ScrollView} from 'react-native';
 import {useRoute} from '@react-navigation/native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { Rating,Button,PricingCard} from 'react-native-elements';
import {RadioButton , HelperText} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Ionicons';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'

import BackButton from '../helper/BackButton'
import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL,SERVER } from '../core/settings'

import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
import { TabView, SceneMap , TabBar } from 'react-native-tab-view';
//Define a color for toolbar

var { findNodeHandle } = React;
//type Props = {};
const FirstRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const SecondRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const initialLayout = { width: Dimensions.get('screen').width,height:30 };
export default class profile extends Component<Props> {
constructor(route, navigation ,props) {
    super(props);
    this.bn()
    this.state ={
      isLoging:false,
      checkingAuth:true,
      email:"",
      password:"",
    name:"",
    cwt:0,
    mobile:"",
    gender:"male",
      activecolor:"#000",
    malebg:'#2980B9',
    femalebg:'#ccc',
    nameError:'',
    psswordError:'',
    emailError:'',
    mobileError:'',
    userSelected:{},
    routes:[
    { key: 'first', title: 'About' },
    { key: 'second', title: 'Review' },
    { key: 'category', title: 'Category' },
    
  ],index:0, setIndex:0,
    }
  
  }
   showlist(data){
	 if(!data){return (<Text style={{marginLeft: 10,fontSize: 20 }}>No Data Available.</Text>)}
	 let rd= data.map((item, index) => {
					  if(item!=""){
				return(<View style={styles.row} key={index}>
					   
				 <View style={styles.col}>
				  <View style={styles.catrow}>
				 <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-sync-circle" size={25} color="#000" />
				<Text style={{marginLeft: 10,fontSize: 20 }}>
					{item}
				</Text>
				</View>
				</View>
                </View>)}
              
            });  
	return rd;   
   }
   
   showreview(data){
	 if(!data){return (<Text style={{marginLeft: 10,fontSize: 20 }}>No Data Available.</Text>)}
	 let rd= data.map((item, index) => {
					  // console.log("==============>",item);
				let image= SERVER+item.image
				return(<View style={styles.row} key={index}>   
				 <View style={styles.col}>
				  <View style={styles.catrow}>
				 <View>
				<Image style={styles.image} source={{uri:image}}/>
				<Rating imageSize={15} readonly startingValue={parseFloat(item.rating)} style={styles.rating,{marginTop:10}} />
				</View>
				<View>
				<Text style={{marginLeft: 10,fontSize: 20,color:"#000",fontWeight:'bold',}}>{item.name}</Text>
				<Text style={{marginLeft: 10,fontSize: 15,justifyContent: 'center',marginRight:10}}>{item.text}</Text>
				</View>
				</View>
				</View>
                </View>)
              
            });  
	return rd;   
   }
   bn() {
//this.setState({userSelected:this.props.route.params});
  return true 
}
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
    if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
    this.setState({ gender: v});
  }
  async setitems(responseJson)
  {
  //console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson['uid'],responseJson['session'],responseJson['id']);
  await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
  await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
  await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
  await AsyncStorage.setItem('role', responseJson['role'].toString());

  AsyncStorage.flushGetRequests();
  //console.log("==================================<<<<<<<<<<<<<<<",responseJson['uid']);
  Toast.show({
    position: 'top',
    visibilityTime: 100,
      text1: 'Successfully Account Created...',
      text2: 'created for user login',
    onHide: () => {this.props.navigation.navigate('address')},
    }); 
  
  }
  async requestUserSignup() {
  const { navigation } = this.props;
  this.setState({ isLoging: true });
  //console.log(itemId)
  //console.log(this.props.route)
   
   //this.setState({ nameError: "Invalid Name" });
    //alert(SERVER_URL);
   if(this.state.name == "" || this.state.name.length<=4){this.setState({ nameError: "Invalid name or text min lenth 4" });}else{this.setState({ nameError: "" });}
   if(this.state.password == "" || this.state.password.length<6){this.setState({ passwordError: "Invalid password or text min lenth 6" });}
   else{this.setState({ passwordError: "" });}
   if(emailValidator(this.state.email)!= ""){this.setState({ emailError: "Invalid email" });return false}else{this.setState({ emailError: "" });}
   if(this.state.mobile == "" || this.state.mobile.length<=9){this.setState({ mobileError: "Invalid mobile" });}else{this.setState({ mobileError: "" });}
  
   if(this.state.email != "" && this.state.password!="" && this.state.mobile!="" && this.state.name!=""){
  var formData = new FormData();
      formData.append('username', this.state.name);
    formData.append('display_name', this.state.name);
        formData.append('Email_Address', this.state.email);
        formData.append('password', this.state.password);
    formData.append('Mobile', this.state.mobile);
    formData.append('gender', this.state.gender);
    formData.append('role', "4"); 
    console.log(formData);
  fetch(SERVER_URL+'?op=register', {
         method: 'POST',
     headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.text())
      .then((responseJsontx) => {
       var responseJson={}
        try{responseJson=JSON.parse(responseJsontx)}catch(e){alert(responseJsontx);responseJson={'result':false,'error':'erroe in page'}}
        
        console.log('-----',responseJson);
        this.setState({ isLoging: false });
       if(responseJson['result']==true)
     {
       this.setitems(responseJson);
       
      
     }
     else{
       
    
      Toast.show({
    type: 'error',
    position: 'top',
      text1: responseJson['errors'],
      text2: 'Please check ',
    
    }); 
       }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
        alert(SERVER_URL+" , "+error);
         console.error(error);
      });  
   }
   else {
     // Alert.alert("Error", "fields are required")
    }
    //this.props.navigation.navigate('homeScreen');
  }
  _handleIndexChange = index => this.setState({ index });

  _renderHeader = props => <TabBar {...props} />;

  _renderScene =  ({ route }) => {
  console.log('===================------------------------------',this.props.route.params.data)
   let info=this.props.route.params.data
   let rev=this.props.route.params.data['review']
   let cat=this.props.route.params.data['category']
  switch (route.key) {
    case 'first':
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:20,paddingLeft:20,paddingTop:20 } ]}>
        <Text style={{color:'#000',alignSelf:'flex-start'}}>{info.about}</Text>
              </View>
        );
    case 'second':
	console.log('===================',route.key)
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:5,paddingLeft:5,paddingTop:20 } ]}>
        <ScrollView contentContainerStyle={styles.modalInfo,{marginRight:5}}>{this.showreview(rev)}</ScrollView>
              </View>
        );
    case 'category':
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:20,paddingLeft:20,paddingTop:20 } ]}>
        <ScrollView contentContainerStyle={styles.modalInfo}>{this.showlist(cat.split(','))}</ScrollView>
              </View>
        );
    default:
      return null;
  }
};
async getitems()
{
  let uid=await AsyncStorage.getItem('udatax');

  return uid
}

 //async componentDidMount() {this.setState({userSelected:this.props.route.params});}
  render() {
    //const { route } = this.props
  
    
   console.log("<>",this.props.route.params,"<>")
   let info=this.props.route.params.data;console.log("idddddddddddddddddd",info['id']);
   let image= SERVER+info.image
    return (
    <View style={styles.container1}>
    <View style={{backgroundColor:theme.colors.primary}}> 
   
   <TouchableOpacity onPress={()=>{this.props.navigation.navigate('homeScreen');}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: 'white',}} />
   </TouchableOpacity>
    <View style={styles.modalInfo}>
<View style={{alignItems:'center',height:180,paddingTop:0}}>
                  <Image style={styles.imagemodel} source={{uri: image}}/>
                  <View style={styles.modelname}>
                  <Text style={styles.namemodel}>{info.name}</Text>
                  <View style={{flexDirection: 'row',  marginLeft:25,}} ><Icon name="location" style={{ fontSize: 13 ,color: '#fff',marginTop:5}} /><Text style={styles.positionmodel}>{info.position}</Text></View>
                  </View>
                </View>
    </View>
    <View style={[styles.userInfo, styles.bordered]}>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Experience
                            </Text>
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              {info.rating}
                            </Text>
                            <Rating imageSize={15} readonly startingValue={parseFloat(info.rating)} style={styles.rating} />
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Contacted
                            </Text>
                          </View>
                        </View>
       <View style={styles.buttons}>
                      <Button title="Video Chat" type="clear"/>
                      <View style={styles.separator} />
                      <Button title="Contact Number" type="clear"/>
                      <View style={styles.separator} />
                      <Button title="Schedule" onPress={()=>{this.props.navigation.navigate('newappoinment',{lid:info['id'],uinfo:info});}}  type="clear"/>
                      </View>
    </View> 
    <TabView
        style={styles.container1}
        navigationState={this.state}
        renderScene={this._renderScene}
         renderHeader={this._renderHeader}
         initialLayout={{ width: Dimensions.get('window').width }}
        onIndexChange={this._handleIndexChange}
         renderTabBar={props => (
          <TabBar
            {...props}
            renderLabel={this._renderLabel}
            getLabelText={({ route: { title } }) => title}
            indicatorStyle={styles.indicator}
            tabStyle={styles.tabStyle}
            style={styles.tab}
          />
        )}
      /> 
      </View>
    );
  }
}

const styles = StyleSheet.create({
   
container1: {
    flex: 1,
  },
  scene: {
    flex: 1,
  },
  imageback: {
    width: 24,
    height: 24,
  },
   tabStyle: {
 
    backgroundColor: theme.colors.secondary,
  },
  modalInfo:{
    alignItems:'center',
    paddingTop:10,
  },
  topbg:{backgroundColor:theme.primary},
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.5,
    zIndex:1000000,
    justifyContent: 'center',
    alignItems: 'center'
  },
 container:{
    flex:1,

  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    backgroundColor:'#fff',
  marginTop:-10,
  height:170,
  
  
  }, buttons: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      justifyContent: 'center',
    },
	 catrow: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      
    },
    button: {
      flex: 1,
      alignSelf: 'center'
    },
  userInfo: {
      flexDirection: 'row',
      paddingVertical: 10,
      marginTop:10,
      backgroundColor:'#ffffff'
    },
bordered: {

      borderTopWidth: 1,
      borderColor: '#ccc',
      borderBottomWidth: 1,
    },
  section: {
      flex: 1,
      alignItems: 'center'
    },
    space: {
      marginBottom: 3,
      color: '#ccc'
    },
  rating:{marginLeft:0},
  modelname:{flexDirection: 'row',
      flex:1,
      alignItems: 'center',marginTop:10,},
  containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
    marginTop:10,
   },
  containertop:{
    flex:1,
    
  
  
  },
  separator: {
      backgroundColor: '#ccc',
      alignSelf: 'center',
      flexDirection: 'row',
      flex: 0,
      width: 1,
      height: 20
    },
  searchbar:{marginTop:0},
  header:{
    backgroundColor: "#00CED1",
    height:200
  },
  headerContent:{
    padding:30,
    alignItems: 'center',
    flex:1,
  },
  detailContent:{
    top:80,
    height:300,
    width:Dimensions.get('screen').width - 90,
    marginHorizontal:30,
    flexDirection: 'row',
    position:'absolute',
    backgroundColor: "#ffffff"
  },
  userList:{
    flex:1,
  },
  cardContent: {
    marginLeft:10,
    marginTop:5
  },
  image:{
    width:80,
    height:90,
    marginTop:5
  
  },
  imagemodel:{
    width:150,
    height:150,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
verified:{
    width:80,
    height:20,
    marginTop:5,
   
  },
modalInfo:{

    justifyContent:'center',
  },
 cardbutton:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '37%',
    padding: 5,

    flexDirection:'row'
  },
  cardbutton1:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '27%',
    paddingLeft: 10,

    flexDirection:'row'
  },
  card:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
    backgroundColor: "#ffffff",
    flexBasis: '46%',
    padding: 5,
  padding: 5,
    flexDirection:'row'
  },
 namemodel:{
    fontSize:14,

  marginLeft:5,
    color:"#fff",
    alignSelf:'center',
    fontWeight:'bold',


  },

  name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  bname:{
    fontSize:17,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:10,
    color:"#fff",
    fontWeight:'bold',

  },
  position:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#696969"
  },
  positionmodel:{
    fontSize:14,
    color:"#fff"
  },
  about:{
    marginHorizontal:10
  },

});