import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height'

import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import { Modal , RadioButton , HelperText} from 'react-native-paper';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'
import Submit from '../helper/Submit'
import BackButton from '../helper/BackButton'
import Textnew from '../helper/Textnew'
import Form from '../helper/Form'
import Header from '../helper/Header'

import { theme } from '../core/theme'
import { SERVER_URL,SMS_URL } from '../core/settings'
import {emailValidator} from '../helper/emailValidator'
import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
//Define a color for toolbar
global.backgroundColor = '#176abf';
var { findNodeHandle } = React;
type Props = {};
export default class Home extends Component<Props> {
constructor() {
    super();
	GLOBAL.data['test']=this; 
    this.state ={
      isLoging:false,
	  sendsmsval: false,
      checkingAuth:true,
	  resend:false,
	  otpnumber:"",
      email:"",
      password:"",
	  name:"",
	  counter:30,
	  mobileotp:"",
	  udata:null,
	  udatau:0,
	  timer: null,
	  mobile:"",
	  gender:"male",
      activecolor:"#000",
	  malebg:'#2980B9',
	  femalebg:'#ccc',
	  nameError:'',
	  psswordError:'',
	  emailError:'',
	  mobileError:'',
    }
	
  }
  
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
 
  shuffle(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

  random4(){
  return this.shuffle( "0123456789".split('') ).join('').substring(0,4);
}
  sendsms(n) {
	  if(n==0){
	  let otpnumber= this.random4()
	  this.setState({ otpnumber: otpnumber });
	  this.setState({ sendsmsval: true });
	  let url=SMS_URL.replace('m',this.state.mobile);url=url.replace('msg',' Juristz OTP is '+otpnumber)
	  fetch(SERVER_URL+'?op=smsotp&id='+otpnumber+'&m='+this.state.mobile, {
         method: 'GET',
      })
      .then((response) => response.json())
      .then((responseJson) => {
		
         console.log(responseJson);
		this.state.udate=responseJson;this.state.udateu=1;
          console.log(this.state.udata);
      })
      .catch((error) => {
         console.error(error);
      });	 
	 
	  let timer = setInterval(this.tick, 1000);
      this.setState({timer});
	  this.setState({
      resend: false
    });
	  }
      else{
		   if(this.state.mobileotp==this.state.otpnumber){clearInterval(this.state.timer);
		   if(this.state.udateu==0){
			   Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Service is busy...',
      text2: ' please wait or click once again',
	  
    }); 
			  }
		   console.log('ZZZZZZZ',this.state.udateu);
		   console.log(this.state.udate);
		    this.setitems(this.state.udate);
		    if(this.state.udate['status']=='exist'){this.props.navigation.navigate('homeScreen');}
			else{this.props.navigation.navigate('signuplawyer');}
		   }else{
		   Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Invalid OTP...',
      text2: ' Please verify sms',
	  
    }); 
		   }
		  }
	  
  }
  async setitems(responseJson)
  {
	//console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson['uid'],responseJson['session'],responseJson['id']);
	await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
	await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
	await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
	await AsyncStorage.setItem('role', responseJson['role'].toString());

	AsyncStorage.flushGetRequests();
	
  }
 call=()=>{console.log('called xxxxxxxxxxxxx');alert("calleddddd");}
 tick =() => {
    this.setState({
      counter: this.state.counter - 1
    });
	if(this.state.counter<=0){clearInterval(this.state.timer);
	this.setState({
      resend: true
    });
	this.setState({
      counter: 30
    });
	}
  }
  componentDidMount(){console.log(GLOBAL.data);}
  render() {
    //const { route } = this.props
        //const { loveOne } = route.params;
        
    return (
	 
     <Form name="testform">
	  <Textnew name="username" label="Name" post="true"/>
      <Textnew name="username1" label="Email"/>
	  <Textnew name="username2" label="Mobile" post="1"/>
	  <Submit mode="contained" style={{ marginTop: 24 }} form="testform"  callback={()=>this.call()}>
        Sign Up
      </Submit>
    </Form>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    position: 'absolute',
    top: 10 + getStatusBarHeight(),
    left: 4,
	flex: 1,
  },
  socialbtn:{
    backgroundColor:'#fff',
    borderRadius:25,
    width:30+'%',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    paddingVertical:5,
    marginHorizontal:10,
  },
  socialbtntxt:{
    marginLeft:10,
    fontSize:14,
    fontWeight:'bold'
  },
   btnarrow:{
    backgroundColor:'#775ef0',
    borderRadius:10,
    paddingHorizontal:10,
    paddingVertical:10,
	alignItems:'center',
	justifyContent:'center',
  },
 
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  image: {
    width: 24,
    height: 24,
  },
  radio: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
  radioContainer: {
    height: 20,
    width: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
   row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
});