import React, {Component} from 'react';
import { Button,
  Platform,
  StyleSheet,Image,
  Text,
  TextInput,TouchableOpacity,
  View,} from 'react-native'
import  {PanGestureHandler} from 'react-native-gesture-handler'
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import {PermissionsAndroid} from 'react-native';
import WebrtcSimple from 'react-native-webrtc-simple';
import { theme } from '../core/theme'
const logo = require('./image/logo.jpg');
import Icon from 'react-native-vector-icons/Ionicons';
import lib from '../core/lib'
import { NavigationActions } from 'react-navigation'
import {
  globalCall,
  globalCallRef,
  GlobalCallUI,
} from 'react-native-webrtc-simple/UIKit';
type Props = {};// Math.random().toString(36).substr(2, 4)+'YY'
let id=config.uinfo?config.uinfo[1]:0;
const configuration = {
      optional: null,
      key: Math.random().toString(36).substr(2, 4)+id,
    };
global.peer=null;global.pharmsd=null;console.log()
global.myInterval=null;
export default class call extends Component<Props> {
   constructor(route, navigation ,props) {
    super(props);
    this.state ={
      calltype:'',isLoging:false,userId:null, setUserId:null,callId:'', setCallId:'',logmsg:'Connecting..',sname:'',simage:Image.resolveAssetSource(logo).uri,
      seconds:0,minutes:2,

    }
  
  }
   async requestCameraPermission () {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"App needs access to your camera ",
        buttonNeutral: "Ask Me Later",
        buttonNegative: "Cancel",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera permission given");
    } else {
      console.log("Camera permission denied");
    }
  } catch (err) {
    console.warn(err);
  }
}
 msg(id,data)
 {

 console.log(peer,'caledddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd',data)
 //this.setState({'sname':data['name'],simage:data['image']});
 data['sender_name']=config.uinfo.username;data['sender_avatar']=SERVER+config.uinfo.image;
 data['receiver_name']=data['name'];data['receiver_avatar']=SERVER+data['image'];
  //this.callToUser(data.id)
 if(peer==null){WebrtcSimple.events.connect(data.id, data);}
 else{
   const data = {
        type: 'MESSAGE',sessionId: this.state.userId,message:{call:1},receiver_name:data['name'],receiver_avatar:data['image'],
      }
      console.log('peeeeeeeeeeeer mss send --------------------------------');
     WebrtcSimple.events.message(data);
  }
//WebrtcSimple.events.message({call:1,data:data});
 }
 callToUser = userId => {
    if (userId.length > 0) {
      const data = {
        sender_name: 'Sender Name',
        sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
      };
      WebrtcSimple.events.call(userId, data);
    } else {
      alert('Please enter userId');
    }
  };
cl(id){console.log('XXXXXXXXXXXXXXXx reffffffffffffffffffffffffffffffffed called',id)
WebrtcSimple.events.connect(config.data.id, config.data);
}
col(id){console.log('XXXXXXXXXXXXXXXx reffffffffffffffffffffffffffffffffed called',config.data)
WebrtcSimple.events.connect('tt27', {});
 const data = {
        sender_name: 'Sender Name',
        sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
      };
WebrtcSimple.events.message({message:{call:7},userData:data});
}
clr(s){console.log('XXXXXXXXXXXXXXXx reffffffffffffffffffffffffffffffffed called',s)
}
reconnect(){this.conses()}
consesmsg(pa){
sessionId=this.state.userId;
console.log('1111111111111111 XXXXXXXXXXXXXXXx',pa);config.data=pa;
if(typeof(pa)!='undefined'){
        let d=pa;
        
       if(typeof(d.startcall)!='undefined'){
           let ds=config.uinfo;
           let op={'success':function(d){
               console.log(d);
               },'type':'text','trace':true}

          let pd={'session':ds[2],'uid':ds[0],'id':d.id,'sid':sessionId}
          lib.postdata('?op=push',pd,op)
          }
        else if(typeof(d.incoming)!='undefined'){
          //globalCall.refresh(this.cl);
            console.log('send msg');
            const data = {}
      data['sender_name']=config.uinfo.username;data['sender_avatar']=SERVER+config.uinfo.image;
 data['receiver_name']=pa['name'];data['receiver_avatar']=SERVER+pa['image'];
           let udata = Object.assign({}, pa, data);
           WebrtcSimple.events.connect(pa.id, data);
          // WebrtcSimple.reconnect();console.log('1111111111111111 reconnnnnnnnecting');
           WebrtcSimple.events.message({sessionId :sessionId,message:{call:5,userData:udata},userData:udata});
        }
        }
}
calbk(o,t){console.log(o,t,'Tesing okkkkkkkkkkkkkkkkkkkkkkkkkkk');
if(t='Lost connection to server.' && o=='network'){WebrtcSimple.refresh()}}
conses(){console.log('Commmmmmmmmmmmmmmmmmmmmmmmmmmm XXXXXXXXXXXXXXXx');

    if(this.state.userId!=null)
    {
    let d=this.props.route.params;
    if(typeof(d.startcall)!='undefined'){
           this.setState({calltype:'Calling...'});
           let ds=config.uinfo;
           let op={'success':function(d){
               console.log(d);
               },'type':'text','trace':true}

          let pd={'session':ds[2],'uid':ds[0],'id':d.id,'sid':this.state.userId}
          lib.postdata('?op=push',pd,op)
          }
        else if(typeof(d.incoming)!='undefined'){console.log("msg ccccccccccccccccccccccccccccccalded");
          this.msg(this.state.userId,this.props.route.params.data)}
    return;
    }
    WebrtcSimple.start(configuration)
        .then((status) => {
          console.log(status,'==================staus')
        if (status) {
            //const stream = WebrtcSimple.getLocalStream();
            //console.log('My stream: ', stream);
           
            WebrtcSimple.getSessionId((sessionId: string) => {
                console.log('UserId: ', sessionId);
                 this.setState({userId:sessionId});
                  if(typeof(this.props.route.params)!='undefined'){
        let d=this.props.route.params;
        
       if(typeof(d.startcall)!='undefined'){
           this.setState({calltype:'Calling...'});
           let ds=config.uinfo;
           let op={'success':function(d){
               console.log(d);
               },'type':'text','trace':true}

          let pd={'session':ds[2],'uid':ds[0],'id':d.id,'sid':sessionId}
          lib.postdata('?op=push',pd,op)
          }
        else if(typeof(d.incoming)!='undefined'){console.log("msg ccccccccccccccccccccccccccccccalded");
          this.msg(sessionId,this.props.route.params.data)}
        }
            });
        }
        })
        .catch();
   
   const data = {
        sender_name: 'Sender Name',
        sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
      };
   WebrtcSimple.listenings.callEvents((type, userData) => {   
      console.log('Type: ', type,'<<<<<<<<<<<<>>>>>>>>>>>>>',userData);
       this.setState({logmsg:type+"==>"+JSON.stringify(userData)});
      // START_CALL
      // RECEIVED_CALLJSON.stringify(nameList)
      // REJECT_CALL
      // ACCEPT_CALL
      // END_CALL   
      // MESSAGE
      // GROUP_CALL
      // JOIN_GROUP_CALL
      // LEAVE_GROUP_CALL

      if(type=='MESSAGE' && typeof(userData.message.call)!='undefined'){
        let d=userData.message;d['acceptcall']=1;
        console.log(userData,'----------555555555555555--->>>>>',pharmsd);
        d={sender_name: config.profile.username,sender_avatar:SERVER+config.profile.image,
        receiver_name: pharmsd.name,
        receiver_avatar:SERVER+pharmsd.image,}
        WebrtcSimple.events.call(userData.sessionId, d);}
    });
  console.log('sid(********************************************');
 /* WebrtcSimple.events.message({'call':1,uid:'f73y',sender_name: 'Sender Name',sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',});*/
  }
  async componentDidMount() {
   config.screen1='call';config.peer=this;
    config.data=this.props.route.params;console.log('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',this.props.route.params);
   if(typeof(this.props.route.params)!='undefined'){
    let d=this.props.route.params.data;pharmsd=d; console.log('WWWWWWWWWWWWWWWWWWW>5555>>>>>>>>>>>>>',pharmsd);
    if(d.image.indexOf('http') == -1){this.setState({sname:d.name,simage:SERVER+d.image});}
    else{this.setState({sname:d.name,simage:d.image});}
    this.setState({simage:SERVER+d.image});
    
    const unsubscribe =  this.props.navigation.addListener('focus', () => {
      this.conses();
      this.setState({logmsg:'Connecting'});
      this.setState({minutes:1});
      this.setState({seconds:59});
      this.timer();
    });
    return
    {
      clearInterval(myInterval)
    }
  }
  config.obj=this;
  

}
componentWillUnmount() {
        clearInterval(myInterval);
       
    }
callreset(){
  let url=config.uinfo[3]==3?'homeScreen':'appoinment';
     this.props.navigation.navigate(url);
}
timer()
{

   myInterval = setInterval(() => {
            if (this.state.seconds > 0) {
                this.setState({seconds:this.state.seconds-1});
            }
            if (this.state.seconds === 0) {
                if (this.state.minutes <= 0) {
                    clearInterval(myInterval);
                    this.setState({logmsg:'Call is not attanted'});
                } else {
                    
                    this.setState({minutes:this.state.minutes-1});
                    this.setState({seconds:59});
                }
            } 
        }, 1000)
}
    render() {
        

        //console.log(config.uinfo,'------------------------------------------------------------')
        return (

             <View style={styles.container}>
<View style={{height:30,position:'absolute',top:5,left:10}}><TouchableOpacity onPress={()=>{this.callreset()}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: theme.colors.primary,}} />
   </TouchableOpacity></View>
      <View style={{marginBottom:30}}>
        <Text style={{fontSize: 30}}>{this.state.calltype}{this.state.userId}</Text>
      </View>

      <View style={styles.rowbtn}>
        
        <View>
        <Image style={styles.imagemodel} source={{uri: this.state.simage}}/>
         <Text style={{fontSize: 30,color:'#000'}}>{this.state.sname}</Text>
        </View>
      </View>
      <Text style={{fontSize: 20}}>
        { this.state.minutes === 0 && this.state.seconds === 0? null:this.state.seconds < 10 ?  '0'+this.state.minutes+':0'+this.state.seconds : '0'+this.state.minutes+':'+this.state.seconds}</Text>
        <Text style={{fontSize: 20}}>{this.state.logmsg}</Text>
        
      <View></View>
      <GlobalCallUI ref={globalCallRef} />
    </View>
        )
    }
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  rowbtn: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    alignItems: 'center',
    marginVertical: 8,
  },
  btn: {
    margin: 16,
    backgroundColor: 'black',
    paddingHorizontal: 10,
  },
    imagemodel:{
    width:150,
    height:150,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
  textInput: {
    width: 200,
    height: 50,
    borderWidth: 0.5,
    borderColor: 'gray',
    paddingHorizontal: 12,
  },})