import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,Button,Image,TouchableOpacity} from 'react-native';
import RNUpiPayment from 'react-native-upi-pay';
import lib from '../core/lib'
import config from '../core/global'
import Icon from 'react-native-vector-icons/Ionicons';
import { theme } from '../core/theme'
import PushNotification, {Importance} from 'react-native-push-notification';
const img = require('../image/upi.png');
type Props = {};
global.udata = null;
global.libs = null;
export default class payment extends Component<Props> {
	  constructor(props){
        super();
        this.state={
			udata:null,isLoading:false,
            Status:"", 
            txnId:"",
            GOOGLE_PAY:'GOOGLE_PAY',
            PHONEPE:'PHONEPE',
            PAYTM:'PAYTM',
            message:""
        }
	  }
showpushnotification(item)
{
	this.createChannel()
	PushNotification.cancelAllLocalNotifications();
	/*PushNotification.localNotification({

  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: "My Notification Title", // (optional)
  message: "My Notification Message", // (required)
  data:{id:25},
  actions: '["Call", "Cancel"]',
 
});*/
	//console.log(item,'======================');
	PushNotification.localNotificationSchedule({
  //... You can use all the options from localNotifications
  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: "Appoinment Scheduled", // (optional)
  message: "Appoinment time is "+item.time+", call "+item.username, // (required)
  date: new Date(Date.now() + 60 * 100), // in 60 secs
  data:item,
  actions: '["Call", "Cancel"]',
  allowWhileIdle: false, // (optional) set notification to work while on doze, default: false
  
  /* Android Only Properties */
  repeatTime: 1, // (optional) Increment of configured repeatType. Check 'Repeating Notifications' section for more info.
});
}
createChannel()
{
	PushNotification.createChannel(
    {
      channelId: "juristz-id", // (required)
      channelName: "juristz", // (required)
      channelDescription: "A channel to categorise your notifications", // (optional) default: undefined.
      playSound: false, // (optional) default: true
      soundName: "default", // (optional) See `soundName` parameter of `localNotification` function
      importance: Importance.HIGH, // (optional) default: Importance.HIGH. Int value of the Android notification importance
      vibrate: true, // (optional) default: true. Creates the default vibration pattern if true.
	  color: "red", 
	  actions: ["Yes", "No"],
	  id: 0,
    },
    (created) => console.log(`createChannel returned '${created}'`) // (optional) callback returns whether the channel was created, false means it already existed.
  );
}
 successCallback(data){
            //
            console.log(data);
            that.setState({Status:"SUCCESS"});
            that.setState({txnId:data['txnId']});
            that.setState({message:"Succccessfull payment"});
        }
failureCallback(data){
            console.log(libs)
			console.log('uuuuuuuuuuuuu',config.uinfo);
			 let op={'success':function(d){obj.setState({ isLoading: false });console.log(d)
			 obj.showpushnotification(udata);
			 obj.props.navigation.navigate('appoinment',{'data':udata});
			 },'type':'json','trace':true}
			 let pd={'session':config.uinfo[2],'uid':config.uinfo[0]}
			 pd['id']=udata['aid'];pd['amount']=udata['fee'];
			 lib.postdata('?op=payAppoinments',pd,op);
            // in case no action taken
            if (data['status']=="FAILURE"){
                that.setState({Status:"FAILURE"})
                that.setState({message:data['message']});
            }
            // in case of googlePay
            else if (data['Status']=="FAILURE"){
                that.setState({Status:"FAILURE"})
                that.setState({message:"app closed without doing payment"});;
            }
            // in case of phonepe
            else if (data['Status']=="Failed"){
                that.setState({Status:"FAILURE"});
                that.setState({message:"app closed without doing payment"});
            }
            // in case of phonepe
            else if(data['Status']=="Submitted"){
                that.setState({Status:"FAILURE"});
                that.setState({message:"transaction done but pending"});
            }
            // any other case than above mentioned
            else{
                that.setState({Status:"FAILURE"});
                that.setState({message:data[Status]});
            }
        }
componentDidMount() {global.obj=this;global.uinfo=config.uinfo;global.libs=lib;}
  render() {
	  that=this;
	  lib.f();
	  udata=this.props.route.params.data;
	  let payam=" Pay "+this.props.route.params.data['fee'] + ' & Continue'
        function floo(paymentApp){
			console.log(that.successCallback,'pppppppppppppppppppppp');
            RNUpiPayment.initializePayment({
                vpa: '8056111741@okbizaxis',  		//your upi address like 12345464896@okhdfcbank
                payeeName: ' Juristz Zone',   			// payee name 
                amount: '1',				//amount
                transactionNote:'buy new',
				mode:'00',//note of transaction
                mc : 'BCR2DN6T27E4P7Z6',	//some refs to aknowledge the transaction
				mcc : 'BCR2DN6T27E4P7Z6',	
				transactionRef: 'aasf-332-aoei-fn'
            },that.successCallback,that.failureCallback);
        }
        
        
    return (
      <View style={styles.container}>
	   <View style={{alignItems:"flex-start",justifyContent: 'flex-start',height:50,backgroundColor:theme.colors.primary,width:"100%",padding:10,paddingLeft:20}}>
	   <TouchableOpacity onPress={()=>{this.props.navigation.goBack(null);}} style={{}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: '#fff',}} /> 
   </TouchableOpacity>
  
       </View> 
       <View style={{alignItems:"center",justifyContent:"center",flex:1}}>
        <View style={{padding:5}}>
            <Image style={{padding:5,marginBottom:20,}} source={img}/>
            <Button
			style={{padding:10,marginTop:10}}
            title={payam}
            onPress={() => {floo(this.state.PAYTM)}}
            />
        </View>
 
        <Text>{this.state.Status+" "+this.state.txnId}</Text>
        <Text>{this.state.message}</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});