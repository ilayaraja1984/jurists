import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,Image,TouchableOpacity,Dimensions,ActivityIndicator,Alert} from 'react-native';
import ImagePicker from 'react-native-image-picker'
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';
import Button from '../helper/Button';
import { AsyncStorage } from 'react-native';
import Toast from 'react-native-toast-message';
import { SERVER_URL } from '../core/settings'
import { theme } from '../core/theme'
import eImage from '../assets/profile-picture.jpg'
import GLOBAL from '../core/global'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

type Props = {};
export default class MyList extends Component<Props> {
	constructor() {
    super();
    this.state ={
      photo:{uri:Image.resolveAssetSource(eImage).uri},
	  loadimage:false,
	  isLoging:false,
    }
	
  }
	
 
 /*selectFile = () => {
    var options = {
      title: 'Select Image',
      customButtons: [
        { 
          name: 'customOptionKey', 
          title: 'Choose file from Custom Option' 
        },
      ],
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };

    ImagePicker.showImagePicker(options, res => {
      console.log('Response = ', res);

      if (res.didCancel) {
        console.log('User cancelled image picker');
      } else if (res.error) {
        console.log('ImagePicker Error: ', res.error);
      } else if (res.customButton) {
        console.log('User tapped custom button: ', res.customButton);
        alert(res.customButton);
      } else {
        let source = res;
        this.setState({
          resourcePath: source,
        });
      }
    });
  };*/
  async getitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	
	return [uid,id,session]
}
  handleCameraPhoto = () => {
    const options = {
      noData: true,
    }
	console.log("work start===>>>",this.state.photo.uri);
	try
	{
    launchCamera(
              {
                mediaType: 'photo',
                includeBase64: false,
                maxHeight: 200,
                maxWidth: 200,
              },
              (response) => {
				  
				   if (response.error) {
    console.log('LaunchCamera Error: ', response.error);
  }
  else {
     this.setState({ photo: response })
  }
               
              },
            );
	}catch(e){console.log("work",e);}
	
  }
async createFormData (photo){
	 console.log("pppppppppppppp11111111");
  const data = new FormData();
   console.log("pppppppppppppp11111111");
  data.append('file', {
        uri: Platform.OS === 'android' ? photo.uri : photo.uri.replace('file://', ''),
        type: photo.type,
        name:photo.fileName,
        data: photo.data,
      });
 console.log("pppppppppppppp2222222");
		 let itm=await this.getitems();
		console.log("pppppppppppppp2222222",itm);
		data.append('id', itm[1]); 
		data.append('uid', itm[0]); 
		data.append('session', itm[2]);

       
/*  Object.keys(body).forEach((key) => {
    data.append(key, body[key]);
  });*/

  return data;
  }
   savefile= async () => 
  { 
 	    if(this.state.loadimage==false){
			Toast.show({
	  type: 'error',
	  visibilityTime: 100,
	  position: 'top',
      text1: 'Image is invalid',
      text2: 'Please chose ane image... ',
	  
    }); 
			return false}
			
this.setState({ isLoging: true });
		fetch(SERVER_URL+'?op=profileimage', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: await this.createFormData(this.state.photo)
      })
      .then((response) => response.text())
      .then((responseJson) => {
			 this.setState({ isLoging: false });
			 console.log(responseJson);
		 if(responseJson['result']==false)
		 {
			 Toast.show({
	  type: 'error',
	  visibilityTime: 1000,
	  position: 'top',
      text1: "File is invalid",
      text2: 'Please check ',
	  
    });
		 }
		 else{
			 
		 Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully Profile Updated...',
      text2: 'Profile Image',
	  onHide: () => {this.props.navigation.navigate('login')},
    });
			 
			 }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
         console.error(error);
      });	 
	 
	
  }
  handleChoosePhoto = () => {
    const options = {
      noData: true,
    }
	console.log("work start===>>>",this.state.photo);
	try
	{
    launchImageLibrary(options, response => {
      if (response.uri) {
		  
        this.setState({ photo: response })
		this.setState({ loadimage: true })
      }
    })
	}catch(e){console.log("work",e);}
  }
  render() {
	   const { photo } = this.state;
	   console.log(this.state,'-----------------------------');
	   
    return (

        <View style={styles.container}>
		
       
        
         {photo && (
          <Image
            source={{ uri: photo.uri }}
            style={{ width: 300, height: 300 }}
          />
        )}
       
		
     
	  <View style={styles.uploadContainer}>
        <Text style={styles.uploadContainerTitle}>
          Upload Lawyer Profile Image
        </Text>
        <TouchableOpacity style={styles.uploadButton} onPress={this.handleChoosePhoto}>
          <Text style={styles.uploadButtonText}>
            Select Image
          </Text>
        </TouchableOpacity>
		<TouchableOpacity style={styles.uploadButton} onPress={this.savefile}>
          <Text style={styles.uploadButtonText}>
            Upload Image
          </Text>
        </TouchableOpacity>
      </View>
	  
        <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:10000}} />  
		{this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
        </View>
    
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
uploadButtonText:{color:'#fff',fontWeight: "bold",},
  uploadContainer: {
    backgroundColor: '#f6f5f8',
    borderTopLeftRadius: 45,
    borderTopRightRadius: 45,
    position: 'absolute',
    bottom: 0,
    width: Dimensions.get('window').width,
    height: 200,
  },
   loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  uploadContainerTitle: {
    alignSelf: 'center',
    fontSize: 25,
    margin: 20,
    fontFamily: 'Roboto'
  },
  uploadButton: {
    borderRadius: 16,
    alignSelf: 'center',
    shadowColor: "#000",
	color:'red',
	fontWeight: "bold",
    shadowOffset: {
      width: 7,
      height: 5,
    },
	shadowOpacity: 1.58,
    shadowRadius: 9,
    elevation: 4,
    margin: 10,
    padding: 10,
    backgroundColor: '#fe5b29',
    width: Dimensions.get('window').width - 60,
    alignItems: 'center'
  },
  backgroundImage: {
    flex: 1,resizeMode: 'cover',
  }
 
});