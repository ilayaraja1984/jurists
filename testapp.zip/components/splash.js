import React, { Component } from 'react';
// import all basic components as follows
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
  StatusBar,
  SearchBox,AppState,
  TextInput,ImageBackground
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { AsyncStorage } from 'react-native';
 import { theme } from '../core/theme'
 import  config  from '../core/global'
 import lib from '../core/lib'
global.backgroundColor = theme.colors.primary;
global.appstate='active'
const logo = require('./image/logo.jpg')
global.obj=null;
class SplashScreen extends Component {
  performTimeConsumingTask = async() => {
    return new Promise((resolve) =>
      setTimeout(
        () => { resolve('result') },
        3000
      )
    )
  }
async getitems()
{
  let uid=await AsyncStorage.getItem('uid');
  let id=await AsyncStorage.getItem('id');
  let session=await AsyncStorage.getItem('session');
  let role=await AsyncStorage.getItem('role');
  let scren=await AsyncStorage.getItem('screen');
  let profile=await AsyncStorage.getItem('profile');
  return [uid,id,session,role,scren,profile]
}

  

  componentWillUnmount() {
   // AppState.removeEventListener('change', _handleAppStateChange);
    console.log('App 44444444444444444444444444444444444444444444444444444444444444444444!')
  }

  _handleAppStateChange = (nextAppState) => {config.appState=nextAppState
    
    if (appstate.match(/inactive|background/) && nextAppState === 'active') {

      console.log('App has come to the foreground!')
    }
    console.log('App peeer recontinggggggggggg')
    if(config.peer!=null && nextAppState === 'active'){
      console.log('App peeer recontinggggggggggg')
      if(typeof(config.obj.reconnect)!='undefined'){config.peer.reconnect()}}
    console.log('App has come to active',nextAppState)
    appstate=nextAppState;
  }
  async saveprofile(info){

    await AsyncStorage.setItem('profile', JSON.stringify(info));
   AsyncStorage.flushGetRequests();
  }
  async componentDidMount() {
    // Preload data from an external API
    // Preload data using AsyncStorage
    console.log("Log88888888888888888888888888888888888888888888888888888888888888888888888888");
  //if(config.calling){this.props.navigation.navigate('call',{data:config.notficationData,'incoming':1});return}
  AppState.addEventListener('change', this._handleAppStateChange);
  const ds=await this.getitems();obj=this;let ldata=ds;config.obj=this;
  if(ldata[0]==null || ldata[1]==null || ldata[2]==null || ldata[3]==null){
  this.props.navigation.navigate('homeScreen',{screen: 'otp',});return}
  if(ldata[5]==null){

  let op={'success':function(d){
   let info =d['data'][0];info.image
   console.log(info.image,'WEEE',info);
   info['settings']=d['settings'];
   config.profile=info;
   obj.saveprofile(info)
   obj.callscreen(ds);
   
   },'type':'json','trace':true}
   
   let pd={'session':ds[2],'uid':ds[0]}
   lib.postdata('?op=profile',pd,op);}else{config.profile=JSON.parse(ldata[5]);console.log('prrrrrrrrrrrrrrrrrrrrr',ldata[5]);
   this.callscreen(ds);
 }

  }
  async callscreen(ldata)
  {
    //const data = await this.performTimeConsumingTask();
    if(config.settings==null){config.settings={}}
    //console.log("Log88888888888888888888888888888888888888888888888888888888888888888888888888",config.settings);
    if (ldata !== null) {
    config.uinfo=ldata;
    console.log("Log",pushnotiaction,"loading............. started",ldata);
   config.settings.login=true;config.settings.role=ldata[3];
    let homeScreen=ldata[3]==2?'appoinment':'homeScreen';//lawyerprofile
    config.homeScreen=homeScreen;

    if(config.calling){this.props.navigation.navigate('homeScreen',{screen:'call',params:{'data':config.notficationData,'incoming':1}});return}
    if(ldata[0].length>=5){
      console.log("homescreen","loading............. started",ldata[4]);
      if(ldata[4]=='profile'){     this.props.navigation.navigate('homeScreen',{screen:'profileupdate'});
    
    }
      else if(ldata[4]=='address'){this.props.navigation.navigate('homeScreen',{screen:'address'})}
    else {console.log(ldata,"========= started",ldata[3]);
  if(config.pushnoti){config.pushnoti=false;this.props.navigation.navigate('homeScreen',{screen: 'appoinment','data':config.pushnotidata});return}
  
  /*this.props.navigation.navigate('homeScreen',{screen: 'newappoinment',params:{lid:'Gu570289192',cid:ldata[0],uinfo:{"about": "testing msg", "category": "Crime,", "gender": "male", "id": "Gu570289192", "image": "uploads/users/8369043.jpg", "name": "Gurulawyer", "position": "Dharmapuri", "rating": "0.00", "review": [{"image": "uploads/users/8369043.jpg", "name": "Gurulawyer", "rating": "4", "text": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur "}], "status": "1", "totalReview": "0", "user_id": "192", "verified": "0"}}}); }*///homeScreen 
   //this.props.navigation.navigate(homeScreen)
   console.log("testing okkkkkkkkkkkkk",homeScreen);

   if(ldata[3]==2){this.props.navigation.navigate('homeScreen',{screen:'appoinment'});}
   else{this.props.navigation.navigate(homeScreen);}
   }
   }else{this.props.navigation.navigate('otp');}
    }else{this.props.navigation.navigate('otp');}
  }
  render() {
    const viewStyles = [styles.container, { backgroundColor: 'orange' }];
    const textStyles = {
      color: 'white',
      fontSize: 40,
      fontWeight: 'bold'
    };

    return (
      <ImageBackground source={require("../assets/splashbk.png")} style={styles.bg}>
      <View style={styles.SplashScreen_RootView}>
     
       <StatusBar backgroundColor={theme.colors.primary} barStyle='light-content' />
        
    <Image
          source={ logo }
          style={styles.CircleShapeView}
        />
    
      </View>
    </ImageBackground>
    );
  }
}

const styles = StyleSheet.create(  
{  
    MainContainer:  
    {  
        flex: 1,  
        justifyContent: 'center',  
        alignItems: 'center',  
        paddingTop: ( Platform.OS === 'ios' ) ? 20 : 0  
    },
  bg: {
    flex: 1,
    resizeMode: "cover",
    
  marginTop:0,
  height:250,
  
  
  },
  inputs : {
    borderRadius:25,
    backgroundColor:'#fff',
    width:80+'%',
    paddingHorizontal:25,
    fontSize:16,
    marginTop:20
  },
   CircleShapeView: {  
    backgroundColor: '#ffffff',
    justifyContent: 'center',
    alignItems: 'center'
},
    SplashScreen_RootView:  
    {  
        justifyContent: 'center',  
        flex:1,  
        margin: 0,  
        position: 'absolute',  
        width: '100%',  
        height: '100%',
        justifyContent: 'center',  
        alignItems: 'center', 
 
      },  
      textStyles: {
        color: 'white',
        fontSize: 40,
        fontWeight: 'bold'
      },
    SplashScreen_ChildView:  
    {  
        justifyContent: 'center',  
        alignItems: 'center',  
        backgroundColor: '#00BCD4',  
        flex:1,  
    },  
});
export default SplashScreen;