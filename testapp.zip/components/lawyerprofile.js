import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity,Alert,Image,StyleSheet,ActivityIndicator,Dimensions ,
  Modal,ScrollView} from 'react-native';
 import {useRoute} from '@react-navigation/native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { CheckBox } from 'react-native-elements'
import { Rating,Button,PricingCard} from 'react-native-elements';
import {RadioButton , HelperText,TextInput} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Ionicons';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'
import RNDateTimePicker from '@react-native-community/datetimepicker';
import BackButton from '../helper/BackButton'
//import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import  notification from '../core/notification'
import { SERVER_URL,SERVER } from '../core/settings'
import lib from '../core/lib'
import FlashMessage,{showMessage, hideMessage} from "react-native-flash-message";
import config from '../core/global'
import { TabView, SceneMap , TabBar } from 'react-native-tab-view';
//Define a color for toolbar
global.obj=null;
var { findNodeHandle } = React;
//type Props = {};
const FirstRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const SecondRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const initialLayout = { width: Dimensions.get('screen').width,height:30 };
let uid=0;
export default class profile extends Component<Props> {
constructor(route, navigation ,props) {
    super(props);
    this.bn()
    this.state ={
      isLoging:false,catolddata:[],
      checkingAuth:true,about:null,
      opentimer:false,opentime:null,working:[],live:'450',schedule:'350',
      endtimer:false,endtime:null,
      lstarttimer:false,lstarttime:null,catelist:{},catelist1:{},catelist2:{},category:'',catelist3:{},catelist4:{},
      lendtimer:false,lendtime:null,
      itime:'00:30:00',optm:1,working_days:null,categories:null,
    userSelected:{},
	
    routes:[
    { key: 'first', title: 'About' },
    { key: 'second', title: 'Settings' },
    { key: 'category', title: 'Category' },
    { key: 'fee', title: 'Fees' },
    
    
  ],index:0, setIndex:0,
    }
  
  }
  
  
 
  
   haction1(item,n){ //notification.createChannel();notification.localpushnotification(item);
    //notification.register();
   // notification.sendPushNotification();
   
   let xm=config.profile.settings.working_days
   let clist=xm.split(',');//console.log(clist,'====',item,clist.indexOf(item));
   if(clist.indexOf(item)!== -1){
    var index = clist.indexOf(item);
      if (index !== -1) {
        clist.splice(index, 1);
      }
    }
   else{clist.push(item);}
    config.profile.settings.working_days=clist.join(',');
    //let cn=this.state.catelist[item].props.style.display=='stop-outline'?'none':'flex';
   // console.log(item,cn,this.state.catelist[item].props.style.display);
  //this.state.catolddata[n]=this.state.catolddata[n][]
 console.log(config.profile.settings.working_days,'====',clist);
 this.state.working_days=clist.join(',');
 this.showworking(this.state.working)
 }

 haction(item,n){ //notification.createChannel();notification.localpushnotification(item);
    //notification.register();
   // notification.sendPushNotification();
   let xm=config.profile.category
   if(xm.substr(0,xm.length-1)==','){xm=xm.substr(0,xm.length-1)}
   let clist=xm.split(',');//console.log(xm,'====',clist);
   if(clist.indexOf(item)!== -1){
    var index = clist.indexOf(item);
        clist.splice(index, 1); 
    }
   else{clist.push(item);}
   console.log(clist);
   config.profile.category=clist.join(',');
    //let cn=this.state.catelist[item].props.style.display=='stop-outline'?'none':'flex';
   // console.log(item,cn,this.state.catelist[item].props.style.display);
  //this.state.catolddata[n]=this.state.catolddata[n][]
  //console.log(config.profile.category);
 this.state.category=config.profile.category;
 this.showlist(this.state.catolddata)
 }
   showlist(data){
    this.state.catolddata=data;
	 if(!data){return (<Text style={{marginLeft: 10,fontSize: 20 }}>No Data Available.</Text>)}
    let clist=config.profile.category.split(',');
    //let clist=config.profile.category+','

	 let rd= data.map((item, index) => {
    let cl=(<>
         <Icon style={{ width: 25, height: 25, marginLeft: 10}} name="stop-outline" size={25} color="#000" /></>)
        if(clist.indexOf(item)!== -1){
          
          cl=(<><Icon style={{ width: 25, height: 25, marginLeft: 10}} name="checkbox-outline" size={25} color="#000" />
         </>)
        }
        
        if(item!=''){
				return(<View style={styles.row} key={index}>
					   
				 <View style={styles.col}>
				  <View style={styles.catrow}>
          <TouchableOpacity style={styles.catrow} onPress={() => {this.haction(item,index)}}>

				 {cl}
				
        <Text style={{marginLeft: 10,fontSize: 20 }}>
					{item}
				</Text>
        </TouchableOpacity>
				</View>
				</View>
                </View>)}
              
            }); 
  this.setState({categories:rd}); 
	return rd;   
   }
   showworking(){
    let data=['0','1','2','3','4','5','6'];let datatx=['Sunday','Monday','Tuesday','Wedsday','Thursday','Friday','Saturday'];
   
    let cat=config.profile.settings.working_days.split(',');


   let rd= data.map((item, index) => {
    console.log(cat.indexOf(item),item);
    let cl=(<>
         <Icon style={{ width: 25, height: 25, marginLeft: 10}} name="stop-outline" size={25} color="#000" /></>)
        if(cat.indexOf(item)!==-1){
          
          cl=(<><Icon style={{ width: 25, height: 25, marginLeft: 10}} name="checkbox-outline" size={25} color="#000" />
         </>)
        }
        let t=datatx[item]
        if(item!=''){
        return(<View style={styles.row} key={index}>
             
         <View style={styles.col}>
          <View style={styles.catrow}>
          <TouchableOpacity style={styles.catrow} onPress={() => {this.haction1(item,index)}}>

         {cl}
        
        <Text style={{marginLeft: 10,fontSize: 20 }}>
          {t}
        </Text>
        </TouchableOpacity>
        </View>
        </View>
                </View>)}
              
            }); 
  this.setState({working:rd}); 
  return rd;   
   }
   showreview(data){
	 if(!data){return (<Text style={{marginLeft: 10,fontSize: 20 }}>No Data Available.</Text>)}

	 let rd= data.map((item, index) => {
					  // console.log("==============>",item);
				return(<View style={styles.row} key={index}>   
				 <View style={styles.col}>
				  <View style={styles.catrow}>
				 <View>
				<Image style={styles.image} source={{uri:item.image}}/>
				<Rating imageSize={15} readonly startingValue={parseFloat(item.rating)} style={styles.rating,{marginTop:10}} />
				</View>
				<View>
				<Text style={{marginLeft: 10,fontSize: 20,color:"#000",fontWeight:'bold',}}>{item.name}</Text>
				<Text style={{marginLeft: 10,fontSize: 15,justifyContent: 'center',marginRight:10}}>{item.text}</Text>
				</View>
				</View>
				</View>
                </View>)
              
            });  
	return rd;   
   }
   bn() {
//this.setState({userSelected:this.props.route.params});
  return true 
}
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
    if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
    this.setState({ gender: v});
  }
   async getitems()
   {
  let uid=await AsyncStorage.getItem('uid');
  let id=await AsyncStorage.getItem('id');
  let session=await AsyncStorage.getItem('session');
  let role=await AsyncStorage.getItem('role');
  let scren=await AsyncStorage.getItem('screen');
  return [uid,id,session,role,scren]
  }
  async setitems(responseJson)
  {
  //console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson['uid'],responseJson['session'],responseJson['id']);
  await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
  await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
  await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
  await AsyncStorage.setItem('role', responseJson['role'].toString());

  AsyncStorage.flushGetRequests();
  //console.log("==================================<<<<<<<<<<<<<<<",responseJson['uid']);
  
  
  }
settings()
{
  return(<><View style={{alignItems:'center',marginTop:15,flexDirection: 'row',marginLeft:15}}>
  <TextInput
      label="Office Start Time"
      value={this.state.opentime}
      style={{width:'48%',marginBottom:4,marginRight:10}}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({optm:1});this.setState({opentimer:true}) }} />}
    /> 
    {this.state.opentimer && (<RNDateTimePicker mode="time" value={new Date()} minuteInterval={5} onChange={this.dChange} />)}             
 <TextInput
      label="Office Close Time"
      value={this.state.endtime}
      style={{width:'48%',marginBottom:4,marginRight:10}}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({optm:2});this.setState({opentimer:true}) }} />}
    /> 
   </View><View style={{alignItems:'center',marginTop:15,flexDirection: 'row',marginLeft:15}}>
      <TextInput
      label="Lunch Time"
      value={this.state.lstarttime}
      style={{width:'48%',marginBottom:4,marginRight:10}}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({optm:3});this.setState({opentimer:true}) }} />}
    /> 
    
      <TextInput
      label="Lunch Close Time"
      value={this.state.lendtime}
      style={{width:'48%',marginBottom:4,marginRight:10}}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({optm:4});this.setState({opentimer:true}) }} />}
    /> 
    </View><View style={{alignItems:'center',marginTop:15,flex: 1,marginLeft:15}}>
   <TextInput
      label="Appoinment Interval Time"
      value={this.state.itime}
      style={{width:'99%',marginBottom:4}}
      onChangeText={text=>this.setState({itime:text})}
    /> 

  </View></>
 )
}
dChange = (event, d) => {
  if(event.type != "set") {
    return
    } 
    //const currentDate = d || this.state.datetxt;console.log(d.getMonth(),d);
    //setShow(Platform.OS === 'ios');
    let n=this.state.optm;this.setState({opentimer: Platform.OS === 'ios' ? true : false,});
    if(n==1){this.setState({opentime:d.getHours()+':'+(d.getMinutes())+':'+'00'});}// this.setState({show:false});
    else if(n==2){this.setState({endtime:d.getHours()+':'+(d.getMinutes())+':'+'00'});}
    else if(n==3){this.setState({lstarttime:d.getHours()+':'+(d.getMinutes())+':'+'00'});}
    else if(n==4){this.setState({lendtime:d.getHours()+':'+(d.getMinutes())+':'+'00'});}
    
  return true
  };
msg(tx,t='success'){showMessage({message: tx,type: t,});}
save()
{
  let n=this.state.index;console.log(n,'=====================>>>>>>>');//return;
  let ds=config.uinfo;obj.setState({ isLoading: true });
  let op={'success':function(d){obj.setState({ isLoading: false });
   console.log(d);
   obj.msg("Successfully Saved..",'success')

   },'type':'json','trace':true}
   // s: 'raja' ,g:'male',l:'pppp',c:'crime'
   let pd={'session':ds[2],'uid':ds[0]}
   if(n==3){if(this.state.live<=10 || this.state.schedule<=10){this.msg('invalid value','error');return}
   pd['live']=this.state.live;pd['fee']=this.state.schedule;lib.postdata('?op=userfees',pd,op);
    return
   }
   else if(n==1){pd['end_time']=this.state.endtime;pd['start_time']=this.state.opentime;pd['lunch_endtime']=this.state.lendtime;
  pd['lunch_time']=this.state.lstarttime;pd['interval_time']=this.state.itime;pd['working_days']=this.state.working_days;
 }else if(n==2){pd['category']=this.state.category;}

   else{if(this.state.about.length<=5){this.msg('invalid value','error');return} pd['about']=this.state.about;}
   lib.postdata('?op=updateprofile',pd,op)
}
  _handleIndexChange = index => this.setState({ index });

  _renderHeader = props => <TabBar {...props} />;

  _renderScene =  ({ route }) => {
  //console.log('===================------------------------------',this.props.route.params.data)
   let info=config.profile;
   let rev=info['review']
   let cat=info['category']
  switch (route.key) {
    case 'first':
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:20,paddingLeft:20,paddingTop:20 } ]}>
         <TextInput
            style={{ height:200}}
            value={this.state.about}
            onChangeText={text=>this.setState({about:text})}
            multiline={true}
            label="About Me"
            underlineColorAndroid='transparent'
    />
        
              </View>
        );
    case 'second':
	console.log('===================',route.key)
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:5,paddingLeft:5,paddingTop:20 } ]}>
        <ScrollView contentContainerStyle={styles.modalInfo,{marginRight:5}}>
        <View>{this.settings()}</View>
         <View style={{marginLeft:20,marginTop:10}}><View style={{marginBottom:10}}><Text style={{fontSize:16,fontWeight:'bold'}}>Working Days</Text></View>
        <View>{this.state.working}</View></View>
        </ScrollView>
              </View>
        );
    case 'category':
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:20,paddingLeft:20,paddingTop:20 } ]}>
        <ScrollView contentContainerStyle={styles.modalInfo}>{this.state.categories}</ScrollView>
              </View>
        );
    
    case 'fee':
      return (<View style={[ styles.container, { backgroundColor: '#ffffff',paddingRight:20,paddingLeft:20,paddingTop:20 } ]}>
        <ScrollView contentContainerStyle={styles.modalInfo}>
        <View style={{marginBottom:10}}><Text style={{fontSize:16,fontWeight:'bold'}}>Fee Settings</Text></View>
        <View style={{marginBottom:10}}><TextInput
            value={this.state.live}
            onChangeText={text=>this.setState({live:text})}
            keyboardType="numeric"
            label="Live Video Call Fee"
            underlineColorAndroid='transparent'
    /></View>
    <View style={{marginBottom:10}}><TextInput
            value={this.state.schedule}
            onChangeText={text=>this.setState({schedule:text})}
            keyboardType="numeric"
            label="Schedule Call Fee"
            underlineColorAndroid='transparent'
    /></View>
        </ScrollView>
              </View>
        );
    default:
      return null;
  }
}
postdata(url,data={},op={}){
	
 }
async componentDidMount() {let ds=await this.getitems();obj=this;
	 let op={'success':function(d){obj.setState({ isLoading: false });obj.setState({ info: d.data });
   obj.showlist(d.data.split(','));
	 },'type':'json','trace':true}

	 let pd={'session':ds[2],'uid':ds[0]}
	 lib.postdata('?op=getCategories',pd,op);

this.setState({about:config.profile.about});
this.setState({opentime:config.profile.settings.start_time});
this.setState({endtime:config.profile.settings.end_time});
this.setState({lstarttime:config.profile.settings.lunch_time});
this.setState({lendtime:config.profile.settings.lunch_endtime});
this.setState({interval_time:config.profile.settings.interval_time});
this.setState({working_days:config.profile.settings.working_days});
this.showworking();
}

 //async componentDidMount() {this.setState({userSelected:this.props.route.params});}
  render() {
    //const { route } = this.props
  //console.log('MMMMMMMMMMMMMMMMMMMMMMMMMMMMM>',config.profile.settings)
    
  // console.log("<>",this.props.route.params,"<>")
   let info=config.profile;
   let info1=config.profile;//console.log("idddddddddddddddddd",info);
   let image= SERVER+info.image
    return (
    <View style={styles.container1}>
     
    <View style={{backgroundColor:theme.colors.primary}}> 
   
   <TouchableOpacity onPress={()=>{this.props.navigation.navigate('homeScreen');}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: 'white',}} />
   </TouchableOpacity>
    <View style={styles.modalInfo}>
<View style={{alignItems:'center',height:190,paddingTop:0}}>
                  <Image style={styles.imagemodel} source={{uri: image}}/>
                  <View style={styles.modelname}>
                  <Text style={styles.namemodel}>{info.username}</Text>
                  <View style={{flexDirection: 'row',  marginLeft:25,}} ><Icon name="location" style={{ fontSize: 13 ,color: '#fff',marginTop:3}} /><Text style={styles.positionmodel}>{info.City}</Text></View>
                  </View>
                </View>
    </View>
    <View style={[styles.userInfo, styles.bordered]}>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Experience
                            </Text>
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              {info.rating}
                            </Text>
                            <Rating imageSize={15} readonly startingValue={info.rating} style={styles.rating} />
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Contacted
                            </Text>
                          </View>
                        </View>
       <View style={styles.buttons}>
                      <Button title="Edit Address" type="clear" onPress={()=>{this.props.navigation.navigate('address',{data:1});}}/>
                      <View style={styles.separator} />
                      <Button title="Edit Image" type="clear" onPress={()=>{this.props.navigation.navigate('profileupdate',{data:1});}}/>
                      
                     
                      </View>
    </View> 
    <TabView
        style={styles.container1}
        navigationState={this.state}
        renderScene={this._renderScene}
         renderHeader={this._renderHeader}
         initialLayout={{ width: Dimensions.get('window').width }}
        onIndexChange={this._handleIndexChange}
         renderTabBar={props => (
          <TabBar
            {...props}
            renderLabel={this._renderLabel}
            getLabelText={({ route: { title } }) => title}
            indicatorStyle={styles.indicator}
            tabStyle={styles.tabStyle}
            style={styles.tab}
          />
        )}
      /> 
      <View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.save();}}>
       <Text style={styles.textStyle}><Icon name="save" size={35} color="#fff" /> </Text>
        </TouchableOpacity>
        </View>
        <FlashMessage position="top" />
      </View>
    );
  }
}

const styles = StyleSheet.create({
   
container1: {
    flex: 1,
  },
  bottomView: {
    width: 75,
    height: 75,
  borderRadius: 150,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute', //Here is the trick
    bottom: 25, //Here is the trick
  right:25,
  paddingLeft:5

  },
  scene: {
    flex: 1,
  },
  imageback: {
    width: 24,
    height: 24,
  },
   tabStyle: {
 
    backgroundColor: theme.colors.secondary,
  },
  modalInfo:{
    alignItems:'center',
    paddingTop:0,
  },
  topbg:{backgroundColor:theme.primary},
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.5,
    zIndex:1000000,
    justifyContent: 'center',
    alignItems: 'center'
  },
 container:{
    flex:1,

  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    backgroundColor:'#fff',
  marginTop:-10,
  height:170,
  
  
  }, buttons: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      justifyContent: 'center',
    },
	 catrow: {
      flexDirection: 'row',
      paddingVertical: 2,
      backgroundColor:'#ffffff',
      
    },
    button: {
      flex: 1,
      alignSelf: 'center'
    },
  userInfo: {
      flexDirection: 'row',
      paddingVertical: 10,
      marginTop:10,
      backgroundColor:'#ffffff'
    },
bordered: {

      borderTopWidth: 1,
      borderColor: '#ccc',
      borderBottomWidth: 1,
    },
  section: {
      flex: 1,
      alignItems: 'center'
    },
    space: {
      marginBottom: 3,
      color: '#ccc'
    },
  rating:{marginLeft:0},
  modelname:{flexDirection: 'row',
      flex:1,
      alignItems: 'center',marginTop:10,},
  containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
    marginTop:10,
   },
  containertop:{
    flex:1,
    
  
  
  },
  separator: {
      backgroundColor: '#ccc',
      alignSelf: 'center',
      flexDirection: 'row',
      flex: 0,
      width: 1,
      height: 20
    },
  searchbar:{marginTop:0},
  header:{
    backgroundColor: "#00CED1",
    height:200
  },
  headerContent:{
    padding:30,
    alignItems: 'center',
    flex:1,
  },
  detailContent:{
    top:80,
    height:300,
    width:Dimensions.get('screen').width - 90,
    marginHorizontal:30,
    flexDirection: 'row',
    position:'absolute',
    backgroundColor: "#ffffff"
  },
  userList:{
    flex:1,
  },
  cardContent: {
    marginLeft:10,
    marginTop:5
  },
  image:{
    width:80,
    height:90,
    marginTop:5
  
  },
  imagemodel:{
    width:150,
    height:150,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
verified:{
    width:80,
    height:20,
    marginTop:5,
   
  },
modalInfo:{

    justifyContent:'center',
  },
 cardbutton:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '37%',
    padding: 5,

    flexDirection:'row'
  },
  cardbutton1:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '27%',
    paddingLeft: 10,

    flexDirection:'row'
  },
  card:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
    backgroundColor: "#ffffff",
    flexBasis: '46%',
    padding: 5,
  padding: 5,
    flexDirection:'row'
  },
 namemodel:{
    fontSize:14,

  marginLeft:5,
    color:"#fff",
    alignSelf:'center',
    fontWeight:'bold',


  },

  name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  bname:{
    fontSize:17,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:10,
    color:"#fff",
    fontWeight:'bold',

  },
  position:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#696969"
  },
  positionmodel:{
    fontSize:14,
    color:"#fff"
  },
  about:{
    marginHorizontal:10
  },

});