import {
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItems
} from '@react-navigation/drawer';
import * as React from 'react';
import CustomMenuSidebar from './CustomMenuSidebar';
import { View, StyleSheet,Image,ImageBackground,SafeAreaView,ScrollView } from "react-native";
export default class DrawerComponent extends React.Component {
  render() {
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView>
          <View style={{ backgroundColor: "white" }}>
            <CustomMenuSidebar navi={this.props.navigation}/>
          </View>
  
        </ScrollView>
      </SafeAreaView>
    );
  }
}