import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,Button,Image,TouchableOpacity,Alert,ActivityIndicator} from 'react-native';
import RNUpiPayment from 'react-native-upi-pay';
import lib from '../core/lib'
import config from '../core/global'
import Icon from 'react-native-vector-icons/Ionicons';
import { theme } from '../core/theme'
import { SERVER_URL,SERVER } from '../core/settings'
import { Rating,PricingCard} from 'react-native-elements';
import RNDateTimePicker from '@react-native-community/datetimepicker';
import {TextInput} from 'react-native-paper';
import Toast from 'react-native-toast-message';
const img = require('../image/upi.png');
type Props = {};
global.udata = null;
global.libs = null;global.ainfo = null;
const status=['offline','online','idle','busy','away','in meeting','vacation'];
const statuscol={'online':'green','offline':'grey','idle':'orange','busy':'red','away':'orange','in meeting':'red','vacation':'blue'};
const vr=require("../assets/verified.png");
const uvr=require("../assets/tick.png");
const colors=['#ccc',theme.colors.secondary,'red','#000'];
let d=new Date();
export default class newappoinment extends Component<Props> {
	  constructor(props){
        super();
        this.state={
			udata:null,isLoading:false,times:[],
            Status:"", 
            txnId:"",
            GOOGLE_PAY:'GOOGLE_PAY',
            PHONEPE:'PHONEPE',
            PAYTM:'PAYTM',show:false,
            message:"",datetxt:d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate()
        }
	  }

 successCallback(data){
            //
            console.log(data);
            that.setState({Status:"SUCCESS"});
            that.setState({txnId:data['txnId']});
            that.setState({message:"Succccessfull payment"});
        }
settimecall(data,index){
            //
            console.log(data);
            if(data[1]==3){alert("The time has Already been scheduled with other.");}
			else if(data[1]==0){alert("The lawyer is not avilable");}
			else if(data[1]==2){alert("this is lunch time.");}
			else{
				Alert.alert( "Appoinment Messege","Are you sure to schedule a meeting?",[
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        { text: "OK", onPress: () => {this.apconfirm(data,index)}}
      ],
      { cancelable: false })
				}
        }
apconfirm(data,index){
            obj.setState({ isLoading: true });this.state.times[index][1]=3;let dxt=this.state.times;
			
			 let op={'success':function(d){obj.setState({ isLoading: false });console.log(d)
			 //obj.showpushnotification(udata);
			Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Successfully appoinment has been sheduled...',
      text2: '...',
	  onHide: () => {obj.props.navigation.navigate('appoinment');},
    }); 
			
			 },'type':'text','trace':true}
			 let pd={'session':config.uinfo[2],'uid':config.uinfo[0]}
			 pd['lid']=udata['lid'];pd['slot_date']=this.state.datetxt;pd['interval_time']=ainfo['interval_time'];pd['type']=0;pd['slot_time']=data[0];
			 lib.postdata('?op=scheduleAppoinments',pd,op);
            // in case no action taken
			this.setState({ times: dxt });
            
        }
	value(n,v){
		if(n==1){return [status[v],statuscol[status[v]]]}
		else if(n==0 && v==1){return vr} 
		else if(n==0 && v==0){return uvr}
	}
componentDidMount() {global.obj=this;global.uinfo=config.uinfo; udata=this.props.route.params;global.libs=lib;
let op={'success':function(d){obj.setState({ isLoading: false });console.log('>>>>>>>>>>>>>',d.info);obj.setState({ times: d.data });ainfo=d.info;
			
			 },'type':'json','trace':true}
			let pd={'session':config.uinfo[2],'uid':config.uinfo[0]}
			pd['lid']=udata['lid'];pd['date']=this.state.datetxt;
			lib.postdata('?op=timeAppoinment',pd,op);

}
dChange = (event, d) => {
	if(event.type != "set") {
    return
    } 
    const currentDate = d || this.state.datetxt;console.log(d.getMonth(),d);
    //setShow(Platform.OS === 'ios');
    this.setState({datetxt:d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate(),show: Platform.OS === 'ios' ? true : false,});// this.setState({show:false});
	let op={'success':function(d){obj.setState({ isLoading: false });console.log('>>>>>>>>>>>>>',d.data);obj.setState({ times: d.data });
			
			 },'type':'json','trace':true}
			let pd={'session':config.uinfo[2],'uid':config.uinfo[0]}
			pd['lid']=udata['lid'];pd['date']=this.state.datetxt;
			lib.postdata('?op=timeAppoinment',pd,op);
	return true
  };
  render() {
	  udata=this.props.route.params;
	 console.log(udata,"<<<<<<<<<<<<=====================================");
	 // let payam=" Pay "+this.props.route.params.data['fee'] + ' & Continue'
      let item=udata.uinfo;
	  let st=this.value(1,item.status)
		  let verifyimage=this.value(0,item.verified)
		  let image= SERVER+item.image
		  let dis=item.distance?parseFloat(item.distance).toFixed(2)+' km':null; 
        let n=0;let v,v1=null;
    return (
			<><Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:10000}} />
          <View style={{height:"100%"}}>
		   
    <View style={{backgroundColor:theme.colors.primary,height:70}}> 
   <TouchableOpacity onPress={()=>{this.props.navigation.navigate('homeScreen');}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: 'white',}} />
   </TouchableOpacity>
    <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18}}>Schedule new Appoinment </Text></View>
       </View> 
       <View style={{flex:1,backgroundColor:"#fff"}}>
        <View style={{marginTop:20}}>
       <View  style={{flexDirection: 'row',width:"100%",paddingLeft:10}}>
				<Image style={styles.image} onError={({ nativeEvent: {error} }) => console.log('eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',error) } source={{uri: image}}/>
              <View style={styles.cardContent}>
                <View style={{flex: 1, flexDirection: 'row', justifyContent: 'flex-start'}}>
        <View style={{width: '60%', height: 90}} >
		<Text style={styles.name}>{item.name}</Text>
        <View style={{flex: 1, flexDirection: 'row'}} ><Icon name="location" style={{ fontSize: 18 ,color: '#000',}} /><Text style={styles.position}>{item.position} </Text>
		{dis && <Text style={{color:'green',fontWeight:'bold'}}>{dis}</Text>}
		</View>
		
        <View style={{flex: 1, flexDirection: 'row'}} >
        <Icon name="ellipse-sharp" style={{ fontSize: 14 ,color: st[1],marginLeft:3}} /><Text style={styles.position}>{st[0]}</Text></View>
		</View>
        <View style={{width: '27%', height: 100,justifyContent: 'space-between',alignItems: 'center',}}>
		 <Image style={styles.verified} source={verifyimage}/>
     
		 <View style={{flex: 1, flexDirection: 'column',justifyContent: 'space-between',marginTop:10}} ><Rating imageSize={15} readonly startingValue={parseFloat(item.rating)} style={{marginRight:25}} /></View>
		</View>
        
      </View>
              </View>

	  </View>
      
</View>
 	<View style={{alignItems:'center',marginTop:15,flexDirection: 'row',marginLeft:15}}><Text style={{fontWeight:'bold',color:'#000',fontSize:18}}>Select Time </Text>
	<TouchableOpacity  onPress={()=>{this.setState({show:true});}}><Icon style={{ width: 25, height: 25, marginLeft: 5,marginRight: 5}}  name="calendar-outline" size={25} color="#000" /></TouchableOpacity><Text style={{fontWeight:'bold',color:'#000',fontSize:18}}>{this.state.datetxt}</Text></View>
	<View style={{alignItems:'center',marginTop:15}}>	  
	  
         {this.state.show && (<RNDateTimePicker value={new Date()} minuteInterval={5} onChange={this.dChange} />)}</View>
    <View style={{alignItems:'center',marginTop:15,marginLeft:5,marginRight:5,flex:2}}>
	 
	{this.state.times.map((item, index) => {
		n+=1;
		if(n==1){v=(<TouchableOpacity onPress={()=>{this.settimecall(item,index)}} style={{height:30,width:"48%",backgroundColor:colors[item[1]],margin:5,alignItems:'center',paddingTop:5}}>
  <Text style={{color:'#fff'}}>{item[0]}</Text>
   </TouchableOpacity>);}
		else{
			v1=( <TouchableOpacity  onPress={()=>{this.settimecall(item,index)}} style={{height:30,width:"48%",backgroundColor:colors[item[1]],margin:5,alignItems:'center',paddingTop:5}}>
  <Text style={{color:'#fff'}}>{item[0]}</Text>
   </TouchableOpacity>);n=0;
				return(<View key={index} style={{flexDirection:'row'}}>{v}{v1}</View>)}})}
	</View>
        
        </View>
	{this.state.isLoading &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoading} size="large" color={theme.colors.primary} />
   </View>}
      </View></>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
           
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
   image:{
    width:80,
    height:90,
   	marginRight:15,
	
  }, textInput: {
        borderRadius: 5,
        borderWidth: 0,
        height: Platform.OS === "ios" ? 60 : 80,
        fontSize: 16,
        paddingHorizontal: 10,
        marginHorizontal: 15,
        padding: 10,
        marginLeft: 5,
		
    },
    name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
	marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});