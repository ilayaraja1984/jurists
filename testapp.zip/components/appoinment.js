import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions ,
  Modal,ScrollView, StatusBar} from 'react-native';
import {useRoute} from '@react-navigation/native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
import PushNotification, {Importance} from 'react-native-push-notification';
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { Rating,Button,PricingCard} from 'react-native-elements';
import {RadioButton , HelperText,TextInput,List} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Ionicons';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'

import BackButton from '../helper/BackButton'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL,SERVER } from '../core/settings'
import eImage from '../assets/user.png'
import Toast from 'react-native-toast-message';
import config from '../core/global'
import { TabView, SceneMap , TabBar } from 'react-native-tab-view';
import Form from '../helper/Form'
//Define a color for toolbar
import RNDateTimePicker from '@react-native-community/datetimepicker';
var { findNodeHandle } = React;
//type Props = {};
const FirstRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const SecondRoute = () => <View style={[ styles.container, { backgroundColor: '#ffffff' } ]} />;
const apstatus = ['Waiting','Call','Cancelled'];
const {height, width} = Dimensions.get('window');
const STATUS_BAR = StatusBar.statusBarHeight || 24;
const initialLayout = { width: Dimensions.get('screen').width,height:30 };
let uid=0;
global.obj = null;
global.uinfo = null;
const logo = require('../assets/user.png');
const statusopt={'3':['waiting','pay','cancelled','confirmed','initiated','unanswered','in process','closed'],'2':['accept','scheduled','cancelled','confirmed','initiated','unanswered','in process','closed']}
export default class appoinment extends Component<Props> {
constructor(route, navigation ,props) {
    super(props);
    this.bn()
	this._nodes = new Array()
    this.state ={
      isLoging:false,
      checkingAuth:true,cancelmodel:false,
      email:"",
	  adata:null,
	  show:false, setShow:false,datetxt:null,apstatus:0,
      password:"",
	image:Image.resolveAssetSource(eImage).uri,location:"",statusmode:0,
    name:"xxxxx",cid:0,olddata:null,
    cwt:0,
    mobile:"",expanded:true,lobjs:{},lobjs1:{},
    gender:"male",
    activecolor:"#000",
    malebg:'#2980B9',
    femalebg:'#ccc',
    nameError:'',
    psswordError:'',
    emailError:'',
    mobileError:'',
    userSelected:{},mcontentTitle:"Search Appoinments",mcontentbutton:null,mcontent:null,
	modalVisible:false,modelcontent:null,
    routes:[
    { key: 'first', title: 'About' },
    { key: 'second', title: 'Review' },
    { key: 'category', title: 'Category' },
    
  ],index:0, setIndex:0,
    }
  
  }
    setconfim(item){ //this.props.navigation.setParams({query: 'someText',});
	
   this.state.lobjs[item.aid].setNativeProps({style: {display:'none'} });
   this.state.lobjs1[item.aid].setNativeProps({style: {display:"flex"} })
	 }
   _handleProfile(item,n=0){ //this.props.navigation.setParams({query: 'someText',});
    console.log('pppppppppppppppppppppppppppppppppppppppp998888888888888888888',item);
	this.setState({cid:item.aid});
	if(n==1){
		if(item.status==0){ 
		if(uinfo[3]==2){
				Alert.alert( "Appoinment Messege","Are you sure to confirm?",[
        {
          text: "Cancel",
          onPress: () => console.log("Cancel Pressed"),
          style: "cancel"
        },
        { text: "OK", onPress: () => {this.apconfirm()}}
      ],
      { cancelable: false })
			
			}
		else{Alert.alert( "Appoinment Messege","Waiting for confirmation")}}
		
		if(item.status==1 && uinfo[3]!=2){ this.props.navigation.navigate('payment',{'data':item});}
		else if(item.status==1){  Alert.alert( "Appoinment Messege","Already confirmed..");}
		if(item.status==2){ Alert.alert( "Appoinment Messege","Already cancelled..")}
		if(item.status==3){ item.name=item.username;if(config.peer){config.peer.conses();}
	    item['startcall']=1;
			obj.props.navigation.navigate('call',{'data':item,'startcall':1,id:item.id});
            
			console.log(item)}
		}
	else{this.setModalVisible(false);this.setState({cancelmodel:true})}
    return true
}
tm(){
	
	setInterval(function(){
      if(config.screen1==25){obj.props.navigation.navigate('myList',{'data':25});config.screen1=null}
	  console.log(config.screen1)
    },  1000);
}
showpushnotification(item)
{
	
	PushNotification.cancelAllLocalNotifications();
	/*PushNotification.localNotification({

  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: "My Notification Title", // (optional)
  message: "My Notification Message", // (required)
  data:{id:25},
  actions: '["Call", "Cancel"]',
 
});*/
	//console.log(item,'======================');
	PushNotification.localNotificationSchedule({
  //... You can use all the options from localNotifications
  channelId: "juristz-id", // (required) channelId, if the channel doesn't exist, notification will not trigger.
  title: "Appoinment Scheduled", // (optional)
  message: "Appoinment time is "+item.time+", call "+item.username, // (required)
  date: new Date(Date.now() + 60 * 100), // in 60 secs
  data:item,
  actions: '["Call", "Cancel"]',
  allowWhileIdle: false, // (optional) set notification to work while on doze, default: false
  
  /* Android Only Properties */
  repeatTime: 1, // (optional) Increment of configured repeatType. Check 'Repeating Notifications' section for more info.
});
}
createChannel()
{
	PushNotification.createChannel(
    {
      channelId: "juristz-id", // (required)
      channelName: "juristz", // (required)
      channelDescription: "A channel to categorise your notifications", // (optional) default: undefined.
      playSound: false, // (optional) default: true
      soundName: "default", // (optional) See `soundName` parameter of `localNotification` function
      importance: Importance.HIGH, // (optional) default: Importance.HIGH. Int value of the Android notification importance
      vibrate: true, // (optional) default: true. Creates the default vibration pattern if true.
	  color: "red", 
	  actions: ["Yes", "No"],
	  id: 0,
    },
    (created) => console.log(`createChannel returned '${created}'`) // (optional) callback returns whether the channel was created, false means it already existed.
  );
}




apconfirm(){
	obj.setState({ isLoading: true });obj.setState({ statusmode: 1});
	 let op={'success':function(d){obj.setState({ isLoading: false });
	// let info =d['data'];
	//console.log("=======================>>>>>>>>>>>>>>>>>>>>",obj.state.olddata);
	 obj.showlist(obj.state.olddata);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 
	 let pd={'session':uinfo[2],'uid':uinfo[0]}
	 
	 pd['id']=this.state.cid;
	 this.postdata(SERVER_URL+'?op=confirmAppoinments',pd,op);
	}
apstatusb(n,item={}){
	//console.log(uinfo,"0000000000000000000000000000000000000000000000000000000000000000")
	return n==3 && item.stime==1?'Call':statusopt[uinfo[3]][n];
	/*if(uinfo[3]==2 && n==0){return 'confirm'}
	else if(uinfo[3]==2 && n==1){return 'confirmed'}
	else{return apstatus[n]}*/
	
	}

   apdataview(item)
   {
	  if(item.username!=0)
	  {          
	        
	         let image= SERVER+item.image;let tv=null;
			   if(this.state.cid==item.aid && this.state.statusmode==2){item.status=2;}
			    if(this.state.cid==item.aid && this.state.statusmode==1){item.status=3;}
	            if(item.status!=2 && item.status<=1){
					tv= (<><TouchableOpacity onPress={() => {this._handleProfile(item,0)}} ><Text style={{marginRight: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}}>Cancel</Text></TouchableOpacity><Text style={{marginRight: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}}>|</Text></>)}

				return(<View  style={{flexDirection: 'row',width:"100%",paddingLeft:10}}>
				<Image style={styles.image} source={{uri:image}}/>
				<View  style={{flexDirection: 'column',paddingLeft:5}}>
				<Text style={{marginLeft: 5,fontSize: 20,fontWeight:"bold" }}>{item.username}</Text>
				<View  style={{flexDirection: 'row',}}>
				<View  style={{width:"30%"}}><Text style={{marginLeft: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}}>{item.time}</Text></View>
				<View  style={{width:"55%",flexDirection: 'row',alignItems:"flex-end",justifyContent: 'flex-end'}} ref= {(ref) => this.state.lobjs[item.aid]=ref}>
				
				{tv}
				
				 <TouchableOpacity onPress={() => {this._handleProfile(item,1)}}>
				 <Text style={{marginRight: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}} >{this.apstatusb(item.status,item)}</Text>
	 
				 </TouchableOpacity>
				</View>
				<View  style={{width:"55%",flexDirection: 'row',alignItems:"flex-end",justifyContent: 'flex-end',display:'none'}} ref= {(ref) => this.state.lobjs1[item.aid]=ref}>
				<Text style={{marginRight: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}} >Done</Text>
				</View>
				</View>
				</View>
				</View>)  
	   } 
	   else{return(<View><Text style={{marginLeft: 10,fontSize: 20 }}>No Appoinments</Text></View>)}
   }
   showlist(data){
	   //console.log(data,data.length)
	 if(!data || data.length==0){this.setState({adata:(<View style={{alignItems:"center"}}><Text style={{marginLeft: 10,fontSize: 20 }}>No Data Available.</Text></View>)});return}
	 let rd= data.map((item, index) => {
				return(<View style={{backgroundColor:"#fff",paddingBottom:10}} key={index}>
					   
				 <View style={styles.col}>
				  <View style={styles.catrow}>
				 <Icon style={{ width: 25, height: 25, marginLeft: 5,marginRight: 5}}  name="calendar-outline" size={25} color="#000" />
				
				<Text style={{marginLeft: 10,fontSize: 20,fontWeight:"bold" }}  >
					{item.date}
				</Text>
				
				<View><Text style={{marginLeft: 10,fontSize: 20,color:"#ccc" }} >
					{item.day}
				</Text></View>
				</View>
				 <View style={{borderWidth:1,borderRadius: 5,alignItems: 'center',marginLeft:10,marginRight:10,paddingBottom:10,paddingTop:10,backgroundColor:"#fff"}}>
				  {this.apdataview(item)}</View>
				 
					  
				</View>
                </View>)
              
            }); 
	 
	 this.setState({olddata:data});
	//console.log("$$$$$$$$$$$$$$$>>>>",this.state.olddata);
	 this.setState({adata:rd}); 
   }
   

   bn() {
//this.setState({userSelected:this.props.route.params});
  return true 
}
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
    if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
    this.setState({ gender: v});
  }
   async getitems()
{
  let uid=await AsyncStorage.getItem('uid');
  let id=await AsyncStorage.getItem('id');
  let session=await AsyncStorage.getItem('session');
  let role=await AsyncStorage.getItem('role');
  let scren=await AsyncStorage.getItem('screen');
  return [uid,id,session,role,scren]
}

setModalVisible(visible) {
    this.setState({modalVisible: visible});
  }
  
 isArray ( obj ) {return typeof(obj)=='object'?true:false;}
 isFun(o){if(o){if(typeof o === "function"){return true}} return false}
 opcheck(t,v,a){if(a[t]){if(a[t]==v){return true}} return false}
postdata(url,data={},op={}){
	 console.log(url,' =>>>>> request called ',op);
	 let res=null;let resx=null;
	 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> request called ');}
	  console.log(url,' =>>>>> request called ');
	 var formData = new FormData();
	     if(this.isArray(data)){
		 let k=Object.keys(data);
	     for(var i=0;i<k.length;i++){formData.append(k[i], data[k[i]]);}
		// console.log(formData,'test=================>>>>>');return formData;
		 }
		if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> started ');}
		fetch(url, {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => {resx=response;return this.opcheck('type','text',op)?response.text():response.json();})
      .then((responseJson) => {
			 if(this.opcheck('trace',true,op)){console.log(url,' =>>>>> responce recived ');console.log(responseJson,' =>>>>> responce ');}
			 if(this.isFun(op['success'])){op['success'](responseJson)}})
	   
      .catch((error) => {
		if(this.isFun(op['error'])){op['error'](error)}
		console.log(resx.text());
         console.error(error);
      });	  
	 return
 }
 
 cancelap(r){
	  obj.setState({ isLoading: true });this.setState({cancelmodel: false});obj.setState({ statusmode: 2});
	 let op={'success':function(d){obj.setState({ isLoading: false });
	// let info =d['data'];
	console.log("=======================>>>>>>>>>>>>>>>>>>>>",d);
	 obj.showlist(obj.state.olddata);
	 },'type':'text','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 
	 let pd={'session':uinfo[2],'uid':uinfo[0]}
	 if(this.state.datetxt!=null){pd['date']=this.state.datetxt;}
	 pd['id']=this.state.cid;pd['reason']=r;
	 this.postdata(SERVER_URL+'?op=cancelAppoinments',pd,op);
	  this.setState({modalVisible: false});
	 }
	 searchap(ap){
	  obj.setState({ isLoading: true });
	 let op={'success':function(d){obj.setState({ isLoading: false });
	 let info =d['data'];
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 
	 let pd={'session':uinfo[2],'uid':uinfo[0]}
	 if(this.state.datetxt!=null && ap!=10){pd['date']=this.state.datetxt;}
	 if(ap!=10){pd['status']=ap;}pd['search']=1;
	 this.postdata(SERVER_URL+'?op=clientAppoinments',pd,op);
	  this.setState({modalVisible: false});
	 }
async componentDidMount() {
	 this.createChannel();
	 let ds=await this.getitems(); global.obj=this;global.uinfo=ds;
	 let op={'success':function(d){obj.setState({ isLoading: false });
	 let info =d['data'];console.log("pppppppppppppppppppppppppppppp");
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let pd={'session':ds[2],'uid':ds[0]}
	 this.postdata(SERVER_URL+'?op=clientAppoinments',pd,op);config.obj=this;
	 //this.tm();
	 //let d=new Date();
	 //this.setState({datetxt:d.getFullYear()+'/'+d.getMonth()+'/'+d.getDate()})
}
handlePress = () => {this.setState({expanded:false})};
dChange = (event, d) => {
	if(event.type != "set") {
    return
    } 
    const currentDate = d || this.state.datetxt;console.log(d);
    //setShow(Platform.OS === 'ios');
    this.setState({datetxt:d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate(),show: Platform.OS === 'ios' ? true : false,});// this.setState({show:false});
	return true
  };
 //async componentDidMount() {this.setState({userSelected:this.props.route.params});}
  render() {
	  
	 if(typeof(this.props.route.params)!= "undefined"){this.setconfim(this.props.route.params.data);}
    //const { route } = this.props
	const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	let date = new Date();
// add a day
let tomorrow= new Date(date.setDate(date.getDate() + 1));
    console.log(months[tomorrow.getMonth()],tomorrow.getDate())
  // console.log("<>",this.props.route.params,"<>")
  // let info=this.state.info;
  // let image= SERVER+info.image
    return (
    <View style={{height:"100%"}}>
    <View style={{backgroundColor:theme.colors.primary,flexDirection:'row',height:50,paddingTop:10}}> 
   <TouchableOpacity  onPress={() => {this.props.navigation.openDrawer();}}><Icon name="menu" style={{fontSize: 30 ,color:'#fff',left:5,marginRight:5}} />
		</TouchableOpacity>
    <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18,marginTop:5}}>My Appoinments </Text></View>
    <View style={styles.modalInfo}>

    </View>

       <View style={styles.buttons}>
                    
                      
                     
                      </View>
    </View> 
<View style={{  paddingBottom:10,}}>
<ScrollView style={styles.scrollView}><View style={{paddingBottom:70}}>{this.state.adata}</View></ScrollView>
</View>
<View style={styles.bottomView}>
           <TouchableOpacity onPress={()=>{this.setModalVisible(true);}}>
		   <Text style={styles.textStyle}><Icon name="search" size={35} color="#fff" /> </Text>
		    </TouchableOpacity>
        </View>
		<Modal
          animationType={'fade'}
          transparent={true}
          onRequestClose={() => this.setModalVisible(false)}
          visible={this.state.modalVisible}>

          <View style={styles.popupOverlay}>
            <View style={styles.popup}>
			  <View style={{height:35,backgroundColor:theme.colors.primary,borderColor:'#fff',borderTopWidth:0.5,borderLeftWidth:1,borderRightWidth:1}}> 
                    <Text style={{color:'#fff',fontSize:15,fontWeight:'bold',marginLeft:15,marginTop:5}}>Search Appoinments</Text>
              </View>
              <View style={styles.popupContent}>
			  
               <View style={styles.popupContent1}> 
			  <TextInput
      label="Select Date"
      value={this.state.datetxt}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({show:true}) }} />}
    />              
         {this.state.show && (<RNDateTimePicker value={new Date()} minuteInterval={5} onChange={this.dChange} />)}
      <List.Section>
      <List.Accordion
        title="Appoinment Status"
        left={props => <List.Icon {...props} icon="calendar" />}
        expanded={this.state.expanded}
        onPress={this.handlePressl}>
		  <List.Item title="All" onPress={()=>{this.searchap(10)}}/>
        <List.Item title="Waiting" onPress={()=>{this.searchap(0)}}/>
        <List.Item title="Confirmed"  onPress={()=>{this.searchap(1);}} />
		<List.Item title="Cancelled"  onPress={()=>{this.searchap(2);}} />
		<List.Item title="Closed"  onPress={()=>{this.searchap(7);}} />
      </List.Accordion>
    </List.Section>   
				
              </View>
              </View>
              <View style={styles.popupButtons}>
			  <Button
  onPress={() => {this.setModalVisible(false) }}
  title="Close" type="clear"
/>
   <Button
  onPress={() => {this.setState({datetxt:null}) }}
  title="Clear Date" type="clear"
/>         
			</View>
            </View>
          </View>
        </Modal>
		
		
		<Modal
          animationType={'fade'}
          transparent={true}
          onRequestClose={() => {this.setModalVisible(false);this.setState({cancelmodel:false})}}
          visible={this.state.cancelmodel}>

          <View style={styles.popupOverlay}>
            <View style={styles.popup}>
			  <View style={{height:35,backgroundColor:theme.colors.primary,borderColor:'#fff',borderTopWidth:0.5,borderLeftWidth:1,borderRightWidth:1}}> 
                    <Text style={{color:'#fff',fontSize:15,fontWeight:'bold',marginLeft:15,marginTop:5}}>Appoinment</Text>
              </View>
              <View style={styles.popupContent}>
			  
               <View style={styles.popupContent1}> 
			  
      <List.Section>
      <List.Accordion
        title="Appoinment Cancel Reasons"
        left={props => <List.Icon {...props} icon="calendar" />}
        expanded={this.state.expanded}
        onPress={this.handlePressl}>
        <List.Item title="I'm busy" onPress={()=>{this.cancelap("I'm busy")}}/>
        <List.Item title="Change Date & Time"  onPress={()=>{this.cancelap("Change Date & Time" );}} />
		<List.Item title="Change Time"  onPress={()=>{this.cancelap("Change Time");}} />
      </List.Accordion>
    </List.Section>   
				
              </View>
              </View>
              <View style={styles.popupButtons}>
			  <Button
  onPress={() => {this.setState({cancelmodel:false})}}
  title="Close" type="clear"
/>
           
			</View>
            </View>
          </View>
        </Modal>
		
		 {this.state.isLoading &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoading} size="large" color={theme.colors.primary} />
   </View>}
      </View>
    );
  }
}

const styles = StyleSheet.create({
   
container1: {
    flex: 1,
  },
  scene: {
    flex: 1,
  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
           
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  scrollView: {
    backgroundColor: '#fff',
    marginHorizontal: 5,
	height:height-(STATUS_BAR+60)
  },
  imageback: {
    width: 24,
    height: 24,
  },
   bottomView: {
    width: 75,
    height: 75,
	borderRadius: 150,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute', //Here is the trick
    bottom: 25, //Here is the trick
	right:25,
	paddingLeft:5

  },
  textStyle: {
    color: '#fff',
    fontSize: 18,
  },
  textInput: {
        borderRadius: 5,
        borderWidth: 0,
        height: Platform.OS === "ios" ? 60 : 80,
        fontSize: 16,
        paddingHorizontal: 10,
        marginHorizontal: 15,
        padding: 10,
        marginLeft: 5
    },
   tabStyle: {
 
    backgroundColor: theme.colors.secondary,
  },
  modalInfo:{
    alignItems:'center', paddingTop:10,
   
  },
  topbg:{backgroundColor:theme.primary},
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.5,
    zIndex:1000000,
    justifyContent: 'center',
    alignItems: 'center'
  },
 container:{
    flex:1,

  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    backgroundColor:'#fff',
  marginTop:-10,
  height:170,
  
  
  }, buttons: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      justifyContent: 'center',
    },
	 catrow: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      
    },
    button: {
      flex: 1,
      alignSelf: 'center'
    },
  userInfo: {
      flexDirection: 'row',
      paddingVertical: 10,
      marginTop:10,
      backgroundColor:'#ffffff'
    },
bordered: {

      borderTopWidth: 1,
      borderColor: '#ccc',
      borderBottomWidth: 1,
    },
  section: {
      flex: 1,
      alignItems: 'center'
    },
    space: {
      marginBottom: 3,
      color: '#ccc'
    },
  rating:{marginLeft:0},
  modelname:{flexDirection: 'row',
      flex:1,
      alignItems: 'center',marginTop:10,},
  containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
    marginTop:10,
   },
  containertop:{
    flex:1,
    
  
  
  },
  separator: {
      backgroundColor: '#ccc',
      alignSelf: 'center',
      flexDirection: 'row',
      flex: 0,
      width: 1,
      height: 20
    },
  searchbar:{marginTop:0},
  header:{
    backgroundColor: "#00CED1",
    height:200
  },
  headerContent:{
    padding:30,
    alignItems: 'center',
    flex:1,
  },
  detailContent:{
    top:80,
    height:300,
    width:Dimensions.get('screen').width - 90,
    marginHorizontal:30,
    flexDirection: 'row',
    position:'absolute',
    backgroundColor: "#ffffff"
  },
  userList:{
    flex:1,
  },
  cardContent: {
    marginLeft:10,
    marginTop:5
  },
  image:{
    width:50,
    height:60,
    marginTop:5
  
  },
  imagemodel:{
    width:150,
    height:150,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
verified:{
    width:80,
    height:20,
    marginTop:5,
   
  },
modalInfo:{

    justifyContent:'center',
  },
 cardbutton:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '37%',
    padding: 5,

    flexDirection:'row'
  },
  cardbutton1:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '27%',
    paddingLeft: 10,

    flexDirection:'row'
  },
  card:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
    backgroundColor: "#ffffff",
    flexBasis: '46%',
    padding: 5,
  padding: 5,
    flexDirection:'row'
  },
 namemodel:{
    fontSize:14,

  marginLeft:5,
    color:"#fff",
    alignSelf:'center',
    fontWeight:'bold',


  },

  name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  bname:{
    fontSize:17,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:10,
    color:"#fff",
    fontWeight:'bold',

  },
  position:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#696969"
  },
  positionmodel:{
    fontSize:14,
    color:"#fff"
  },
  about:{
    marginHorizontal:10
  },
popup: {
    backgroundColor: 'white',
    marginTop: 90,
    marginHorizontal: 0,
    borderRadius: 0,
  },
  popupOverlay: {
    backgroundColor: "#00000057",
    flex: 1,
    marginTop: 10
  },
  popupContent: {
    //alignItems: 'center',
    margin: 5,
	 marginTop: 15,
    
  },
  popupContent1: {
    //alignItems: 'center',
    margin: 5,
	marginTop: 15,
    
  },
  
  popupHeader: {
    marginBottom: 45
  },
  popupButtons: {
    marginTop: 15,
    flexDirection: 'row',
    borderTopWidth: 1,
    borderColor: "#eee",
    justifyContent:'center'

  },
  popupButton: {
    flex: 1,
    marginVertical: 16
  },
  btnClose:{
    height:20,
    backgroundColor:'#20b2aa',
    padding:20
  },
  modalInfo:{
    alignItems:'center',
    justifyContent:'center',
  },
});