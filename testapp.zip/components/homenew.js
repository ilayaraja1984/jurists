import * as React from 'react';
import { View, StyleSheet, ScrollView,Text } from 'react-native';
import { Card, Button } from 'react-native-elements';

const BASE_URL = 'https://raw.githubusercontent.com/sdras/sample-vue-shop/master/dist';

const products = [
  {
    name: 'Khaki Suede Polish Work Boots',
    price: 149.99,
    img: `${BASE_URL}/shoe1.png`
  },
  {
    name: 'Camo Fang Backpack Jungle',
    price: 39.99,
    img: `${BASE_URL}/jacket1.png`
  },
  {
    name: 'Parka and Quilted Liner Jacket',
    price: 49.99,
    img: `${BASE_URL}/jacket2.png`
  },
  {
    name: 'Cotton Black Cap',
    price: 12.99,
    img: `${BASE_URL}/hat1.png`
  },
];

class HomeScreen extends React.Component {
    render() {
      return (
        <ScrollView
          style={{
            flexGrow: 0,
            width: "100%",
            height: "100%",
          }}>
          {
            products.map((product, index) => {
              return(
                <View style={styles.row} key={index}>
                    <View style={styles.col}>
                      <Card
            image={{uri: product.img}}>
            <Text style={{marginBottom: 10, marginTop: 20 }} h2>
                {product.name}
            </Text>
            <Text style={styles.price} h4>
                {product.price}
            </Text>
            <Text h6 style={styles.description}>
                added 2h ago
            </Text>
            <Button
  type="clear"
  title='Buy now'
  onPress={() => {console.log("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb xxxxxxxxxxxxxxxx",index.name);
  this.props.navigation.navigate('Details', {
    name: product.name,
    price: product.price,
    
  })}} />
        </Card>
                    </View>
                </View>
              )
            })
          }
        </ScrollView>
      );
    }
}

const styles = StyleSheet.create({
  row: {
      flex: 1,
      flexDirection: 'row',
      justifyContent: 'center',
  },
  col: {
      flex: 1,
  },
});

export default HomeScreen;