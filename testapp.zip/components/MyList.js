import React, {Component} from 'react';
import { Button,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  View,} from 'react-native'
import  {PanGestureHandler} from 'react-native-gesture-handler'
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import {PermissionsAndroid} from 'react-native';
import WebrtcSimple from 'react-native-webrtc-simple';

import {
  globalCall,
  globalCallRef,
  GlobalCallUI,
} from 'react-native-webrtc-simple/UIKit';
type Props = {};
const configuration = {
      optional: null,
      key: Math.random().toString(36).substr(2, 4),
    };

export default class MyList extends Component<Props> {
   constructor(route, navigation ,props) {
    super(props);
   
    this.state ={
      isLoging:false,userId:null, setUserId:null,callId:'', setCallId:'',

    }
  
  }
   async requestCameraPermission () {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"App needs access to your camera ",
        buttonNeutral: "Ask Me Later",
        buttonNegative: "Cancel",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera permission given");
    } else {
      console.log("Camera permission denied");
    }
  } catch (err) {
    console.warn(err);
  }
}
 msg()
 {


 }
 callToUser = userId => {
    if (userId.length > 0) {
      const data = {
        sender_name: 'Sender Name',
        sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
      };
      WebrtcSimple.events.call(userId, data);
    } else {
      alert('Please enter userId');
    }
  };
async componentDidMount() {

  globalCall.start(configuration, sessionId => {
      this.setState({userId:sessionId});console.log('sid(********************************************',sessionId);
    });
  console.log('sid(********************************************');
}
    render() {
        
        return (
             <View style={styles.container}>
      <View>
        <Text style={{fontSize: 30}}>{this.state.userId}</Text>
      </View>

      <View style={styles.rowbtn}>
        <TextInput
          style={styles.textInput}
          autoCapitalize="none"
          keyboardType="default"
          placeholder="Enter id"
          onChangeText={text => {
            this.setState({callId:text});
          }}
        />
        <View style={styles.btn}>
          <Button
            title="Call"
            color={Platform.OS === 'ios' ? 'white' : 'black'}
            onPress={() => {
                this.callToUser(this.state.callId);
              
            }}
          />
          <Button
            title="Call1"
            color={Platform.OS === 'ios' ? 'white' : 'black'}
            onPress={() => {
                this.msg(this.state.callId);
              
            }}
          />
        </View>
      </View>
      <GlobalCallUI ref={globalCallRef} />
    </View>
        )
    }
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  rowbtn: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    alignItems: 'center',
    marginVertical: 8,
  },
  btn: {
    margin: 16,
    backgroundColor: 'black',
    paddingHorizontal: 10,
  },
  textInput: {
    width: 200,
    height: 50,
    borderWidth: 0.5,
    borderColor: 'gray',
    paddingHorizontal: 12,
  },})