import React, {Component} from 'react';
import { Button,
  Platform,
  StyleSheet,
  Text,
  TextInput,TouchableOpacity, Alert,Image,ActivityIndicator,Dimensions,
  View,} from 'react-native'
import Icon from 'react-native-vector-icons/Ionicons';
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import {PermissionsAndroid} from 'react-native';
import WebrtcSimple from 'react-native-webrtc-simple';
import { theme } from '../core/theme'
import {
  globalCall,
  globalCallRef,
  GlobalCallUI,
} from 'react-native-webrtc-simple/UIKit';
type Props = {};
const configuration = {
      optional: null,
      key: Math.random().toString(36).substr(2, 4),
    };

export default class call extends Component<Props> {
   constructor(route, navigation ,props) {
    super(props);
   
    this.state ={
      isLoging:false,userId:null, setUserId:null,callId:'', setCallId:'',

    }
  
  }
   async requestCameraPermission () {
  try {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.CAMERA,
      {
        title: "App Camera Permission",
        message:"App needs access to your camera ",
        buttonNeutral: "Ask Me Later",
        buttonNegative: "Cancel",
        buttonPositive: "OK"
      }
    );
    if (granted === PermissionsAndroid.RESULTS.GRANTED) {
      console.log("Camera permission given");
    } else {
      console.log("Camera permission denied");
    }
  } catch (err) {
    console.warn(err);
  }
}
 callToUser = userId => {
    if (userId.length > 0) {
      const data = {
        sender_name: 'Sender Name',
        sender_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
        receiver_name: 'Receiver Name',
        receiver_avatar:
          'https://www.atlantawatershed.org/wp-content/uploads/2017/06/default-placeholder.png',
      };
      WebrtcSimple.events.call(userId, data);
     // let objp=WebrtcSimple.conPeer(this.state.callId,userId, data);console.log('sid(********************************************',objp);
    } else {
      alert('Please enter userId');
    }
  };
async componentDidMount() {

  globalCall.start(configuration, sessionId => {
      this.setState({userId:sessionId});console.log('sid(*xxx********************',sessionId);
    
    });
  console.log('sid(********************************************');
}
    render() {
        let sid=config.notficationData.sid;
        this.callToUser(sid);

        let items=this.props.route.params.data;let image= SERVER+items.image;
        return (
             <View style={styles.container}>
             <View style={{height:70,backgroundColor:theme.colors.primary,width:"100%",justifyContent: 'center',alignItems: 'center'}}>
             <Text style={{marginLeft: 5,color:'#fff',fontSize: 20,fontWeight:"bold" ,}}>Connecting Server...</Text>
     </View> 
      <View style={{flex: 1,justifyContent: 'center',alignItems: 'center',}}>
        <Image style={{width:100,height:100,borderRadius: 150}} source={{uri:image}}/>
        <Text style={{marginTop: 25,fontSize: 20,fontWeight:"bold" ,}}>{items.name}</Text>
      </View>

      <View style={styles.rowbtn}>
        <TextInput
          style={styles.textInput}
          autoCapitalize="none"
          keyboardType="default"
          placeholder="Enter id"
          onChangeText={text => {
            this.setState({callId:text});
          }}
        />
        <View style={styles.btn}>
          <Button
            title="Call"
            color={Platform.OS === 'ios' ? 'white' : 'black'}
            onPress={() => {
                this.callToUser(this.state.callId);
              
            }}
          />
        </View>
      </View>
      <GlobalCallUI ref={globalCallRef} />
    </View>
        )
    }
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  rowbtn: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    alignItems: 'center',
    marginVertical: 8,
  },
  btn: {
    margin: 16,
    backgroundColor: 'black',
    paddingHorizontal: 10,
  },
  textInput: {
    width: 200,
    height: 50,
    borderWidth: 0.5,
    borderColor: 'gray',
    paddingHorizontal: 12,
  },})