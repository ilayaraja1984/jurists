import React from 'react';
import { View, Text } from 'react-native';

class DetailsScreen extends React.Component {

	constructor({ route, navigation ,props}){
		super(props)
	}

    render() {

    	const {name,price} =this.props.route.params;
    	console.log(name);
      return (
        <View>
            <Text>Details {name} {price}</Text>
        </View>
      );
    }
}

export default DetailsScreen;