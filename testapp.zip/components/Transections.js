import React, {Component} from 'react';
import {Platform,  Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions,ScrollView} from 'react-native';
import { theme } from '../core/theme'
import Icon from 'react-native-vector-icons/Ionicons';
import {TextInput,List} from 'react-native-paper';
import RNDateTimePicker from '@react-native-community/datetimepicker';
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
import lib from '../core/lib'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

type Props = {};
const statuscol=['red','red','green','blue','green','red'];
export default class transections extends Component<Props> {
	constructor(route, navigation ,props) {
    super(props);
    this.state ={
      isLoging:false,balance:0,adata:null,olddata:null,
      checkingAuth:true,cancelmodel:false,show:false,datetxt:null,
	  }
	}
dChange = (event, d) => {
	if(event.type != "set") {
    return
    } 
    const currentDate = d || this.state.datetxt;console.log(d);
    //setShow(Platform.OS === 'ios');
    this.setState({datetxt:d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate(),show: Platform.OS === 'ios' ? true : false,});// this.setState({show:false});
	let op={'success':function(d){obj.setState({ isLoading: false });
	let info =d['data'];console.log(info);obj.setState({ balance: d.balance });
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let ds=config.uinfo;
	 let pd={'session':ds[2],'uid':ds[0],'date':this.state.datetxt}
	 lib.postdata('?op=getTransections',pd,op);
	return true
  };
componentDidMount() {
	 global.obj=this;let ds=config.uinfo;
	 let op={'success':function(d){obj.setState({ isLoading: false });console.log(d);
	 let info =d['data'];obj.setState({ balance: d.balance });
	 obj.showlist(info);
	 },'type':'json','trace':true}
	 // s: 'raja' ,g:'male',l:'pppp',c:'crime'
	 let pd={'session':ds[2],'uid':ds[0]}
	 lib.postdata('?op=getTransections',pd,op);config.obj=this;
}
 showlist(data){
	   //console.log(data,data.length)
	 if(!data || data.length==0){this.setState({adata:(<View style={{alignItems:"center",marginTop: 10,}}><Text style={{marginTop: 10,fontSize: 20 }}>No Data Available.</Text></View>)});return}
	 let rd= data.map((item, index) => {
					   let cols={marginLeft: 10,fontSize: 20 ,color:statuscol[item.mode]};
				return(<View style={{backgroundColor:"#fff",paddingBottom:10}} key={index}>
					   
				 <View style={{borderBottomWidth:1,borderBottomColor:"#ccc"}}>
				  <View style={[styles.catrow,,backgroundColor:"#ccc"]}>
				 <Icon style={{ width: 25, height: 25, marginLeft: 5,marginRight: 5}}  name="calendar-outline" size={25} color="#000" />				
				 <Text style={{marginLeft: 10,fontSize: 20,fontWeight:"bold" }}  >
					{item.comment}
				</Text>
				<Text style={cols}  >
					{'\u20B9'}{item.amount}
				</Text>
				
				<View><Text style={{marginLeft: 10,fontSize: 20}} >
					{item.other}
				</Text></View>
				</View>
				<View style={{marginLeft:45,marginRight:10,paddingBottom:5,backgroundColor:"#"}}>
				  <Text style={{fontSize: 15}}  >Date : {item.date}</Text></View>
				 
					  
				</View>
                </View>)
              
            }); 
	 
	 this.setState({olddata:data});
	//console.log("$$$$$$$$$$$$$$$>>>>",this.state.olddata);
	 this.setState({adata:rd}); 
   }
  render() {
	 
	 let gbk=config.settings.role==2?'appoinment':'homeScreen';
	  
    return (
      <View style={{height:"100%"}}>
	  
	   <View style={{height:70,backgroundColor:theme.colors.primary,width:"100%"}}>
	   <TouchableOpacity onPress={()=>{this.props.navigation.navigate(gbk);;}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: '#fff',}} /> 
   </TouchableOpacity>
  <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18}}>
  <Text style={styles.textStyle}>
              Balance : {'\u20B9'}{this.state.balance}
            </Text> </Text></View>
       </View> 
 

<View style={{marginTop:2}}>
<TextInput
      label="Select Date"
      value={this.state.datetxt}
      right={<TextInput.Icon name="calendar-outline" onPress={() => {this.setState({show:true}) }} />}
    />              
         {this.state.show && (<RNDateTimePicker value={new Date()} minuteInterval={5} onChange={this.dChange} />)}
</View>
    <ScrollView style={styles.scrollView}><View style={{paddingBottom:70}}>{this.state.adata}</View></ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  catrow: {
      flexDirection: 'row',
      paddingVertical: 8,
      backgroundColor:'#ffffff',
      
    },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  imageback: {
    width: 24,
    height: 24,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});