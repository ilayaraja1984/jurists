import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions ,
  Modal,ScrollView} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { Rating,Button,PricingCard} from 'react-native-elements';
import {RadioButton , HelperText} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Ionicons';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'

import BackButton from '../helper/BackButton'
import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL } from '../core/settings'
import {emailValidator} from '../helper/emailValidator'
import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
import { TabView, SceneMap } from 'react-native-tab-view';
//Define a color for toolbar
global.backgroundColor = '#176abf';
var { findNodeHandle } = React;
type Props = {};
const FirstRoute = () => <View style={[ styles.container, { backgroundColor: '#ff4081' } ]} />;
const SecondRoute = () => <View style={[ styles.container, { backgroundColor: '#673ab7' } ]} />;
const initialLayout = { width: Dimensions.get('screen').width,height:30 };
export default class Home extends Component<Props> {
constructor() {
    super();
  
    this.state ={
      isLoging:false,
      checkingAuth:true,
      email:"",
      password:"",
    name:"",
    mobile:"",
    gender:"male",
      activecolor:"#000",
    malebg:'#2980B9',
    femalebg:'#ccc',
    nameError:'',
    psswordError:'',
    emailError:'',
    mobileError:'',
    userSelected:GLOBAL.data,
    routes:[
    { key: 'first', title: 'First' },
    { key: 'second', title: 'Second' },
  ],index:0, setIndex:0,
    }
  
  }
   
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
    if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
    this.setState({ gender: v});
  }
  async setitems(responseJson)
  {
  console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson['uid'],responseJson['session'],responseJson['id']);
  await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
  await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
  await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
  await AsyncStorage.setItem('role', responseJson['role'].toString());

  AsyncStorage.flushGetRequests();
  console.log("==================================<<<<<<<<<<<<<<<",responseJson['uid']);
  Toast.show({
    position: 'top',
    visibilityTime: 100,
      text1: 'Successfully Account Created...',
      text2: 'created for user login',
    onHide: () => {this.props.navigation.navigate('address')},
    }); 
  
  }
  async requestUserSignup() {
  const { navigation } = this.props;
  this.setState({ isLoging: true });
  //console.log(itemId)
  console.log(this.props.route)
   
   //this.setState({ nameError: "Invalid Name" });
    //alert(SERVER_URL);
   if(this.state.name == "" || this.state.name.length<=4){this.setState({ nameError: "Invalid name or text min lenth 4" });}else{this.setState({ nameError: "" });}
   if(this.state.password == "" || this.state.password.length<6){this.setState({ passwordError: "Invalid password or text min lenth 6" });}
   else{this.setState({ passwordError: "" });}
   if(emailValidator(this.state.email)!= ""){this.setState({ emailError: "Invalid email" });return false}else{this.setState({ emailError: "" });}
   if(this.state.mobile == "" || this.state.mobile.length<=9){this.setState({ mobileError: "Invalid mobile" });}else{this.setState({ mobileError: "" });}
  
   if(this.state.email != "" && this.state.password!="" && this.state.mobile!="" && this.state.name!=""){
  var formData = new FormData();
      formData.append('username', this.state.name);
    formData.append('display_name', this.state.name);
        formData.append('Email_Address', this.state.email);
        formData.append('password', this.state.password);
    formData.append('Mobile', this.state.mobile);
    formData.append('gender', this.state.gender);
    formData.append('role', "4"); 
    console.log(formData);
  fetch(SERVER_URL+'?op=register', {
         method: 'POST',
     headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.text())
      .then((responseJsontx) => {
       var responseJson={}
        try{responseJson=JSON.parse(responseJsontx)}catch(e){alert(responseJsontx);responseJson={'result':false,'error':'erroe in page'}}
        
        console.log('-----',responseJson);
        this.setState({ isLoging: false });
       if(responseJson['result']==true)
     {
       this.setitems(responseJson);
       
      
     }
     else{
       
    
      Toast.show({
    type: 'error',
    position: 'top',
      text1: responseJson['errors'],
      text2: 'Please check ',
    
    }); 
       }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
        alert(SERVER_URL+" , "+error);
         console.error(error);
      });  
   }
   else {
     // Alert.alert("Error", "fields are required")
    }
    //this.props.navigation.navigate('homeScreen');
  }
  _handleIndexChange = index => this.setState({ index });

  _renderHeader = props => <TabBar {...props} />;

  _renderScene = SceneMap({
    '1': FirstRoute,
    '2': SecondRoute,
  });

  render() {
    //const { route } = this.props
        //const { loveOne } = route.params;
    console.log('==> NEXT PAGE>',GLOBAL.data); 
   
    return (
   
    <ImageBackground source={require("../assets/profilebk.png")} style={styles.bg}>
    <View style={{flex:1,heigh:20,position:'absolute',top:30,left:15}}> 
   
   <TouchableOpacity onPress={()=> this.props.navigation.navigate('home')} style={styles.container}>
    <Image style={styles.imageback} source={require('../assets/arrow_back.png')} />
   </TouchableOpacity>
    </View> 
    <View style={styles.modalInfo}>
    <View style={{alignItems:'center',height:150,paddingTop:20}}>
                    <Image style={styles.imagemodel} source={{uri: this.state.userSelected.image}}/>
                    <View style={styles.modelname}>
                    <Text style={styles.namemodel}>{this.state.userSelected.name}</Text>
                    <View style={{flexDirection: 'row',  marginLeft:25,}} ><Icon name="location" style={{ fontSize: 13 ,color: '#fff',marginTop:5}} /><Text style={styles.positionmodel}>{this.state.userSelected.position}</Text></View>
                    </View>
                </View>
                    <View style={[styles.userInfo, styles.bordered]}>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Experience
                            </Text>
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              {this.state.userSelected.rating}
                            </Text>
                            <Rating imageSize={15} readonly startingValue={this.state.userSelected.rating} style={styles.rating} />
                          </View>
                          <View style={styles.section}>
                            <Text category='s1' style={styles.space}>
                              0
                            </Text>
                            <Text appearance='hint' category='s2'>
                              Contacted
                            </Text>
                          </View>
                        </View>
                      <View style={styles.buttons}>
                      <Button title="Video Chat" type="clear"/>
                      <View style={styles.separator} />
                      <Button title="Contact Number" type="clear"/>
                      <View style={styles.separator} />
                      <Button title="Schedule" type="clear"/>
                      </View>
                      <View style={{flex: 1,paddingRight:10,paddingLeft:10}}>
                      <Text category='s1' style={styles.space}>
                              0
                            </Text>
                       
  <TabView
        style={styles.container1}
        navigationState={this.state}
        renderScene={SceneMap({
    first: FirstRoute,
    second: SecondRoute,
  })}
         renderHeader={this._renderHeader}
         initialLayout={{ width: Dimensions.get('window').width }}
        onIndexChange={this._handleIndexChange}
      />
                         
                      </View>
                </View>
     
    </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    position: 'absolute',
    top: 10 + getStatusBarHeight(),
    left: 4,backgroundColor:'red'
  },
container1: {
    flex: 1,
  },
  scene: {
    flex: 1,
  },
  imageback: {
    width: 24,
    height: 24,
  },
  modalInfo:{
    alignItems:'center',
    paddingTop:10
  },
  loading: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    opacity: 0.5,
    zIndex:1000000,
    justifyContent: 'center',
    alignItems: 'center'
  },
 container:{
    flex:1,

  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    backgroundColor:'#fff',
  marginTop:-10,
  height:170,
  
  
  }, buttons: {
      flexDirection: 'row',
      paddingVertical: 8
    },
    button: {
      flex: 1,
      alignSelf: 'center'
    },
  userInfo: {
      flexDirection: 'row',
      paddingVertical: 10,
      marginTop:10
    },
bordered: {

      borderTopWidth: 1,
      borderColor: '#ccc',
      borderBottomWidth: 1,
    },
  section: {
      flex: 1,
      alignItems: 'center'
    },
    space: {
      marginBottom: 3,
      color: '#ccc'
    },
  rating:{marginLeft:0},
  modelname:{flexDirection: 'row',
      flex:1,
      alignItems: 'center',marginTop:10,},
  containerrow: {
      flexDirection: 'row',
      
      alignItems: 'center',
     
      
    marginTop:10,
   },
  containertop:{
    flex:1,
    
  
  
  },
  separator: {
      backgroundColor: '#ccc',
      alignSelf: 'center',
      flexDirection: 'row',
      flex: 0,
      width: 1,
      height: 20
    },
  searchbar:{marginTop:0},
  header:{
    backgroundColor: "#00CED1",
    height:200
  },
  headerContent:{
    padding:30,
    alignItems: 'center',
    flex:1,
  },
  detailContent:{
    top:80,
    height:300,
    width:Dimensions.get('screen').width - 90,
    marginHorizontal:30,
    flexDirection: 'row',
    position:'absolute',
    backgroundColor: "#ffffff"
  },
  userList:{
    flex:1,
  },
  cardContent: {
    marginLeft:10,
    marginTop:5
  },
  image:{
    width:80,
    height:90,
    marginTop:5
  
  },
  imagemodel:{
    width:80,
    height:90,
    marginTop:5,
    borderRadius: 150 / 2,
    overflow: "hidden",
    borderWidth: 3,},
verified:{
    width:80,
    height:20,
    marginTop:5,
   
  },

 cardbutton:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '37%',
    padding: 5,

    flexDirection:'row'
  },
  cardbutton1:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
   
    flexBasis: '27%',
    paddingLeft: 10,

    flexDirection:'row'
  },
  card:{
    shadowColor: '#00000021',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,
    elevation: 12,

    marginVertical: 2,
    marginHorizontal:2,
    backgroundColor: "#ffffff",
    flexBasis: '46%',
    padding: 5,
  padding: 5,
    flexDirection:'row'
  },
 namemodel:{
    fontSize:14,

  marginLeft:5,
    color:"#fff",
    alignSelf:'center',
    fontWeight:'bold',


  },

  name:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#000",
    fontWeight:'bold',

  },
  bname:{
    fontSize:17,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:10,
    color:"#fff",
    fontWeight:'bold',

  },
  position:{
    fontSize:14,
    flex:1,
    alignSelf:'flex-start',
  marginLeft:5,
    color:"#696969"
  },
  positionmodel:{
    fontSize:14,
    color:"#fff"
  },
  about:{
    marginHorizontal:10
  },

});