import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height'
import {YellowBox} from 'react-native';
YellowBox.ignoreWarnings(['Warning: Async Storage has been extracted from react-native core']);
import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import { Modal , RadioButton , HelperText} from 'react-native-paper';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'
import Button from '../helper/Button'
import BackButton from '../helper/BackButton'
import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL } from '../core/settings'
import {emailValidator} from '../helper/emailValidator'
import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
//Define a color for toolbar
global.backgroundColor = '#176abf';
var { findNodeHandle } = React;
type Props = {};
export default class Home extends Component<Props> {
constructor() {
    super();
	
    this.state ={
      isLoging:false,
      checkingAuth:true,
      email:"",
      password:"",
	  name:"",
	  mobile:"",
	  gender:"male",
      activecolor:"#000",
	  malebg:'#2980B9',
	  femalebg:'#ccc',
	  nameError:'',
	  psswordError:'',
	  emailError:'',
	  mobileError:'',
    }
	
  }
   
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
  cgender(v) {
	  if(v=='male'){this.setState({ femalebg: "#ccc" });this.setState({ malebg: "#2980B9" });}
      else{this.setState({ malebg: "#ccc" });this.setState({ femalebg: "#2980B9" });}
	  this.setState({ gender: v});
  }
  async setitems(responseJson)
  {
	console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson['uid'],responseJson['session'],responseJson['id']);
	await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
	await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
	await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
	await AsyncStorage.setItem('role', responseJson['role'].toString());

	AsyncStorage.flushGetRequests();
	console.log("==================================<<<<<<<<<<<<<<<",responseJson['uid']);
	Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully Account Created...',
      text2: 'created for user login',
	  onHide: () => {this.props.navigation.navigate('address')},
    }); 
	
  }
  async requestUserSignup() {
	const { navigation } = this.props;
	this.setState({ isLoging: true });
	//console.log(itemId)
	console.log(this.props.route)
   
	 //this.setState({ nameError: "Invalid Name" });
	  //alert(SERVER_URL);
	 if(this.state.name == "" || this.state.name.length<=4){this.setState({ nameError: "Invalid name or text min lenth 4" });}else{this.setState({ nameError: "" });}
	 if(this.state.password == "" || this.state.password.length<6){this.setState({ passwordError: "Invalid password or text min lenth 6" });}
	 else{this.setState({ passwordError: "" });}
	 if(emailValidator(this.state.email)!= ""){this.setState({ emailError: "Invalid email" });return false}else{this.setState({ emailError: "" });}
	 if(this.state.mobile == "" || this.state.mobile.length<=9){this.setState({ mobileError: "Invalid mobile" });}else{this.setState({ mobileError: "" });}
	
	 if(this.state.email != "" && this.state.password!="" && this.state.mobile!="" && this.state.name!=""){
	var formData = new FormData();
	    formData.append('username', this.state.name);
		formData.append('display_name', this.state.name);
        formData.append('Email_Address', this.state.email);
        formData.append('password', this.state.password);
		formData.append('Mobile', this.state.mobile);
		formData.append('gender', this.state.gender);
		formData.append('role', "4"); 
		console.log(formData);
	fetch(SERVER_URL+'?op=register', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.text())
      .then((responseJsontx) => {
			 var responseJson={}
			  try{responseJson=JSON.parse(responseJsontx)}catch(e){alert(responseJsontx);responseJson={'result':false,'error':'erroe in page'}}
			  
			  console.log('-----',responseJson);
			  this.setState({ isLoging: false });
			 if(responseJson['result']==true)
		 {
			 this.setitems(responseJson);
			 
			
		 }
		 else{
			 
		
			Toast.show({
	  type: 'error',
	  position: 'top',
      text1: responseJson['errors'],
      text2: 'Please check ',
	  
    }); 
			 }
         console.log(responseJson['result']);
        
      })
      .catch((error) => {
			  alert(SERVER_URL+" , "+error);
         console.error(error);
      });	 
	 }
	 else {
     // Alert.alert("Error", "fields are required")
    }
    //this.props.navigation.navigate('homeScreen');
  }
  render() {
    //const { route } = this.props
        //const { loveOne } = route.params;
        
    return (
	 
     <Background>
	 
	 <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:1000}} />
	 
    
      <Logo />
      <Header>Create Account</Header>
     

  <TextInput
	    ref="myInput"
        label="Name"
        returnKeyType="next"
        onChangeText={name => this.setState({name})}
        errorText={this.state.nameError}
	 
      />

     
      <TextInput
        label="Password"
        returnKeyType="done"
        onChangeText={password => this.setState({password})}
        secureTextEntry
		errorText={this.state.passwordError}
      />
	  <TextInput
        label="Email"
        returnKeyType="next"
        onChangeText={email => this.setState({email})}
        autoCapitalize="none"
        autoCompleteType="email"
        textContentType="emailAddress"
        keyboardType="email-address"
		errorText={this.state.emailError}
      />
	  <TextInput
        label="Mobile"
        returnKeyType="next"
        onChangeText={mobile => this.setState({mobile})}
        autoCapitalize="none"
        textContentType="numeric"
        keyboardType="numeric"
		errorText={this.state.mobileError}
      />
	
	<View style={{ flexDirection: "row" }}>
     <View style={{ flex: 1 }}>
         <TouchableOpacity style={{ alignSelf: 'stretch',backgroundColor: this.state.malebg }} onPress={() => this.cgender('male')}>
              <Text style={{ alignSelf: 'center',
                            color: '#ffffff',
                            fontSize: 16,
                            fontWeight: '600',
                            paddingTop: 10,
                            paddingBottom: 10 }}>Male</Text>
         </TouchableOpacity>
     </View>
     <View style={{borderLeftWidth: 1,borderLeftColor: 'white'}}/>
     <View style={{ flex: 1}}>
         <TouchableOpacity style={{ alignSelf: 'stretch',backgroundColor: this.state.femalebg}} onPress={() =>this.cgender('female')}>
              <Text style={{ alignSelf: 'center',
                            color: '#ffffff',
                            fontSize: 16,
                            fontWeight: '600',
                            paddingTop: 10,
                            paddingBottom: 10 }}>Female</Text>
         </TouchableOpacity>
     </View>
 </View>
  
      <Button
        mode="contained"
         onPress={() => this.requestUserSignup()}
        style={{ marginTop: 24 }}
      >
        Sign Up
      </Button>
      <View style={styles.row}>
        <Text>Already have an account? </Text>
        <TouchableOpacity onPress={() => this.props.navigation.navigate('login')}>
          <Text style={styles.link}>Login</Text>
        </TouchableOpacity>
      </View>
	  {this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
    </Background>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    position: 'absolute',
    top: 10 + getStatusBarHeight(),
    left: 4,
  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  image: {
    width: 24,
    height: 24,
  },
  radio: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
  radioContainer: {
    height: 20,
    width: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputs : {
    borderRadius:25,
    backgroundColor:'#fff',
    width:80+'%',
    paddingHorizontal:25,
    fontSize:16,
    marginTop:20
  },
   row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
});