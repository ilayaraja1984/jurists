import React, {Component} from 'react';
import {Platform,  Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator,Dimensions} from 'react-native';
import { theme } from '../core/theme'
import Icon from 'react-native-vector-icons/Ionicons';
import config from '../core/global'
import { SERVER_URL,SERVER } from '../core/settings'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

type Props = {};
export default class Myappoinment extends Component<Props> {
  render() {
	 
	  let items=this.props.route.params.data.data;let image= SERVER+items.image; console.log("xxxxxxxxxxxxxxxxx",image);
	  
    return (
      <View style={{height:"100%"}}>
	  
	   <View style={{height:70,backgroundColor:theme.colors.primary,width:"100%"}}>
	   <TouchableOpacity onPress={()=>{this.props.navigation.navigate('appoinment');;}} style={{position:'relative',top:20,left:20}}>
    <Icon name="arrow-back-outline" style={{ fontSize: 25 ,color: '#fff',}} /> 
   </TouchableOpacity>
  <View style={{alignItems:'center'}}><Text style={{fontWeight:'bold',color:'#fff',fontSize:18}}>My Appoinments </Text></View>
       </View> 
  <View style={{  paddingBottom:10,}}>

<View style={{marginTop:20}}>
       <View  style={{flexDirection: 'row',width:"100%",paddingLeft:10}}>
				<Image style={{width:75,height:75}} source={{uri:image}}/>
				<View  style={{flexDirection: 'column',paddingLeft:5}}>
				<Text style={{marginLeft: 5,fontSize: 20,fontWeight:"bold" }}>{items.username}</Text>
				<View  style={{flexDirection: 'row',}}>
				<View  style={{width:"30%"}}><Text style={{marginLeft: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}}>{items.time}</Text></View>
				
				<View  style={{width:"55%",flexDirection: 'row',alignItems:"flex-end",justifyContent: 'flex-end'}} >
				<Text style={{marginRight: 5,marginTop: 15,fontSize: 16,fontWeight:"bold",color: theme.colors.secondary}} >Calling....</Text>
				</View>
				</View>
				</View>
				</View>
        </View>
</View>
<View style={{marginTop:20}}>

</View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  imageback: {
    width: 24,
    height: 24,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});