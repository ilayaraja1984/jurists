import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,ImageBackground,TextInput,ActivityIndicator,TouchableOpacity, Alert,Image,StatusBar, BackHandler} from 'react-native';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import Logo from '../helper/Logo'
import { SERVER_URL } from '../core/settings'
import Toast from 'react-native-toast-message';
import GLOBAL from '../core/global'
import { theme } from '../core/theme'
const instructions = Platform.select({
  ios: 'Press Cmd+R to reload,\n' + 'Cmd+D or shake for dev menu',
  android:
    'Double tap R on your keyboard to reload,\n' +
    'Shake or press menu button for dev menu',
});

//Define a color for toolbar
global.backgroundColor = '#176abf';

type Props = {};
export default class Home extends Component<Props> {
constructor() {
    super();
    this.state ={
      isLoging:false,
      checkingAuth:true,
      email:"",
      password:""
    }
	
  }
  
   backAction = () => {
	  console.log(this.props.navigation.state.params['name'])
	  if(this.props.navigation.state.routeName=='First'){
		  try{
			  let nm=this.props.navigation.state.params['name'];
			  if(nm=='signup' || nm=='signuplawyer'){this.props.navigation.navigate('login');}
			  }
		  catch(e){}
		  return true}
    Alert.alert("Hold on!", "Are you sure you want to go back?", [
      {
        text: "Cancel",
        onPress: () => null,
        style: "cancel"
      },
      { text: "YES", onPress: () => BackHandler.exitApp() }
    ]);
    return true;
  };
  componentDidMount() {
    BackHandler.addEventListener("hardwareBackPress", this.backAction);
  }

  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.backAction);
  }
  async pos(n){
	await AsyncStorage.setItem('screen',n);
	AsyncStorage.flushGetRequests();}
  async setitems(responseJson)
  {
	//await AsyncStorage.clear();
	await AsyncStorage.setItem('email', this.state.email);
	await AsyncStorage.setItem('password', this.state.password);
	await AsyncStorage.setItem('uid', responseJson['uid']);
	await AsyncStorage.setItem('session', responseJson['session']);
	await AsyncStorage.setItem('id', responseJson['id']);
	AsyncStorage.flushGetRequests();
	console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
	this.props.navigation.setParams({name:'home'});
	Toast.show({
	  position: 'top',
	  visibilityTime: 100,
      text1: 'Successfully signed ...',
      text2: 'login',
	  onHide: () => {this.props.navigation.navigate('homeScreen');},
    });
	
  }
   async getitems()
{
	let uid=await AsyncStorage.getItem('uid');
	let id=await AsyncStorage.getItem('id');
	let session=await AsyncStorage.getItem('session');
	
	return [uid,id,session]
}
  signuplawyer(){this.props.navigation.setParams({name:'signuplawyer'}); this.props.navigation.navigate('signuplawyer');}
  async signup(){
	 this.props.navigation.setParams({name:'signup'});
	this.props.navigation.navigate('signup');}
  requestUserLogin() {
    this.setState({isLoging:true})
	 if(this.state.email != "" && this.state.password!=""){
	var formData = new FormData();
        formData.append('email', this.state.email);
        formData.append('password', this.state.password);
		console.log(SERVER_URL,'==========================>>>>>>>>>>>>>>>>>>>>>');
	fetch(SERVER_URL+'?op=login', {
         method: 'POST',
		 headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.json())
      .then((responseJson) => {
			 //console.log("lllllllllllllllllooggg");
			 console.log(responseJson);this.setState({ isLoging: false });
		 if(responseJson['result']==false)
		 {
			try{alert(responseJson['errors'][0])}catch(e){alert("Invalid login details..")}
		 }
		 else{
			   let responseJsons=responseJson['data'];
			   console.log(responseJsons['uid'], responseJsons['session'],responseJsons['session']);
			   this.setitems(responseJsons);
			   //console.log('valuesxxxxxxxxxxx:',)
			   
			 
			 
			 }
         //console.log(responseJson['result']);
         
      })
      .catch((error) => {
         console.error(error);
      });	 
	 }
	 else {
      Alert.alert("Error", "fields are required")
    }
    //this.props.navigation.navigate('homeScreen');
  }
  render() {
	  const checkingAuth = false
	  const isLoging = false
    return (
     <View style={styles.container}>
	    <Toast ref={(ref) => Toast.setRef(ref)} style={{zIndex:1000}} />
        <StatusBar backgroundColor="#775ef0" />
        {checkingAuth ?
          <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <ActivityIndicator size={'large'} color="#775ef0" />
          </View>
          :
          <ImageBackground source={require("../assets/images/background.png")} style={styles.bg}>
            <Image source ={require("../assets/icons/logo.png")} style={{width:100, height:100}} resizeMode="contain"/>
            <Text style={{fontSize:30,fontWeight:'bold'}}>Juristz</Text>
            <Text style={{fontSize:15,}}>Zone of Lawers</Text>
            <Text style={{fontSize:20}}>Login to continue</Text>
            <TextInput style={styles.inputs}
                    placeholder="Your Email"
                    placeholderTextColor="#000000" 
                    onChangeText={email => this.setState({email})}/>
            <TextInput style={styles.inputs}
                  placeholder="Your password"
                  secureTextEntry={true}
                  placeholderTextColor="#000000" 
                  onChangeText={password => this.setState({password})}/>
            <View style={{marginTop:20,flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
              {!isLoging ?
                <TouchableOpacity style={styles.btnarrow} onPress={()=>this.requestUserLogin()}>
                  <Icon name="arrow-right" size={25} color="#fff" />
                </TouchableOpacity>:
                <TouchableOpacity style={styles.btnarrow}>
                  <ActivityIndicator color="#fff" size={"large"}/>
                </TouchableOpacity>
              }
              <View style={{marginHorizontal:30}}><Image source ={require("../assets/icons/face.png")} style={{width:40, height:40}} resizeMode="contain"/></View>
              <View><Text style={{fontSize:12,textDecorationLine:'underline'}}>Forgot password</Text></View>
            </View>
                       
            <View style={{marginVertical:20}}><Text style={{fontSize:12}}>Not registered please</Text></View>
            <TouchableOpacity style={{backgroundColor:'#775ef0',paddingVertical:15,paddingHorizontal:30,borderRadius:25}} onPress={()=>this.signup()}>
                <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Sign up</Text>
            </TouchableOpacity>
			<TouchableOpacity style={{backgroundColor:'#775ef0',paddingVertical:15,paddingHorizontal:30,borderRadius:25,marginVertical:15}} onPress={()=>this.signuplawyer()}>
                <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Sign up as Lawyer</Text>
            </TouchableOpacity>
			{this.state.isLoging &&
	   <View style={styles.loading}>
     <ActivityIndicator animating={this.state.isLoging} size="large" color={theme.colors.primary} />
   </View>}
          </ImageBackground>
        }
        
        
      </View>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    flex: 1,
    flexDirection: "column"
  },
  inputs : {
    borderRadius:25,
    backgroundColor:'#fff',
    width:80+'%',
    paddingHorizontal:25,
    fontSize:16,
    marginTop:20
  },
  btnarrow:{
    backgroundColor:'#775ef0',
    borderRadius:25,
    paddingHorizontal:40,
    paddingVertical:5
  },
  socialbtn:{
    backgroundColor:'#fff',
    borderRadius:25,
    width:30+'%',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    paddingVertical:5,
    marginHorizontal:10,
  },
  socialbtntxt:{
    marginLeft:10,
    fontSize:14,
    fontWeight:'bold'
  },
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  bg: {
    flex: 1,
    resizeMode: "cover",
    justifyContent: "center",
    alignItems:'center'
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});