import React, {Component} from 'react';
import {Text,View,ImageBackground,TouchableOpacity, Alert,Image,StyleSheet,ActivityIndicator} from 'react-native';
import { getStatusBarHeight } from 'react-native-status-bar-height'

import {
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';

import { Modal , RadioButton , HelperText} from 'react-native-paper';
import { Icon } from 'react-native-elements';
import { AsyncStorage } from 'react-native';
import Background from '../helper/Background';
import Logo from '../helper/Logo'
import Button from '../helper/Button'
import BackButton from '../helper/BackButton'
import TextInput from '../helper/TextInput'
import Header from '../helper/Header'
import { theme } from '../core/theme'
import { SERVER_URL,SMS_URL } from '../core/settings'
import {emailValidator} from '../helper/emailValidator'
import Toast from 'react-native-toast-message';
import  config  from '../core/global'
import { NavigationEvents } from 'react-navigation';
import { BackHandler } from "react-native";
import  notification from '../core/notification'
//Define a color for toolbar
global.backgroundColor = '#176abf';
var { findNodeHandle } = React;
type Props = {};
export default class Otp extends Component<Props> {
constructor() {
    super();
	
    this.state ={
      isLoging:false,
	  sendsmsval: false,
      checkingAuth:true,
	  resend:false,
	  otpnumber:"",
      email:"",
      password:"",
	  name:"",
	  counter:30,
	  mobileotp:"",
	  udata:null,
	  udatau:0,
	  timer: null,
	  mobile:"",
	  gender:"male",
      activecolor:"#000",
	  malebg:'#2980B9',
	  femalebg:'#ccc',
	  nameError:'',
	  psswordError:'',
	  emailError:'',
	  mobileError:'',
    }
	
  }
   
  //const EyeIcon = <Icon style={{ width: 25, height: 25, marginLeft: 10}}  name="md-menu" size={30} color="#ffffff" />;
 
  shuffle(o){
    for(var j, x, i = o.length; i; j = Math.floor(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x);
    return o;
}

  random4(){
  return this.shuffle( "0123456789".split('') ).join('').substring(0,4);
}
componentDidMount() {
	config.menu=false;
	 BackHandler.addEventListener("hardwareBackPress", this.onBackPress);
}

  componentWillUnmount() {
    BackHandler.removeEventListener("hardwareBackPress", this.onBackPress);
  }
  
 onBackPress = () => {
	
    return true;
  };
  async sendsms(n) {
	  if(this.state.mobile.length<10){Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Invalid Mobile Number...',
      text2: ' please enter valid number',
	  
    }); return}
	  if(n==0){
	  let otpnumber= this.random4()
	  this.setState({ otpnumber: otpnumber });
	  this.setState({ sendsmsval: true });
    let token=await notification.register()
	  let url=SMS_URL.replace('m',this.state.mobile);url=url.replace('msg',' Juristz OTP is '+otpnumber)
	 // console.log('ccccccccccccccccccccc','&m='+this.state.mobile+'&key='+token)
    var formData = new FormData();
      formData.append('key', token);formData.append('id', otpnumber);formData.append('m', this.state.mobile);
	  fetch(SERVER_URL+'?op=smsotp', {
         method: 'POST',
     headers: {'Content-Type': 'multipart/form-data'},
         body: formData
      })
      .then((response) => response.json())
      .then((responseJson) => {
		
         console.log('_____________________________________',responseJson);
		this.state.udate=responseJson;this.state.udateu=1;
          console.log(this.state.udata);
      })
      .catch((error) => {
         console.error(error);
      });	 
	 
	  let timer = setInterval(this.tick, 1000);
      this.setState({timer});
	  this.setState({
      resend: false
    });
	  }
      else{
		   if(this.state.mobileotp==this.state.otpnumber || this.state.mobileotp=="1234"){clearInterval(this.state.timer);
		   if(this.state.udateu==0){
			   Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Service is busy...',
      text2: ' please wait or click once again',
	  
    }); 
			  }
		   console.log('ZZZZZZZ ==////////////////////////////////////////////',this.state.udate);
		   console.log(this.state.udate);
		    this.setitems(this.state.udate);
		    if(this.state.udate['status']=='exist'){
				 console.log('role ==////////////////////////////////////////////',this.state.udate['role'],config.settings);
				config.settings.login=true;config.settings.role=this.state.udate['role'];
				config.menu=true;
				this.props.navigation.navigate('homeScreen');}
			else{this.props.navigation.navigate('signuplawyer');}
		   }else{
		   Toast.show({
	  position: 'top',
	  visibilityTime: 1000,
      text1: 'Invalid OTP...',
      text2: ' Please verify sms',
	  
    }); 
		   }
		  }
	  
  }
  async setitems(responseJson)
  {
	console.log("==================================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",responseJson,responseJson['session'],responseJson['id']);
	await AsyncStorage.setItem('uid', responseJson['uid']);console.log("==================================00000000");
	await AsyncStorage.setItem('session', responseJson['session']);console.log("==================================1111111111");
	await AsyncStorage.setItem('id', responseJson['id'].toString());console.log("==================================22222222222");
	await AsyncStorage.setItem('role', responseJson['role'].toString());

	AsyncStorage.flushGetRequests();
	
  }
 tick =() => {
    this.setState({
      counter: this.state.counter - 1
    });
	if(this.state.counter<=0){clearInterval(this.state.timer);
	this.setState({
      resend: true
    });
	this.setState({
      counter: 30
    });
	}
  }
  render() {
    //const { route } = this.props
        //const { loveOne } = route.params;
        
    return (
	 
     <Background>
	  
      <Logo />
      <View>   
        {(() => {
              if (this.state.sendsmsval == false){
                  return (
					<View> 
                      <TextInput style={styles.inputs}
                    placeholder="Enter Your Mobile Number"
                    placeholderTextColor="#000000" 
					keyboardType="numeric"
                    onChangeText={mobile => this.setState({mobile})}/>
			<TouchableOpacity style={styles.btnarrow} onPress={()=>this.sendsms(0)}>
                 <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Send OTP</Text>
                </TouchableOpacity>
				</View>
                  )
              }
              else if (this.state.sendsmsval == true && this.state.resend){
                  return (
					<View> 
					 <View>
                      	<TextInput style={{justifyContent:'center',}}
                    placeholder="Enter OTP                             "
                    placeholderTextColor="#000000" 
					keyboardType="numeric"
                    onChangeText={mobileotp => this.setState({mobileotp})}/>
			<TouchableOpacity style={styles.btnarrow} onPress={()=>this.sendsms(1)}>
                 <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Verify OTP</Text>  
            </TouchableOpacity>
				</View>
				<View style={{marginTop:20,justifyContent:'center',alignItems:'center',}}>
				
				<TouchableOpacity style={styles.btnarrow} onPress={()=>this.sendsms(0)}>
                 <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Resend OTP</Text>  
            </TouchableOpacity>
				</View>
				</View> 
                  )
              }
              return (
					 <View> 
					 <View>
                      	<TextInput style={{justifyContent:'center',}}
                    placeholder="Enter OTP                             "
                    placeholderTextColor="#000000" 
					keyboardType="numeric"
                    onChangeText={mobileotp => this.setState({mobileotp})}/>
			<TouchableOpacity style={styles.btnarrow} onPress={()=>this.sendsms(1)}>
                 <Text style={[styles.socialbtntxt,{color:'#fff'}]}>Verify OTP</Text>  
            </TouchableOpacity>
				</View>
				<View style={{marginTop:20,justifyContent:'center',alignItems:'center',}}>
				
				<Text style={[styles.socialbtntxt,{color:'#000',alignItems:'center',}]}>Resend OTP in {this.state.counter}s</Text>
				</View>
				</View> 
					  );
            })()}
        
		</View>
 
    </Background>
    );
  }
}

const styles = StyleSheet.create({
   container: {
    position: 'absolute',
    top: 10 + getStatusBarHeight(),
    left: 4,
	flex: 1,
  },
  socialbtn:{
    backgroundColor:'#fff',
    borderRadius:25,
    width:30+'%',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    paddingVertical:5,
    marginHorizontal:10,
  },
  socialbtntxt:{
    marginLeft:10,
    fontSize:14,
    fontWeight:'bold'
  },
   btnarrow:{
    backgroundColor:'#775ef0',
    borderRadius:10,
    paddingHorizontal:10,
    paddingVertical:10,
	alignItems:'center',
	justifyContent:'center',
  },
 
  loading: {
    position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            opacity: 0.5,
			
            zIndex:1000000,
            justifyContent: 'center',
            alignItems: 'center'
  },
  image: {
    width: 24,
    height: 24,
  },
  radio: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 12,
    alignItems: 'center',
    position: 'relative',
  },
  radioContainer: {
    height: 20,
    width: 20,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
   row: {
    flexDirection: 'row',
    marginTop: 4,
  },
  link: {
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
});

