//This is an example code for Navigation Drawer with Custom Side bar//
//This Example is for React Navigation 3.+//
import React, { Component } from 'react';
// import all basic components as follows
import {
  View,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
  Platform,
  Text,
  StatusBar,
  SearchBox,
  TextInput,ImageBackground
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { Searchbar } from 'react-native-paper';
 //++++++++++++++++++++For React-native <0.60.0 use following imports++++++++++++++++++++++++++
//Import required react-navigation component with requried
//import {
 // createDrawerNavigator,
 // createStackNavigator,
 // createAppContainer,
//} from 'react-navigation';

//++++++++++++++++++++For React-native >0.60.0 or above use following imports++++++++++++++++++++++++++
import {createAppContainer} from 'react-navigation';
import {createDrawerNavigator} from 'react-navigation-drawer';
import {createStackNavigator} from 'react-navigation-stack';
 import { theme } from './core/theme'
 import  config  from './core/global'
//Import all the menu screens
import Screen1 from './components/Home';
import Screen2 from './components/MyList';
import Login from './components/Login';
import signup from './components/signup';
import profile from './components/profile';
import signuplawyer from './components/signuplawyer';
import address from './components/address';
import profileupdate from './components/profileupdate';
import lawyerprofileupdate from './components/lawyerprofileupdate';
import otp from './components/otp';
import test from './components/test';
import homenew from './components/homenew';
import details from './components/details';
import { AsyncStorage } from 'react-native';
//Import Custom Sidebar component
import CustomMenuSidebar from './components/CustomMenuSidebar';

//Define a global color for toolbar 176abf F96233 898989 31AAFB  F43B36 9C26B0  111111  737373
global.backgroundColor = theme.colors.primary;

const logo = require('./image/logo.jpg')

class SplashScreen extends Component {
  performTimeConsumingTask = async() => {
    return new Promise((resolve) =>
      setTimeout(
        () => { resolve('result') },
        3000
      )
    )
  }
async getitems()
{
  let uid=await AsyncStorage.getItem('uid');
  let id=await AsyncStorage.getItem('id');
  let session=await AsyncStorage.getItem('session');
  let role=await AsyncStorage.getItem('role');
  let scren=await AsyncStorage.getItem('screen');
  return [uid,id,session,role,scren]
}
  async componentDidMount() {
    // Preload data from an external API
    // Preload data using AsyncStorage
  
    const data = await this.performTimeConsumingTask();
    
    if (data !== null) {
    let ldata=await this.getitems();
    console.log("Log","loading............. started",ldata)
    if(ldata[0]==null){this.props.navigation.navigate('otp');}
    if(ldata[0].length>=5){
      console.log("homescreen","loading............. started",ldata[4]);
      if(ldata[4]=='profile'){this.props.navigation.navigate('profileupdate');}
      else if(ldata[4]=='address'){this.props.navigation.navigate('address');}
    else {console.log("========= started",ldata[3]);config.settings.login=true;config.settings.role=ldata[3];this.props.navigation.navigate('homenew'); }//homeScreen 
    }else{this.props.navigation.navigate('otp');}
    }else{this.props.navigation.navigate('otp');}
  }

  render() {
    const viewStyles = [styles.container, { backgroundColor: 'orange' }];
    const textStyles = {
      color: 'white',
      fontSize: 40,
      fontWeight: 'bold'
    };

    return (
      <ImageBackground source={require("./assets/splashbk.png")} style={styles.bg}>
      <View style={styles.SplashScreen_RootView}>
     
       <StatusBar backgroundColor={theme.colors.primary} barStyle='light-content' />
        
    <Image
          source={ logo }
          style={styles.CircleShapeView}
        />
    
      </View>
    </ImageBackground>
    );
  }
}


//Navigation Drawer button Structure for all screen
class NavigationDrawerButton extends Component {
  //Top Navigation Header with Donute Button
  toggleDrawer = () => {
    //Props to open/close the drawer
    this.props.navigationProps.toggleDrawer();
  };
  
  render() {
    
    return (
      <View>
      <StatusBar backgroundColor={theme.colors.primary} barStyle='light-content' />
      <View style={{ flexDirection: 'row',marginBottom:5 }}>
       
        <TouchableOpacity onPress={this.toggleDrawer.bind(this)}>
          {/*Donute Button Image */}
          <Icon  
                        style={{ width: 25, height: 25, marginLeft: 20}}    
                        name="md-menu"  
                        size={30}
                        color="#ffffff"  
                    />  
         
        </TouchableOpacity>
      </View>
      </View>
    );
  }
}
 //-------------------------Set Navigation Drawer options as follows-------------------------------------
//First Option of Navigation Drawer
const FirstOption_StackNavigator = createStackNavigator({
  
  First: {
    screen: Screen1,
    navigationOptions: ({ navigation }) => ({
      title: 'Juristz',
      headerLeft: <NavigationDrawerButton navigationProps={navigation} />,
 
      headerStyle: {
        backgroundColor: backgroundColor,
      },
      headerTintColor: '#fff',
    }),
  },
});
 
//Second Option of Navigation Drawer
const Second_StackNavigator = createStackNavigator({
 
  Second: {
    screen: Screen2,
    navigationOptions: ({ navigation }) => ({
      title: 'Wallet',
      headerLeft: <NavigationDrawerButton navigationProps={navigation} />,
 
      headerStyle: {
        backgroundColor: backgroundColor,
      },
      headerTintColor: '#fff',
    }),
  },
});
 //Second Option of Navigation Drawer
const Login_StackNavigator = createStackNavigator({
 
  First: {
    screen: Login,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const test_StackNavigator = createStackNavigator({
 
  First: {
    screen: test,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const Signup_StackNavigator = createStackNavigator({
 
  First: {
    screen: signup,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const Signuplawyer_StackNavigator = createStackNavigator({
 
  First: {
    screen: signuplawyer,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const homenew_StackNavigator = createStackNavigator({
 
  First: {
            screen: homenew,
            navigationOptions: { title: 'Home' }
        },
});
const details_StackNavigator = createStackNavigator({
 
  First: {
            screen: details,
            navigationOptions: { title: 'detilsHome' }
        },
});
const profile_StackNavigator = createStackNavigator({
 
  First: {
    screen: profile,
    headerMode: 'none',
    navigationOptions: { header: null } ,
    params: { user: 'meyyyyyyyyyyyyyyyyyyyyyyyyyy' },
  },
});
const address_StackNavigator = createStackNavigator({
 
  First: {
    screen: address,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const profileupdate_StackNavigator = createStackNavigator({
 
  First: {
    screen: profileupdate,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const lawyerprofileupdate_StackNavigator = createStackNavigator({
 
  First: {
    screen: lawyerprofileupdate,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
const otp_StackNavigator = createStackNavigator({
 
  First: {
    screen: otp,
    headerMode: 'none',
    navigationOptions: { header: null } 
  },
});
//----------------------------------Define screens using createDrawerNavigator------------------------
//Drawer Navigator Which will provide the structure of our App
const DrawerNavigator = createDrawerNavigator(
  {
    //Drawer Optons and indexing
    splash: {
      screen: SplashScreen,
     
    },
    homeScreen: {
      screen: FirstOption_StackNavigator,
     
    },
    homenew: {
      screen: homenew_StackNavigator,
     
    },
    details: {
      screen: details_StackNavigator,
     
    },
    myList: {
      screen: Second_StackNavigator,
     
    },
    login: {
      screen: Login_StackNavigator,
     
    },
  
    profile: {
      screen: profile_StackNavigator,
     
    },
    signup: {
      screen: Signup_StackNavigator,
     
    },
  signuplawyer: {
      screen: Signuplawyer_StackNavigator,
     
    },
  address: {
      screen: address_StackNavigator,
     
    },
  profileupdate: {
      screen: profileupdate_StackNavigator,
     
    },
  lawyerprofileupdate: {
      screen: lawyerprofileupdate_StackNavigator,
     
    },
  otp: {
      screen: otp_StackNavigator,
     
    },
  test: {
      screen: test_StackNavigator,
     
    }
  },
  {
    //Custom sidebar menu we have to provide our CustomMenuSidebar
    contentComponent: CustomMenuSidebar,
    //Set sidebar width 
    drawerWidth: Dimensions.get('window').width - 130,
  }
);
export default createAppContainer(DrawerNavigator);
const styles = StyleSheet.create(  
{  
    MainContainer:  
    {  
        flex: 1,  
        justifyContent: 'center',  
        alignItems: 'center',  
        paddingTop: ( Platform.OS === 'ios' ) ? 20 : 0  
    },
  bg: {
    flex: 1,
    resizeMode: "cover",
    
  marginTop:0,
  height:250,
  
  
  },
  inputs : {
    borderRadius:25,
    backgroundColor:'#fff',
    width:80+'%',
    paddingHorizontal:25,
    fontSize:16,
    marginTop:20
  },
   CircleShapeView: {  
    backgroundColor: '#00BCD4',
    justifyContent: 'center',
    alignItems: 'center'
},
    SplashScreen_RootView:  
    {  
        justifyContent: 'center',  
        flex:1,  
        margin: 0,  
        position: 'absolute',  
        width: '100%',  
        height: '100%',
        justifyContent: 'center',  
        alignItems: 'center', 
 
      },  
      textStyles: {
        color: 'white',
        fontSize: 40,
        fontWeight: 'bold'
      },
    SplashScreen_ChildView:  
    {  
        justifyContent: 'center',  
        alignItems: 'center',  
        backgroundColor: '#00BCD4',  
        flex:1,  
    },  
});